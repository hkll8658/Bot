"""Add payment logs and refund tracking

Revision ID: 004_add_payment_logs
Revises: 003_add_content_moderation
Create Date: 2024-01-04 00:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '004_add_payment_logs'
down_revision = '003_add_content_moderation'
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Add refund tracking to transactions
    op.add_column('transactions', sa.Column('refund_id', sa.String(length=100), nullable=True))
    op.add_column('transactions', sa.Column('refund_amount', sa.Float(), nullable=True))
    op.add_column('transactions', sa.Column('refund_date', sa.DateTime(), nullable=True))
    op.add_column('transactions', sa.Column('refund_reason', sa.Text(), nullable=True))
    
    # Create payment_methods table
    op.create_table('payment_methods',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('method_type', sa.String(length=50), nullable=False),  # 'upi', 'card', 'netbanking'
        sa.Column('provider', sa.String(length=50), nullable=True),
        sa.Column('details', sa.JSON(), nullable=True),  # Encrypted details
        sa.Column('is_default', sa.Boolean(), nullable=True, server_default='false'),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('last_used', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_payment_methods_user_id'), 'payment_methods', ['user_id'], unique=False)
    
    # Create invoices table
    op.create_table('invoices',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('invoice_number', sa.String(length=50), nullable=False),
        sa.Column('transaction_id', sa.String(length=100), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('amount', sa.Float(), nullable=False),
        sa.Column('tax_amount', sa.Float(), nullable=True),
        sa.Column('total_amount', sa.Float(), nullable=False),
        sa.Column('currency', sa.String(length=10), nullable=True, server_default='INR'),
        sa.Column('items', sa.JSON(), nullable=True),
        sa.Column('billing_address', sa.JSON(), nullable=True),
        sa.Column('pdf_url', sa.String(length=500), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('paid_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('invoice_number'),
        sa.UniqueConstraint('transaction_id')
    )
    op.create_index(op.f('ix_invoices_invoice_number'), 'invoices', ['invoice_number'], unique=True)
    op.create_index(op.f('ix_invoices_user_id'), 'invoices', ['user_id'], unique=False)
    
    # Create payment_webhooks table for logging
    op.create_table('payment_webhooks',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('webhook_id', sa.String(length=100), nullable=True),
        sa.Column('event_type', sa.String(length=100), nullable=False),
        sa.Column('payload', sa.JSON(), nullable=True),
        sa.Column('signature', sa.String(length=255), nullable=True),
        sa.Column('verified', sa.Boolean(), nullable=True),
        sa.Column('processed', sa.Boolean(), nullable=True, server_default='false'),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('processed_at', sa.DateTime(), nullable=True),
        sa.Column('error', sa.Text(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('webhook_id')
    )
    op.create_index(op.f('ix_payment_webhooks_event_type'), 'payment_webhooks', ['event_type'], unique=False)
    op.create_index(op.f('ix_payment_webhooks_created_at'), 'payment_webhooks', ['created_at'], unique=False)


def downgrade() -> None:
    # Drop payment_webhooks table
    op.drop_table('payment_webhooks')
    
    # Drop invoices table
    op.drop_table('invoices')
    
    # Drop payment_methods table
    op.drop_table('payment_methods')
    
    # Remove columns from transactions table
    op.drop_column('transactions', 'refund_reason')
    op.drop_column('transactions', 'refund_date')
    op.drop_column('transactions', 'refund_amount')
    op.drop_column('transactions', 'refund_id')