"""Add notifications and announcements tables

Revision ID: 006_add_notifications_tables
Revises: 005_add_analytics_tables
Create Date: 2024-01-06 00:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '006_add_notifications_tables'
down_revision = '005_add_analytics_tables'
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Create notifications table
    op.create_table('notifications',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('type', sa.String(length=50), nullable=False),  # 'info', 'success', 'warning', 'error'
        sa.Column('title', sa.String(length=255), nullable=True),
        sa.Column('message', sa.Text(), nullable=False),
        sa.Column('data', sa.JSON(), nullable=True),
        sa.Column('is_read', sa.Boolean(), nullable=True, server_default='false'),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('read_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_notifications_user_id'), 'notifications', ['user_id'], unique=False)
    op.create_index(op.f('ix_notifications_is_read'), 'notifications', ['is_read'], unique=False)
    op.create_index(op.f('ix_notifications_created_at'), 'notifications', ['created_at'], unique=False)

    # Create announcements table (broadcast messages)
    op.create_table('announcements',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('title', sa.String(length=255), nullable=False),
        sa.Column('message', sa.Text(), nullable=False),
        sa.Column('type', sa.String(length=50), nullable=True, server_default='info'),
        sa.Column('target_audience', sa.String(length=50), nullable=True, server_default='all'),
        sa.Column('filters', sa.JSON(), nullable=True),
        sa.Column('media_url', sa.String(length=500), nullable=True),
        sa.Column('button_text', sa.String(length=100), nullable=True),
        sa.Column('button_url', sa.String(length=500), nullable=True),
        sa.Column('scheduled_for', sa.DateTime(), nullable=True),
        sa.Column('sent_at', sa.DateTime(), nullable=True),
        sa.Column('created_by', sa.Integer(), nullable=False),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('status', sa.String(length=50), nullable=True, server_default='draft'),
        sa.ForeignKeyConstraint(['created_by'], ['admins.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_announcements_status'), 'announcements', ['status'], unique=False)
    op.create_index(op.f('ix_announcements_scheduled_for'), 'announcements', ['scheduled_for'], unique=False)
    op.create_index(op.f('ix_announcements_created_at'), 'announcements', ['created_at'], unique=False)

    # Create announcement_delivery table to track who received announcements
    op.create_table('announcement_delivery',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('announcement_id', sa.Integer(), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('delivered_at', sa.DateTime(), nullable=True),
        sa.Column('read_at', sa.DateTime(), nullable=True),
        sa.Column('clicked_at', sa.DateTime(), nullable=True),
        sa.Column('status', sa.String(length=50), nullable=True, server_default='pending'),
        sa.ForeignKeyConstraint(['announcement_id'], ['announcements.id'], ),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('announcement_id', 'user_id', name='unique_announcement_delivery')
    )
    op.create_index(op.f('ix_announcement_delivery_status'), 'announcement_delivery', ['status'], unique=False)

    # Create user_preferences table for notification settings
    op.create_table('user_preferences',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('notification_email', sa.Boolean(), nullable=True, server_default='true'),
        sa.Column('notification_telegram', sa.Boolean(), nullable=True, server_default='true'),
        sa.Column('notification_push', sa.Boolean(), nullable=True, server_default='false'),
        sa.Column('marketing_emails', sa.Boolean(), nullable=True, server_default='false'),
        sa.Column('language', sa.String(length=10), nullable=True, server_default='en'),
        sa.Column('timezone', sa.String(length=50), nullable=True, server_default='UTC'),
        sa.Column('theme', sa.String(length=20), nullable=True, server_default='light'),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('updated_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('user_id')
    )
    op.create_index(op.f('ix_user_preferences_user_id'), 'user_preferences', ['user_id'], unique=True)


def downgrade() -> None:
    # Drop tables in reverse order
    op.drop_table('user_preferences')
    op.drop_table('announcement_delivery')
    op.drop_table('announcements')
    op.drop_table('notifications')