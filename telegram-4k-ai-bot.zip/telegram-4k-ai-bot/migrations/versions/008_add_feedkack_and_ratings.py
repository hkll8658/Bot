"""Add feedback and ratings system

Revision ID: 008_add_feedback_and_ratings
Revises: 007_add_subscription_tiers
Create Date: 2024-01-08 00:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '008_add_feedback_and_ratings'
down_revision = '007_add_subscription_tiers'
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Create image_feedback table
    op.create_table('image_feedback',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('image_id', sa.Integer(), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('rating', sa.Integer(), nullable=True),  # 1-5 stars
        sa.Column('comment', sa.Text(), nullable=True),
        sa.Column('liked', sa.Boolean(), nullable=True),
        sa.Column('would_use_again', sa.Boolean(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['image_id'], ['generated_images.id'], ),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('image_id', 'user_id', name='unique_image_feedback')
    )
    op.create_index(op.f('ix_image_feedback_rating'), 'image_feedback', ['rating'], unique=False)
    op.create_index(op.f('ix_image_feedback_created_at'), 'image_feedback', ['created_at'], unique=False)

    # Create prompt_templates table
    op.create_table('prompt_templates',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('name', sa.String(length=100), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('template', sa.Text(), nullable=False),
        sa.Column('category', sa.String(length=50), nullable=True),
        sa.Column('tags', sa.JSON(), nullable=True),
        sa.Column('usage_count', sa.Integer(), nullable=True, server_default='0'),
        sa.Column('avg_rating', sa.Float(), nullable=True),
        sa.Column('created_by', sa.Integer(), nullable=True),
        sa.Column('is_public', sa.Boolean(), nullable=True, server_default='true'),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['created_by'], ['users.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_prompt_templates_category'), 'prompt_templates', ['category'], unique=False)
    op.create_index(op.f('ix_prompt_templates_usage_count'), 'prompt_templates', ['usage_count'], unique=False)

    # Create user_favorites table
    op.create_table('user_favorites',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('image_id', sa.Integer(), nullable=False),
        sa.Column('prompt_id', sa.Integer(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ),
        sa.ForeignKeyConstraint(['image_id'], ['generated_images.id'], ),
        sa.ForeignKeyConstraint(['prompt_id'], ['prompt_templates.id'], ),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('user_id', 'image_id', name='unique_user_favorite_image')
    )
    op.create_index(op.f('ix_user_favorites_user_id'), 'user_favorites', ['user_id'], unique=False)

    # Add feedback columns to generated_images
    op.add_column('generated_images', sa.Column('avg_rating', sa.Float(), nullable=True))
    op.add_column('generated_images', sa.Column('total_ratings', sa.Integer(), nullable=True, server_default='0'))
    op.add_column('generated_images', sa.Column('total_favorites', sa.Integer(), nullable=True, server_default='0'))


def downgrade() -> None:
    # Remove columns from generated_images
    op.drop_column('generated_images', 'total_favorites')
    op.drop_column('generated_images', 'total_ratings')
    op.drop_column('generated_images', 'avg_rating')
    
    # Drop user_favorites table
    op.drop_table('user_favorites')
    
    # Drop prompt_templates table
    op.drop_table('prompt_templates')
    
    # Drop image_feedback table
    op.drop_table('image_feedback')