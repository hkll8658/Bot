"""Add security features and audit logs

Revision ID: 009_add_security_features
Revises: 008_add_feedback_and_ratings
Create Date: 2024-01-09 00:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '009_add_security_features'
down_revision = '008_add_feedback_and_ratings'
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Create login_attempts table
    op.create_table('login_attempts',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('username', sa.String(length=100), nullable=False),
        sa.Column('ip_address', sa.String(length=50), nullable=True),
        sa.Column('user_agent', sa.String(length=255), nullable=True),
        sa.Column('success', sa.Boolean(), nullable=True),
        sa.Column('attempted_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_login_attempts_username'), 'login_attempts', ['username'], unique=False)
    op.create_index(op.f('ix_login_attempts_ip_address'), 'login_attempts', ['ip_address'], unique=False)
    op.create_index(op.f('ix_login_attempts_attempted_at'), 'login_attempts', ['attempted_at'], unique=False)

    # Create api_keys table
    op.create_table('api_keys',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('key', sa.String(length=255), nullable=False),
        sa.Column('name', sa.String(length=100), nullable=True),
        sa.Column('user_id', sa.Integer(), nullable=True),
        sa.Column('admin_id', sa.Integer(), nullable=True),
        sa.Column('permissions', sa.JSON(), nullable=True),
        sa.Column('rate_limit', sa.Integer(), nullable=True),
        sa.Column('last_used', sa.DateTime(), nullable=True),
        sa.Column('expires_at', sa.DateTime(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('created_by', sa.Integer(), nullable=True),
        sa.Column('is_active', sa.Boolean(), nullable=True, server_default='true'),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ),
        sa.ForeignKeyConstraint(['admin_id'], ['admins.id'], ),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('key')
    )
    op.create_index(op.f('ix_api_keys_key'), 'api_keys', ['key'], unique=True)

    # Create ip_whitelist table
    op.create_table('ip_whitelist',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('ip_address', sa.String(length=50), nullable=False),
        sa.Column('description', sa.String(length=255), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('created_by', sa.Integer(), nullable=True),
        sa.Column('expires_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['created_by'], ['admins.id'], ),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('ip_address')
    )

    # Create rate_limit_rules table
    op.create_table('rate_limit_rules',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('endpoint', sa.String(length=255), nullable=False),
        sa.Column('method', sa.String(length=10), nullable=True),
        sa.Column('limit', sa.Integer(), nullable=False),
        sa.Column('window', sa.Integer(), nullable=False),  # in seconds
        sa.Column('user_type', sa.String(length=50), nullable=True),  # 'all', 'user', 'admin', 'guest'
        sa.Column('is_active', sa.Boolean(), nullable=True, server_default='true'),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )

    # Add security columns to admins table
    op.add_column('admins', sa.Column('failed_login_attempts', sa.Integer(), nullable=True, server_default='0'))
    op.add_column('admins', sa.Column('locked_until', sa.DateTime(), nullable=True))
    op.add_column('admins', sa.Column('last_login_ip', sa.String(length=50), nullable=True))
    op.add_column('admins', sa.Column('password_changed_at', sa.DateTime(), nullable=True))
    op.add_column('admins', sa.Column('password_reset_token', sa.String(length=255), nullable=True))
    op.add_column('admins', sa.Column('password_reset_expires', sa.DateTime(), nullable=True))

    # Add security columns to users table
    op.add_column('users', sa.Column('last_login_ip', sa.String(length=50), nullable=True))
    op.add_column('users', sa.Column('account_locked', sa.Boolean(), nullable=True, server_default='false'))
    op.add_column('users', sa.Column('lock_reason', sa.String(length=255), nullable=True))

    # Insert default rate limit rules
    op.execute("""
        INSERT INTO rate_limit_rules (endpoint, method, limit, window, user_type) VALUES
        ('/api/generate', 'POST', 10, 60, 'user'),
        ('/api/generate', 'POST', 100, 60, 'admin'),
        ('/api/users', 'GET', 30, 60, 'admin'),
        ('/api/login', 'POST', 5, 300, 'guest'),
        ('/api/register', 'POST', 3, 3600, 'guest'),
        ('/api/recharge', 'POST', 5, 3600, 'user')
    """)


def downgrade() -> None:
    # Remove columns from users table
    op.drop_column('users', 'lock_reason')
    op.drop_column('users', 'account_locked')
    op.drop_column('users', 'last_login_ip')
    
    # Remove columns from admins table
    op.drop_column('admins', 'password_reset_expires')
    op.drop_column('admins', 'password_reset_token')
    op.drop_column('admins', 'password_changed_at')
    op.drop_column('admins', 'last_login_ip')
    op.drop_column('admins', 'locked_until')
    op.drop_column('admins', 'failed_login_attempts')
    
    # Drop tables
    op.drop_table('rate_limit_rules')
    op.drop_table('ip_whitelist')
    op.drop_table('api_keys')
    op.drop_table('login_attempts')