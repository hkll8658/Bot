"""Add performance optimization indexes

Revision ID: 011_add_performance_indexes
Revises: 010_add_system_settings
Create Date: 2024-01-11 00:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '011_add_performance_indexes'
down_revision = '010_add_system_settings'
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Composite indexes for users table
    op.create_index('idx_users_status_credits', 'users', ['status', 'credits_balance'], unique=False)
    op.create_index('idx_users_referral_stats', 'users', ['total_referrals', 'referral_earnings'], unique=False)
    op.create_index('idx_users_joined_status', 'users', ['joined_date', 'status'], unique=False)
    
    # Composite indexes for images table
    op.create_index('idx_images_user_date', 'generated_images', ['user_id', 'generation_date'], unique=False)
    op.create_index('idx_images_style_date', 'generated_images', ['style', 'generation_date'], unique=False)
    op.create_index('idx_images_status_date', 'generated_images', ['status', 'generation_date'], unique=False)
    
    # Composite indexes for transactions table
    op.create_index('idx_transactions_user_status', 'transactions', ['user_id', 'status'], unique=False)
    op.create_index('idx_transactions_date_status', 'transactions', ['date', 'status'], unique=False)
    op.create_index('idx_transactions_amount_status', 'transactions', ['amount', 'status'], unique=False)
    
    # Composite indexes for queue table
    op.create_index('idx_queue_status_created', 'generation_queue', ['status', 'created_at'], unique=False)
    op.create_index('idx_queue_user_status', 'generation_queue', ['user_id', 'status'], unique=False)
    
    # Full text search indexes (PostgreSQL specific)
    op.execute("""
        CREATE INDEX idx_users_search ON users 
        USING gin(to_tsvector('english', coalesce(username, '') || ' ' || coalesce(first_name, '') || ' ' || coalesce(last_name, '')));
    """)
    
    op.execute("""
        CREATE INDEX idx_prompts_search ON generated_images 
        USING gin(to_tsvector('english', coalesce(prompt, '')));
    """)
    
    # Partial indexes for common queries
    op.create_index('idx_active_users', 'users', ['last_active'], 
                   unique=False, postgresql_where=sa.text("status = 'active'"))
    
    op.create_index('idx_pending_transactions', 'transactions', ['created_at'], 
                   unique=False, postgresql_where=sa.text("status = 'pending'"))
    
    op.create_index('idx_queued_jobs', 'generation_queue', ['created_at'], 
                   unique=False, postgresql_where=sa.text("status = 'queued'"))
    
    # Expression indexes
    op.create_index('idx_users_lower_username', 'users', 
                   [sa.text('lower(username)')], unique=False)
    
    op.create_index('idx_users_lower_email', 'admins', 
                   [sa.text('lower(email)')], unique=False)
    
    # BRIN indexes for time-series data (PostgreSQL)
    op.execute("CREATE INDEX idx_images_generation_date_brin ON generated_images USING brin(generation_date);")
    op.execute("CREATE INDEX idx_transactions_date_brin ON transactions USING brin(date);")
    op.execute("CREATE INDEX idx_activity_log_created_at_brin ON user_activity_log USING brin(created_at);")


def downgrade() -> None:
    # Drop BRIN indexes
    op.execute("DROP INDEX IF EXISTS idx_activity_log_created_at_brin;")
    op.execute("DROP INDEX IF EXISTS idx_transactions_date_brin;")
    op.execute("DROP INDEX IF EXISTS idx_images_generation_date_brin;")
    
    # Drop expression indexes
    op.drop_index('idx_users_lower_email', table_name='admins')
    op.drop_index('idx_users_lower_username', table_name='users')
    
    # Drop partial indexes
    op.drop_index('idx_queued_jobs', table_name='generation_queue')
    op.drop_index('idx_pending_transactions', table_name='transactions')
    op.drop_index('idx_active_users', table_name='users')
    
    # Drop full text search indexes
    op.execute("DROP INDEX IF EXISTS idx_prompts_search;")
    op.execute("DROP INDEX IF EXISTS idx_users_search;")
    
    # Drop composite indexes
    op.drop_index('idx_queue_user_status', table_name='generation_queue')
    op.drop_index('idx_queue_status_created', table_name='generation_queue')
    op.drop_index('idx_transactions_amount_status', table_name='transactions')
    op.drop_index('idx_transactions_date_status', table_name='transactions')
    op.drop_index('idx_transactions_user_status', table_name='transactions')
    op.drop_index('idx_images_status_date', table_name='generated_images')
    op.drop_index('idx_images_style_date', table_name='generated_images')
    op.drop_index('idx_images_user_date', table_name='generated_images')
    op.drop_index('idx_users_joined_status', table_name='users')
    op.drop_index('idx_users_referral_stats', table_name='users')
    op.drop_index('idx_users_status_credits', table_name='users')