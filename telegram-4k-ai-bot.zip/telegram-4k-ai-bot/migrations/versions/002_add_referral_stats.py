"""Add referral statistics and user stats

Revision ID: 002_add_referral_stats
Revises: 001_initial_migration
Create Date: 2024-01-02 00:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '002_add_referral_stats'
down_revision = '001_initial_migration'
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Add referral stats columns to users table
    op.add_column('users', sa.Column('total_referrals', sa.Integer(), nullable=True, server_default='0'))
    op.add_column('users', sa.Column('referral_earnings', sa.Integer(), nullable=True, server_default='0'))
    op.add_column('users', sa.Column('last_referral_date', sa.DateTime(), nullable=True))
    
    # Add user stats columns
    op.add_column('users', sa.Column('total_spent', sa.Float(), nullable=True, server_default='0'))
    op.add_column('users', sa.Column('avg_rating', sa.Float(), nullable=True))
    op.add_column('users', sa.Column('total_feedback_count', sa.Integer(), nullable=True, server_default='0'))
    
    # Create referrals table for tracking
    op.create_table('referrals',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('referrer_id', sa.Integer(), nullable=False),
        sa.Column('referred_id', sa.Integer(), nullable=False),
        sa.Column('referral_date', sa.DateTime(), nullable=True),
        sa.Column('bonus_credits', sa.Integer(), nullable=True),
        sa.Column('status', sa.String(length=50), nullable=True, server_default='pending'),
        sa.Column('converted_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['referrer_id'], ['users.id'], ),
        sa.ForeignKeyConstraint(['referred_id'], ['users.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_referrals_referrer_id'), 'referrals', ['referrer_id'], unique=False)
    op.create_index(op.f('ix_referrals_referred_id'), 'referrals', ['referred_id'], unique=True)
    op.create_index(op.f('ix_referrals_status'), 'referrals', ['status'], unique=False)
    
    # Add daily bonus tracking
    op.create_table('daily_bonus',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('claim_date', sa.Date(), nullable=False),
        sa.Column('credits_earned', sa.Integer(), nullable=True),
        sa.Column('streak_day', sa.Integer(), nullable=True),
        sa.Column('claimed_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('user_id', 'claim_date', name='unique_daily_claim')
    )
    op.create_index(op.f('ix_daily_bonus_user_id'), 'daily_bonus', ['user_id'], unique=False)
    op.create_index(op.f('ix_daily_bonus_claim_date'), 'daily_bonus', ['claim_date'], unique=False)


def downgrade() -> None:
    # Drop daily_bonus table
    op.drop_table('daily_bonus')
    
    # Drop referrals table
    op.drop_table('referrals')
    
    # Remove columns from users table
    op.drop_column('users', 'total_feedback_count')
    op.drop_column('users', 'avg_rating')
    op.drop_column('users', 'total_spent')
    op.drop_column('users', 'last_referral_date')
    op.drop_column('users', 'referral_earnings')
    op.drop_column('users', 'total_referrals')