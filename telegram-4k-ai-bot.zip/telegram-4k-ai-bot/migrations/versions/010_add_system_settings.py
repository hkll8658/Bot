"""Add system settings and configuration tables

Revision ID: 010_add_system_settings
Revises: 009_add_security_features
Create Date: 2024-01-10 00:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '010_add_system_settings'
down_revision = '009_add_security_features'
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Create system_settings table
    op.create_table('system_settings',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('key', sa.String(length=100), nullable=False),
        sa.Column('value', sa.JSON(), nullable=True),
        sa.Column('type', sa.String(length=50), nullable=True),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('category', sa.String(length=50), nullable=True),
        sa.Column('is_public', sa.Boolean(), nullable=True, server_default='false'),
        sa.Column('is_encrypted', sa.Boolean(), nullable=True, server_default='false'),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('updated_at', sa.DateTime(), nullable=True),
        sa.Column('updated_by', sa.Integer(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('key')
    )
    op.create_index(op.f('ix_system_settings_key'), 'system_settings', ['key'], unique=True)
    op.create_index(op.f('ix_system_settings_category'), 'system_settings', ['category'], unique=False)

    # Create maintenance_logs table
    op.create_table('maintenance_logs',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('type', sa.String(length=50), nullable=False),
        sa.Column('status', sa.String(length=50), nullable=True),
        sa.Column('message', sa.Text(), nullable=True),
        sa.Column('started_at', sa.DateTime(), nullable=True),
        sa.Column('completed_at', sa.DateTime(), nullable=True),
        sa.Column('performed_by', sa.Integer(), nullable=True),
        sa.Column('details', sa.JSON(), nullable=True),
        sa.ForeignKeyConstraint(['performed_by'], ['admins.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_maintenance_logs_type'), 'maintenance_logs', ['type'], unique=False)
    op.create_index(op.f('ix_maintenance_logs_started_at'), 'maintenance_logs', ['started_at'], unique=False)

    # Create feature_flags table
    op.create_table('feature_flags',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('name', sa.String(length=100), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('enabled', sa.Boolean(), nullable=True, server_default='false'),
        sa.Column('percentage', sa.Integer(), nullable=True),  # For gradual rollout (0-100)
        sa.Column('user_ids', sa.JSON(), nullable=True),  # Specific users for beta testing
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('updated_at', sa.DateTime(), nullable=True),
        sa.Column('created_by', sa.Integer(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('name')
    )
    op.create_index(op.f('ix_feature_flags_name'), 'feature_flags', ['name'], unique=True)

    # Create cache_stats table for monitoring
    op.create_table('cache_stats',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('cache_key', sa.String(length=255), nullable=False),
        sa.Column('hits', sa.Integer(), nullable=True, server_default='0'),
        sa.Column('misses', sa.Integer(), nullable=True, server_default='0'),
        sa.Column('last_accessed', sa.DateTime(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('cache_key')
    )

    # Insert default system settings
    op.execute("""
        INSERT INTO system_settings (key, value, type, description, category, is_public) VALUES
        ('site_name', '"AI Image Generator"', 'string', 'Site name', 'general', true),
        ('site_description', '"Ultra 4K AI Image Generation Bot"', 'string', 'Site description', 'general', true),
        ('contact_email', '"support@example.com"', 'string', 'Contact email', 'general', true),
        ('max_upload_size', '10485760', 'integer', 'Maximum upload size in bytes', 'limits', false),
        ('session_timeout', '3600', 'integer', 'Session timeout in seconds', 'security', false),
        ('maintenance_mode', 'false', 'boolean', 'Maintenance mode status', 'system', false),
        ('maintenance_message', '"System under maintenance"', 'string', 'Maintenance mode message', 'system', true),
        ('default_language', '"en"', 'string', 'Default language', 'localization', true),
        ('timezone', '"UTC"', 'string', 'Default timezone', 'localization', true),
        ('currency', '"INR"', 'string', 'Default currency', 'payment', true),
        ('tax_rate', '0.18', 'float', 'Tax rate (GST)', 'payment', false),
        ('enable_referrals', 'true', 'boolean', 'Enable referral system', 'features', true),
        ('enable_daily_bonus', 'false', 'boolean', 'Enable daily login bonus', 'features', true),
        ('enable_nsfw_filter', 'true', 'boolean', 'Enable NSFW content filter', 'moderation', true),
        ('max_concurrent_generations', '5', 'integer', 'Maximum concurrent image generations', 'limits', false),
        ('queue_timeout', '300', 'integer', 'Queue timeout in seconds', 'limits', false),
        ('api_rate_limit', '60', 'integer', 'API rate limit per minute', 'security', false),
        ('backup_frequency', '"daily"', 'string', 'Backup frequency', 'system', false),
        ('retention_days', '30', 'integer', 'Data retention period in days', 'system', false)
    """)

    # Insert default feature flags
    op.execute("""
        INSERT INTO feature_flags (name, description, enabled, percentage) VALUES
        ('new_ui', 'New user interface design', false, 0),
        ('batch_generation', 'Batch image generation', false, 0),
        ('image_variations', 'Generate image variations', true, 100),
        ('prompt_templates', 'Prompt templates library', true, 100),
        ('api_access', 'API access for users', false, 0),
        ('subscriptions', 'Subscription plans', false, 0),
        ('white_label', 'White label branding', false, 0),
        ('analytics_dashboard', 'Advanced analytics', true, 100)
    """)


def downgrade() -> None:
    # Drop tables in reverse order
    op.drop_table('cache_stats')
    op.drop_table('feature_flags')
    op.drop_table('maintenance_logs')
    op.drop_table('system_settings')