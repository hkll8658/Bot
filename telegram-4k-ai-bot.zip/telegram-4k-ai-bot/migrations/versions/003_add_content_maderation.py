"""Add content moderation tables

Revision ID: 003_add_content_moderation
Revises: 002_add_referral_stats
Create Date: 2024-01-03 00:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '003_add_content_moderation'
down_revision = '002_add_referral_stats'
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Create banned_words table
    op.create_table('banned_words',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('word', sa.String(length=100), nullable=False),
        sa.Column('category', sa.String(length=50), nullable=True),
        sa.Column('severity', sa.Integer(), nullable=True, server_default='1'),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('created_by', sa.Integer(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('word')
    )
    op.create_index(op.f('ix_banned_words_word'), 'banned_words', ['word'], unique=True)
    
    # Create moderation_log table
    op.create_table('moderation_log',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('content_type', sa.String(length=50), nullable=True),
        sa.Column('content', sa.Text(), nullable=True),
        sa.Column('matched_words', sa.JSON(), nullable=True),
        sa.Column('action_taken', sa.String(length=50), nullable=True),
        sa.Column('moderated_at', sa.DateTime(), nullable=True),
        sa.Column('moderated_by', sa.String(length=50), nullable=True),  # 'auto' or admin username
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_moderation_log_user_id'), 'moderation_log', ['user_id'], unique=False)
    op.create_index(op.f('ix_moderation_log_moderated_at'), 'moderation_log', ['moderated_at'], unique=False)
    
    # Add moderation columns to users table
    op.add_column('users', sa.Column('warning_count', sa.Integer(), nullable=True, server_default='0'))
    op.add_column('users', sa.Column('last_warning_date', sa.DateTime(), nullable=True))
    op.add_column('users', sa.Column('moderation_notes', sa.Text(), nullable=True))
    
    # Create content_reports table
    op.create_table('content_reports',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('reporter_id', sa.Integer(), nullable=False),
        sa.Column('reported_user_id', sa.Integer(), nullable=False),
        sa.Column('image_id', sa.String(length=100), nullable=True),
        sa.Column('reason', sa.String(length=255), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('status', sa.String(length=50), nullable=True, server_default='pending'),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('resolved_at', sa.DateTime(), nullable=True),
        sa.Column('resolved_by', sa.Integer(), nullable=True),
        sa.Column('resolution_notes', sa.Text(), nullable=True),
        sa.ForeignKeyConstraint(['reporter_id'], ['users.id'], ),
        sa.ForeignKeyConstraint(['reported_user_id'], ['users.id'], ),
        sa.ForeignKeyConstraint(['resolved_by'], ['admins.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_content_reports_status'), 'content_reports', ['status'], unique=False)
    op.create_index(op.f('ix_content_reports_created_at'), 'content_reports', ['created_at'], unique=False)


def downgrade() -> None:
    # Drop content_reports table
    op.drop_table('content_reports')
    
    # Remove columns from users table
    op.drop_column('users', 'moderation_notes')
    op.drop_column('users', 'last_warning_date')
    op.drop_column('users', 'warning_count')
    
    # Drop moderation_log table
    op.drop_table('moderation_log')
    
    # Drop banned_words table
    op.drop_table('banned_words')