"""Add table partitioning for large tables

Revision ID: 012_add_partitioning
Revises: 011_add_performance_indexes
Create Date: 2024-01-12 00:00:00.000000

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision = '012_add_partitioning'
down_revision = '011_add_performance_indexes'
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Note: This migration is PostgreSQL specific
    connection = op.get_bind()
    if connection.dialect.name == 'postgresql':
        
        # Create partitioned tables
        op.execute("""
            -- Create partitioned images table by month
            CREATE TABLE generated_images_partitioned (
                LIKE generated_images INCLUDING DEFAULTS INCLUDING CONSTRAINTS
            ) PARTITION BY RANGE (generation_date);
            
            -- Create partitions for last 3 months and future
            CREATE TABLE generated_images_202401 PARTITION OF generated_images_partitioned
                FOR VALUES FROM ('2024-01-01') TO ('2024-02-01');
            CREATE TABLE generated_images_202402 PARTITION OF generated_images_partitioned
                FOR VALUES FROM ('2024-02-01') TO ('2024-03-01');
            CREATE TABLE generated_images_202403 PARTITION OF generated_images_partitioned
                FOR VALUES FROM ('2024-03-01') TO ('2024-04-01');
            CREATE TABLE generated_images_future PARTITION OF generated_images_partitioned
                FOR VALUES FROM ('2024-04-01') TO ('2025-01-01');
            CREATE TABLE generated_images_archive PARTITION OF generated_images_partitioned
                FOR VALUES FROM ('1900-01-01') TO ('2024-01-01');
        """)
        
        op.execute("""
            -- Create partitioned transactions table by month
            CREATE TABLE transactions_partitioned (
                LIKE transactions INCLUDING DEFAULTS INCLUDING CONSTRAINTS
            ) PARTITION BY RANGE (date);
            
            CREATE TABLE transactions_202401 PARTITION OF transactions_partitioned
                FOR VALUES FROM ('2024-01-01') TO ('2024-02-01');
            CREATE TABLE transactions_202402 PARTITION OF transactions_partitioned
                FOR VALUES FROM ('2024-02-01') TO ('2024-03-01');
            CREATE TABLE transactions_202403 PARTITION OF transactions_partitioned
                FOR VALUES FROM ('2024-03-01') TO ('2024-04-01');
            CREATE TABLE transactions_future PARTITION OF transactions_partitioned
                FOR VALUES FROM ('2024-04-01') TO ('2025-01-01');
            CREATE TABLE transactions_archive PARTITION OF transactions_partitioned
                FOR VALUES FROM ('1900-01-01') TO ('2024-01-01');
        """)
        
        op.execute("""
            -- Create partitioned activity logs by month
            CREATE TABLE user_activity_log_partitioned (
                LIKE user_activity_log INCLUDING DEFAULTS INCLUDING CONSTRAINTS
            ) PARTITION BY RANGE (created_at);
            
            CREATE TABLE user_activity_log_202401 PARTITION OF user_activity_log_partitioned
                FOR VALUES FROM ('2024-01-01') TO ('2024-02-01');
            CREATE TABLE user_activity_log_202402 PARTITION OF user_activity_log_partitioned
                FOR VALUES FROM ('2024-02-01') TO ('2024-03-01');
            CREATE TABLE user_activity_log_202403 PARTITION OF user_activity_log_partitioned
                FOR VALUES FROM ('2024-03-01') TO ('2024-04-01');
            CREATE TABLE user_activity_log_future PARTITION OF user_activity_log_partitioned
                FOR VALUES FROM ('2024-04-01') TO ('2025-01-01');
            CREATE TABLE user_activity_log_archive PARTITION OF user_activity_log_partitioned
                FOR VALUES FROM ('1900-01-01') TO ('2024-01-01');
        """)
        
        # Create functions for automatic partition management
        op.execute("""
            CREATE OR REPLACE FUNCTION create_next_month_partitions()
            RETURNS void AS $$
            DECLARE
                next_month date;
                partition_name text;
                table_name text;
                tables text[] := ARRAY['generated_images', 'transactions', 'user_activity_log'];
            BEGIN
                next_month := date_trunc('month', CURRENT_DATE + interval '1 month');
                
                FOREACH table_name IN ARRAY tables
                LOOP
                    partition_name := table_name || '_' || to_char(next_month, 'YYYYMM');
                    
                    EXECUTE format('
                        CREATE TABLE IF NOT EXISTS %I PARTITION OF %I_partitioned
                        FOR VALUES FROM (%L) TO (%L)',
                        partition_name,
                        table_name,
                        next_month,
                        next_month + interval '1 month'
                    );
                END LOOP;
            END;
            $$ LANGUAGE plpgsql;
        """)
        
        op.execute("""
            CREATE OR REPLACE FUNCTION archive_old_partitions(months INTEGER)
            RETURNS void AS $$
            DECLARE
                cutoff_date date;
                partition_name text;
                table_name text;
                tables text[] := ARRAY['generated_images', 'transactions', 'user_activity_log'];
            BEGIN
                cutoff_date := date_trunc('month', CURRENT_DATE - (months || ' months')::interval);
                
                FOREACH table_name IN ARRAY tables
                LOOP
                    -- Detach old partition and attach to archive
                    EXECUTE format('
                        ALTER TABLE %I_partitioned DETACH PARTITION %I_%s;
                        ALTER TABLE %I_partitioned ATTACH PARTITION %I_archive
                        FOR VALUES FROM (%L) TO (%L);',
                        table_name,
                        table_name,
                        to_char(cutoff_date, 'YYYYMM'),
                        table_name,
                        table_name,
                        '1900-01-01',
                        cutoff_date
                    );
                END LOOP;
            END;
            $$ LANGUAGE plpgsql;
        """)


def downgrade() -> None:
    connection = op.get_bind()
    if connection.dialect.name == 'postgresql':
        # Drop functions
        op.execute("DROP FUNCTION IF EXISTS archive_old_partitions(INTEGER);")
        op.execute("DROP FUNCTION IF EXISTS create_next_month_partitions();")
        
        # Drop partitioned tables
        op.execute("DROP TABLE IF EXISTS user_activity_log_partitioned CASCADE;")
        op.execute("DROP TABLE IF EXISTS transactions_partitioned CASCADE;")
        op.execute("DROP TABLE IF EXISTS generated_images_partitioned CASCADE;")