"""Add analytics and logging tables

Revision ID: 005_add_analytics_tables
Revises: 004_add_payment_logs
Create Date: 2024-01-05 00:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '005_add_analytics_tables'
down_revision = '004_add_payment_logs'
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Create user_activity_log table
    op.create_table('user_activity_log',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('activity_type', sa.String(length=50), nullable=False),  # 'login', 'generate', 'recharge', etc.
        sa.Column('details', sa.JSON(), nullable=True),
        sa.Column('ip_address', sa.String(length=50), nullable=True),
        sa.Column('user_agent', sa.String(length=255), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_user_activity_log_user_id'), 'user_activity_log', ['user_id'], unique=False)
    op.create_index(op.f('ix_user_activity_log_activity_type'), 'user_activity_log', ['activity_type'], unique=False)
    op.create_index(op.f('ix_user_activity_log_created_at'), 'user_activity_log', ['created_at'], unique=False)

    # Create admin_activity_log table
    op.create_table('admin_activity_log',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('admin_id', sa.Integer(), nullable=False),
        sa.Column('action', sa.String(length=100), nullable=False),
        sa.Column('resource_type', sa.String(length=50), nullable=True),
        sa.Column('resource_id', sa.String(length=100), nullable=True),
        sa.Column('details', sa.JSON(), nullable=True),
        sa.Column('ip_address', sa.String(length=50), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['admin_id'], ['admins.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_admin_activity_log_admin_id'), 'admin_activity_log', ['admin_id'], unique=False)
    op.create_index(op.f('ix_admin_activity_log_action'), 'admin_activity_log', ['action'], unique=False)
    op.create_index(op.f('ix_admin_activity_log_created_at'), 'admin_activity_log', ['created_at'], unique=False)

    # Create api_usage_log table
    op.create_table('api_usage_log',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('api_key', sa.String(length=255), nullable=True),
        sa.Column('endpoint', sa.String(length=255), nullable=False),
        sa.Column('method', sa.String(length=10), nullable=True),
        sa.Column('response_time', sa.Float(), nullable=True),
        sa.Column('status_code', sa.Integer(), nullable=True),
        sa.Column('ip_address', sa.String(length=50), nullable=True),
        sa.Column('user_id', sa.Integer(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_api_usage_log_endpoint'), 'api_usage_log', ['endpoint'], unique=False)
    op.create_index(op.f('ix_api_usage_log_created_at'), 'api_usage_log', ['created_at'], unique=False)

    # Create daily_stats table for aggregated analytics
    op.create_table('daily_stats',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('date', sa.Date(), nullable=False),
        sa.Column('bot_instance_id', sa.Integer(), nullable=True),
        sa.Column('new_users', sa.Integer(), nullable=True, server_default='0'),
        sa.Column('active_users', sa.Integer(), nullable=True, server_default='0'),
        sa.Column('total_images', sa.Integer(), nullable=True, server_default='0'),
        sa.Column('total_revenue', sa.Float(), nullable=True, server_default='0'),
        sa.Column('total_credits_sold', sa.Integer(), nullable=True, server_default='0'),
        sa.Column('total_transactions', sa.Integer(), nullable=True, server_default='0'),
        sa.Column('popular_styles', sa.JSON(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['bot_instance_id'], ['bot_instances.id'], ),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('date', 'bot_instance_id', name='unique_daily_stats')
    )
    op.create_index(op.f('ix_daily_stats_date'), 'daily_stats', ['date'], unique=False)

    # Create error_logs table
    op.create_table('error_logs',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('error_type', sa.String(length=100), nullable=False),
        sa.Column('error_message', sa.Text(), nullable=True),
        sa.Column('traceback', sa.Text(), nullable=True),
        sa.Column('user_id', sa.Integer(), nullable=True),
        sa.Column('admin_id', sa.Integer(), nullable=True),
        sa.Column('url', sa.String(length=500), nullable=True),
        sa.Column('method', sa.String(length=10), nullable=True),
        sa.Column('ip_address', sa.String(length=50), nullable=True),
        sa.Column('user_agent', sa.String(length=255), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('resolved', sa.Boolean(), nullable=True, server_default='false'),
        sa.Column('resolved_at', sa.DateTime(), nullable=True),
        sa.Column('resolved_by', sa.Integer(), nullable=True),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ),
        sa.ForeignKeyConstraint(['admin_id'], ['admins.id'], ),
        sa.ForeignKeyConstraint(['resolved_by'], ['admins.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_error_logs_error_type'), 'error_logs', ['error_type'], unique=False)
    op.create_index(op.f('ix_error_logs_created_at'), 'error_logs', ['created_at'], unique=False)
    op.create_index(op.f('ix_error_logs_resolved'), 'error_logs', ['resolved'], unique=False)


def downgrade() -> None:
    # Drop tables in reverse order
    op.drop_table('error_logs')
    op.drop_table('daily_stats')
    op.drop_table('api_usage_log')
    op.drop_table('admin_activity_log')
    op.drop_table('user_activity_log')