"""Add subscription tiers and premium features

Revision ID: 007_add_subscription_tiers
Revises: 006_add_notifications_tables
Create Date: 2024-01-07 00:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '007_add_subscription_tiers'
down_revision = '006_add_notifications_tables'
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Create subscription_tiers table
    op.create_table('subscription_tiers',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('name', sa.String(length=50), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('price_monthly', sa.Float(), nullable=True),
        sa.Column('price_yearly', sa.Float(), nullable=True),
        sa.Column('credits_per_month', sa.Integer(), nullable=True),
        sa.Column('features', sa.JSON(), nullable=True),
        sa.Column('limits', sa.JSON(), nullable=True),
        sa.Column('is_active', sa.Boolean(), nullable=True, server_default='true'),
        sa.Column('sort_order', sa.Integer(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('name')
    )

    # Create user_subscriptions table
    op.create_table('user_subscriptions',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('tier_id', sa.Integer(), nullable=False),
        sa.Column('status', sa.String(length=50), nullable=True, server_default='active'),
        sa.Column('start_date', sa.DateTime(), nullable=False),
        sa.Column('end_date', sa.DateTime(), nullable=True),
        sa.Column('renewal_date', sa.DateTime(), nullable=True),
        sa.Column('payment_method', sa.String(length=50), nullable=True),
        sa.Column('auto_renew', sa.Boolean(), nullable=True, server_default='true'),
        sa.Column('cancelled_at', sa.DateTime(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('updated_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ),
        sa.ForeignKeyConstraint(['tier_id'], ['subscription_tiers.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_user_subscriptions_user_id'), 'user_subscriptions', ['user_id'], unique=False)
    op.create_index(op.f('ix_user_subscriptions_status'), 'user_subscriptions', ['status'], unique=False)
    op.create_index(op.f('ix_user_subscriptions_end_date'), 'user_subscriptions', ['end_date'], unique=False)

    # Create subscription_payments table
    op.create_table('subscription_payments',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('subscription_id', sa.Integer(), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('amount', sa.Float(), nullable=False),
        sa.Column('currency', sa.String(length=10), nullable=True, server_default='INR'),
        sa.Column('payment_method', sa.String(length=50), nullable=True),
        sa.Column('transaction_id', sa.String(length=100), nullable=True),
        sa.Column('status', sa.String(length=50), nullable=True, server_default='pending'),
        sa.Column('period_start', sa.DateTime(), nullable=True),
        sa.Column('period_end', sa.DateTime(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('paid_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['subscription_id'], ['user_subscriptions.id'], ),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('transaction_id')
    )
    op.create_index(op.f('ix_subscription_payments_status'), 'subscription_payments', ['status'], unique=False)
    op.create_index(op.f('ix_subscription_payments_created_at'), 'subscription_payments', ['created_at'], unique=False)

    # Add subscription-related columns to users table
    op.add_column('users', sa.Column('subscription_tier', sa.String(length=50), nullable=True))
    op.add_column('users', sa.Column('subscription_expiry', sa.DateTime(), nullable=True))
    op.add_column('users', sa.Column('is_premium', sa.Boolean(), nullable=True, server_default='false'))

    # Insert default subscription tiers
    op.execute("""
        INSERT INTO subscription_tiers (name, description, price_monthly, price_yearly, credits_per_month, features, sort_order) VALUES
        ('Free', 'Basic access with limited features', 0, 0, 50, '{"max_resolution": "1024x1024", "styles": 5, "queue_priority": "low"}', 1),
        ('Basic', 'Enhanced features for casual users', 199, 1990, 200, '{"max_resolution": "1920x1080", "styles": 10, "queue_priority": "normal", "support": "email"}', 2),
        ('Premium', 'Full access for power users', 499, 4990, 500, '{"max_resolution": "3840x2160", "styles": "all", "queue_priority": "high", "support": "priority", "api_access": true}', 3),
        ('Enterprise', 'Custom solutions for businesses', 1999, 19990, 2000, '{"max_resolution": "7680x4320", "styles": "all", "queue_priority": "highest", "support": "dedicated", "api_access": true, "white_label": true}', 4)
    """)


def downgrade() -> None:
    # Drop subscription_payments table
    op.drop_table('subscription_payments')
    
    # Drop user_subscriptions table
    op.drop_table('user_subscriptions')
    
    # Drop subscription_tiers table
    op.drop_table('subscription_tiers')
    
    # Remove columns from users table
    op.drop_column('users', 'is_premium')
    op.drop_column('users', 'subscription_expiry')
    op.drop_column('users', 'subscription_tier')