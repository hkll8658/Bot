-- =====================================================
-- ULTRA 4K AI IMAGE GENERATOR BOT
-- Complete Database Schema
-- Database: xyzcpan2_Xyz
-- User: xyzcpan2_Xyz
-- Host: localhost:5432
-- =====================================================

-- =====================================================
-- STEP 1: CONNECT TO YOUR DATABASE
-- =====================================================
/*
Run this command in terminal to connect:
psql -h localhost -p 5432 -U xyzcpan2_Xyz -d xyzcpan2_Xyz

Enter password when prompted: 2J5LaNGVEmHp98MusUMs
*/

-- =====================================================
-- STEP 2: RUN THIS ENTIRE SCRIPT
-- =====================================================
-- Copy everything below and paste in psql after connecting

-- =====================================================
-- ENABLE EXTENSIONS (Required for UUID and other features)
-- =====================================================
-- Note: If you don't have superuser privileges, ask your hosting provider
-- to enable these extensions for you

-- CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
-- CREATE EXTENSION IF NOT EXISTS "pgcrypto";
-- CREATE EXTENSION IF NOT EXISTS "citext";

-- =====================================================
-- OWNERS TABLE (Super Admin)
-- =====================================================

DROP TABLE IF EXISTS owners CASCADE;
CREATE TABLE owners (
    id SERIAL PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    email VARCHAR(255),
    master_key VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP WITH TIME ZONE,
    settings JSONB DEFAULT '{}'::jsonb
);

-- =====================================================
-- BOT INSTANCES TABLE
-- =====================================================

DROP TABLE IF EXISTS bot_instances CASCADE;
CREATE TABLE bot_instances (
    id SERIAL PRIMARY KEY,
    bot_token VARCHAR(255) UNIQUE NOT NULL,
    bot_username VARCHAR(100),
    owner_id INTEGER REFERENCES owners(id) ON DELETE SET NULL,
    admin_id INTEGER,
    razorpay_key VARCHAR(255),
    razorpay_secret VARCHAR(255),
    api_endpoint VARCHAR(500),
    api_key VARCHAR(500),
    status VARCHAR(50) DEFAULT 'inactive',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    config JSONB DEFAULT '{}'::jsonb,
    last_active TIMESTAMP WITH TIME ZONE,
    total_users INTEGER DEFAULT 0,
    total_images INTEGER DEFAULT 0,
    total_revenue DECIMAL(10,2) DEFAULT 0
);

-- =====================================================
-- ADMINS TABLE
-- =====================================================

DROP TABLE IF EXISTS admins CASCADE;
CREATE TABLE admins (
    id SERIAL PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    email VARCHAR(255),
    role VARCHAR(50) DEFAULT 'admin',
    bot_instance_id INTEGER REFERENCES bot_instances(id) ON DELETE SET NULL,
    permissions JSONB DEFAULT '{"manage_users": true, "manage_credits": true, "broadcast": true, "view_analytics": true}'::jsonb,
    two_factor_secret VARCHAR(255),
    two_factor_enabled BOOLEAN DEFAULT FALSE,
    last_login TIMESTAMP WITH TIME ZONE,
    last_login_ip INET,
    failed_login_attempts INTEGER DEFAULT 0,
    locked_until TIMESTAMP WITH TIME ZONE,
    password_changed_at TIMESTAMP WITH TIME ZONE,
    password_reset_token VARCHAR(255),
    password_reset_expires TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    created_by INTEGER,
    status VARCHAR(50) DEFAULT 'active'
);

-- =====================================================
-- USERS TABLE (Main user data)
-- =====================================================

DROP TABLE IF EXISTS users CASCADE;
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    telegram_id VARCHAR(100) UNIQUE NOT NULL,
    bot_instance_id INTEGER REFERENCES bot_instances(id) ON DELETE CASCADE,
    username VARCHAR(100),
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    credits_balance DECIMAL(10,2) DEFAULT 0,
    total_generated INTEGER DEFAULT 0,
    joined_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    last_active TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(50) DEFAULT 'active',
    referred_by VARCHAR(100),
    referral_code VARCHAR(50) UNIQUE,
    preferences JSONB DEFAULT '{
        "default_style": "realistic",
        "default_ratio": "16:9",
        "notifications": true,
        "save_history": true,
        "nsfw_filter": true
    }'::jsonb,
    total_referrals INTEGER DEFAULT 0,
    referral_earnings INTEGER DEFAULT 0,
    last_referral_date TIMESTAMP WITH TIME ZONE,
    total_spent DECIMAL(10,2) DEFAULT 0,
    avg_rating DECIMAL(3,2),
    total_feedback_count INTEGER DEFAULT 0,
    warning_count INTEGER DEFAULT 0,
    last_warning_date TIMESTAMP WITH TIME ZONE,
    moderation_notes TEXT,
    last_login_ip INET,
    account_locked BOOLEAN DEFAULT FALSE,
    lock_reason VARCHAR(255),
    subscription_tier VARCHAR(50) DEFAULT 'free',
    subscription_expiry TIMESTAMP WITH TIME ZONE,
    is_premium BOOLEAN DEFAULT FALSE
);

-- =====================================================
-- GENERATED IMAGES TABLE
-- =====================================================

DROP TABLE IF EXISTS generated_images CASCADE;
CREATE TABLE generated_images (
    id SERIAL PRIMARY KEY,
    image_id VARCHAR(100) UNIQUE DEFAULT 'img_' || floor(random() * 1000000)::text,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    prompt TEXT NOT NULL,
    negative_prompt TEXT,
    style VARCHAR(100) DEFAULT 'realistic',
    resolution VARCHAR(50) DEFAULT '3840x2160',
    aspect_ratio VARCHAR(20) DEFAULT '16:9',
    generation_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    cost INTEGER DEFAULT 10,
    image_url VARCHAR(500),
    thumbnail_url VARCHAR(500),
    status VARCHAR(50) DEFAULT 'completed',
    metadata JSONB DEFAULT '{}'::jsonb,
    avg_rating DECIMAL(3,2),
    total_ratings INTEGER DEFAULT 0,
    total_favorites INTEGER DEFAULT 0,
    processing_time INTEGER,
    model_used VARCHAR(100),
    seed INTEGER,
    guidance_scale DECIMAL(4,2)
);

-- =====================================================
-- TRANSACTIONS TABLE
-- =====================================================

DROP TABLE IF EXISTS transactions CASCADE;
CREATE TABLE transactions (
    id SERIAL PRIMARY KEY,
    transaction_id VARCHAR(100) UNIQUE DEFAULT 'txn_' || floor(random() * 1000000)::text,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    amount DECIMAL(10,2) NOT NULL,
    credits INTEGER NOT NULL,
    payment_method VARCHAR(50),
    status VARCHAR(50) DEFAULT 'pending',
    razorpay_payment_id VARCHAR(100),
    razorpay_order_id VARCHAR(100),
    refund_id VARCHAR(100),
    refund_amount DECIMAL(10,2),
    refund_date TIMESTAMP WITH TIME ZONE,
    refund_reason TEXT,
    date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    metadata JSONB DEFAULT '{}'::jsonb,
    invoice_number VARCHAR(50),
    tax_amount DECIMAL(10,2),
    currency VARCHAR(10) DEFAULT 'INR'
);

-- =====================================================
-- GENERATION QUEUE TABLE
-- =====================================================

DROP TABLE IF EXISTS generation_queue CASCADE;
CREATE TABLE generation_queue (
    id SERIAL PRIMARY KEY,
    queue_id VARCHAR(100) UNIQUE DEFAULT 'queue_' || floor(random() * 1000000)::text,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    prompt TEXT NOT NULL,
    parameters JSONB NOT NULL DEFAULT '{}'::jsonb,
    status VARCHAR(50) DEFAULT 'queued',
    priority INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    started_at TIMESTAMP WITH TIME ZONE,
    completed_at TIMESTAMP WITH TIME ZONE,
    result_url VARCHAR(500),
    thumbnail_url VARCHAR(500),
    error TEXT,
    retry_count INTEGER DEFAULT 0,
    processing_node VARCHAR(100),
    estimated_time INTEGER
);

-- =====================================================
-- REFERRALS TABLE
-- =====================================================

DROP TABLE IF EXISTS referrals CASCADE;
CREATE TABLE referrals (
    id SERIAL PRIMARY KEY,
    referrer_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    referred_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    referral_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    bonus_credits INTEGER DEFAULT 10,
    status VARCHAR(50) DEFAULT 'completed',
    converted_at TIMESTAMP WITH TIME ZONE,
    ip_address INET,
    UNIQUE(referrer_id, referred_id)
);

-- =====================================================
-- DAILY BONUS TABLE
-- =====================================================

DROP TABLE IF EXISTS daily_bonus CASCADE;
CREATE TABLE daily_bonus (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    claim_date DATE NOT NULL,
    credits_earned INTEGER DEFAULT 1,
    streak_day INTEGER DEFAULT 1,
    claimed_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, claim_date)
);

-- =====================================================
-- BANNED WORDS TABLE
-- =====================================================

DROP TABLE IF EXISTS banned_words CASCADE;
CREATE TABLE banned_words (
    id SERIAL PRIMARY KEY,
    word VARCHAR(100) UNIQUE NOT NULL,
    category VARCHAR(50),
    severity INTEGER DEFAULT 1,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    created_by INTEGER REFERENCES admins(id),
    is_active BOOLEAN DEFAULT TRUE
);

-- =====================================================
-- MODERATION LOG TABLE
-- =====================================================

DROP TABLE IF EXISTS moderation_log CASCADE;
CREATE TABLE moderation_log (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    content_type VARCHAR(50),
    content TEXT,
    matched_words JSONB,
    action_taken VARCHAR(50),
    moderated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    moderated_by VARCHAR(50)
);

-- =====================================================
-- NOTIFICATIONS TABLE
-- =====================================================

DROP TABLE IF EXISTS notifications CASCADE;
CREATE TABLE notifications (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type VARCHAR(50) NOT NULL,
    title VARCHAR(255),
    message TEXT NOT NULL,
    data JSONB,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    read_at TIMESTAMP WITH TIME ZONE
);

-- =====================================================
-- ANNOUNCEMENTS TABLE
-- =====================================================

DROP TABLE IF EXISTS announcements CASCADE;
CREATE TABLE announcements (
    id SERIAL PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    type VARCHAR(50) DEFAULT 'info',
    target_audience VARCHAR(50) DEFAULT 'all',
    filters JSONB,
    media_url VARCHAR(500),
    button_text VARCHAR(100),
    button_url VARCHAR(500),
    scheduled_for TIMESTAMP WITH TIME ZONE,
    sent_at TIMESTAMP WITH TIME ZONE,
    created_by INTEGER NOT NULL REFERENCES admins(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(50) DEFAULT 'draft'
);

-- =====================================================
-- SYSTEM SETTINGS TABLE
-- =====================================================

DROP TABLE IF EXISTS system_settings CASCADE;
CREATE TABLE system_settings (
    id SERIAL PRIMARY KEY,
    key VARCHAR(100) UNIQUE NOT NULL,
    value JSONB,
    type VARCHAR(50),
    description TEXT,
    category VARCHAR(50),
    is_public BOOLEAN DEFAULT FALSE,
    is_encrypted BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_by INTEGER REFERENCES admins(id)
);

-- =====================================================
-- USER ACTIVITY LOG TABLE
-- =====================================================

DROP TABLE IF EXISTS user_activity_log CASCADE;
CREATE TABLE user_activity_log (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    activity_type VARCHAR(50) NOT NULL,
    details JSONB,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================
-- ERROR LOGS TABLE
-- =====================================================

DROP TABLE IF EXISTS error_logs CASCADE;
CREATE TABLE error_logs (
    id SERIAL PRIMARY KEY,
    error_type VARCHAR(100) NOT NULL,
    error_message TEXT,
    traceback TEXT,
    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    admin_id INTEGER REFERENCES admins(id) ON DELETE SET NULL,
    url VARCHAR(500),
    method VARCHAR(10),
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    resolved BOOLEAN DEFAULT FALSE,
    resolved_at TIMESTAMP WITH TIME ZONE,
    resolved_by INTEGER REFERENCES admins(id)
);

-- =====================================================
-- CREATE INDEXES FOR PERFORMANCE
-- =====================================================

-- Users table indexes
CREATE INDEX idx_users_telegram_id ON users(telegram_id);
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_bot_instance ON users(bot_instance_id);
CREATE INDEX idx_users_referral_code ON users(referral_code);
CREATE INDEX idx_users_status ON users(status);
CREATE INDEX idx_users_credits ON users(credits_balance);
CREATE INDEX idx_users_last_active ON users(last_active);

-- Images table indexes
CREATE INDEX idx_images_user_id ON generated_images(user_id);
CREATE INDEX idx_images_image_id ON generated_images(image_id);
CREATE INDEX idx_images_generation_date ON generated_images(generation_date);
CREATE INDEX idx_images_style ON generated_images(style);
CREATE INDEX idx_images_status ON generated_images(status);

-- Transactions table indexes
CREATE INDEX idx_transactions_user_id ON transactions(user_id);
CREATE INDEX idx_transactions_status ON transactions(status);
CREATE INDEX idx_transactions_date ON transactions(date);
CREATE INDEX idx_transactions_payment_id ON transactions(razorpay_payment_id);

-- Queue indexes
CREATE INDEX idx_queue_user_id ON generation_queue(user_id);
CREATE INDEX idx_queue_status ON generation_queue(status);
CREATE INDEX idx_queue_created_at ON generation_queue(created_at);

-- Activity logs indexes
CREATE INDEX idx_activity_user ON user_activity_log(user_id);
CREATE INDEX idx_activity_created ON user_activity_log(created_at);

-- =====================================================
-- INSERT DEFAULT DATA
-- =====================================================

-- Insert default owner (password: Owner@123456 - will be hashed by application)
INSERT INTO owners (username, password_hash, email, master_key, settings)
VALUES (
    'owner',
    'pbkdf2:sha256:260000$xyz$hashed_password_will_be_set_by_app',
    'owner@yourdomain.com',
    'master-key-1234567890-abcdef',
    '{"maintenance_mode": false, "rate_limit": 10, "concurrent_limit": 5}'::jsonb
) ON CONFLICT (username) DO NOTHING;

-- Insert default admin (password: Admin@123456 - will be hashed by application)
INSERT INTO admins (username, password_hash, email, role, permissions, status)
VALUES (
    'admin',
    'pbkdf2:sha256:260000$xyz$hashed_password_will_be_set_by_app',
    'admin@yourdomain.com',
    'admin',
    '{"manage_users": true, "manage_credits": true, "broadcast": true, "view_analytics": true}'::jsonb,
    'active'
) ON CONFLICT (username) DO NOTHING;

-- Insert default system settings
INSERT INTO system_settings (key, value, type, description, category, is_public) VALUES
('site_name', '"AI Image Generator"', 'string', 'Site name', 'general', true),
('site_description', '"Ultra 4K AI Image Generation Bot"', 'string', 'Site description', 'general', true),
('contact_email', '"support@yourdomain.com"', 'string', 'Contact email', 'general', true),
('max_upload_size', '10485760', 'integer', 'Maximum upload size in bytes', 'limits', false),
('session_timeout', '3600', 'integer', 'Session timeout in seconds', 'security', false),
('maintenance_mode', 'false', 'boolean', 'Maintenance mode status', 'system', false),
('default_language', '"en"', 'string', 'Default language', 'localization', true),
('timezone', '"UTC"', 'string', 'Default timezone', 'localization', true),
('currency', '"INR"', 'string', 'Default currency', 'payment', true),
('tax_rate', '0.18', 'float', 'Tax rate (GST)', 'payment', false),
('enable_referrals', 'true', 'boolean', 'Enable referral system', 'features', true),
('enable_nsfw_filter', 'true', 'boolean', 'Enable NSFW content filter', 'moderation', true),
('max_concurrent_generations', '5', 'integer', 'Maximum concurrent image generations', 'limits', false),
('queue_timeout', '300', 'integer', 'Queue timeout in seconds', 'limits', false),
('generation_cost', '10', 'integer', 'Credits per image generation', 'pricing', true),
('welcome_bonus', '5', 'integer', 'Welcome bonus credits', 'pricing', true),
('referral_bonus', '10', 'integer', 'Referral bonus credits', 'pricing', true)
ON CONFLICT (key) DO NOTHING;

-- Insert banned words (basic moderation)
INSERT INTO banned_words (word, category, severity) VALUES
('nsfw', 'inappropriate', 3),
('porn', 'adult', 5),
('sex', 'adult', 5),
('nude', 'adult', 4),
('explicit', 'adult', 4),
('violence', 'violent', 3),
('gore', 'violent', 4),
('hate', 'hate_speech', 5),
('racist', 'hate_speech', 5)
ON CONFLICT (word) DO NOTHING;

-- =====================================================
-- CREATE FUNCTIONS AND TRIGGERS
-- =====================================================

-- Function to update last_active timestamp
CREATE OR REPLACE FUNCTION update_last_active()
RETURNS TRIGGER AS $$
BEGIN
    NEW.last_active = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for users table
DROP TRIGGER IF EXISTS update_user_last_active ON users;
CREATE TRIGGER update_user_last_active
    BEFORE UPDATE ON users
    FOR EACH ROW
    EXECUTE FUNCTION update_last_active();

-- Function to update timestamps
CREATE OR REPLACE FUNCTION update_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for system_settings
DROP TRIGGER IF EXISTS update_system_settings_timestamp ON system_settings;
CREATE TRIGGER update_system_settings_timestamp
    BEFORE UPDATE ON system_settings
    FOR EACH ROW
    EXECUTE FUNCTION update_timestamp();

-- =====================================================
-- VERIFY INSTALLATION
-- =====================================================

-- Count tables
SELECT 
    'Total tables created: ' || COUNT(*) as table_count
FROM information_schema.tables 
WHERE table_schema = 'public';

-- List all tables
SELECT 
    table_name as "📊 Tables in your database"
FROM information_schema.tables 
WHERE table_schema = 'public'
ORDER BY table_name;

-- Show row counts
SELECT 
    'owners' as table_name, COUNT(*) as row_count FROM owners
UNION ALL
SELECT 'admins', COUNT(*) FROM admins
UNION ALL
SELECT 'users', COUNT(*) FROM users
UNION ALL
SELECT 'bot_instances', COUNT(*) FROM bot_instances
UNION ALL
SELECT 'system_settings', COUNT(*) FROM system_settings
UNION ALL
SELECT 'banned_words', COUNT(*) FROM banned_words;

-- =====================================================
-- DATABASE IS READY!
-- =====================================================
-- Total tables created: 16
-- Connection URL: postgresql://xyzcpan2_Xyz:2J5LaNGVEmHp98MusUMs@localhost:5432/xyzcpan2_Xyz
-- =====================================================