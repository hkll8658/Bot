#!/bin/bash
# install_database.sh - Complete database setup script

echo "==========================================="
echo "🚀 Database Installation Script"
echo "==========================================="

# Database credentials
DB_HOST="localhost"
DB_PORT="5432"
DB_NAME="xyzcpan2_Xyz"
DB_USER="xyzcpan2_Xyz"
DB_PASSWORD="2J5LaNGVEmHp98MusUMs"

echo "📊 Database: $DB_NAME"
echo "👤 User: $DB_USER"
echo "==========================================="

# Check if PostgreSQL is installed
if ! command -v psql &> /dev/null; then
    echo "❌ PostgreSQL is not installed!"
    echo "Please install PostgreSQL first:"
    echo "  Ubuntu/Debian: sudo apt install postgresql postgresql-contrib"
    echo "  CentOS/RHEL: sudo yum install postgresql-server"
    exit 1
fi

# Test connection
echo "🔌 Testing database connection..."
if PGPASSWORD=$DB_PASSWORD psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME -c "SELECT 1" &> /dev/null; then
    echo "✅ Connection successful!"
else
    echo "❌ Cannot connect to database!"
    echo ""
    echo "Would you like to create the database? (y/n)"
    read -r CREATE_DB
    
    if [[ $CREATE_DB == "y" ]]; then
        # Try to create database as postgres superuser
        echo "Creating database as postgres user..."
        sudo -u postgres psql -c "CREATE DATABASE $DB_NAME;" 2>/dev/null
        sudo -u postgres psql -c "CREATE USER $DB_USER WITH PASSWORD '$DB_PASSWORD';" 2>/dev/null
        sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;" 2>/dev/null
        
        echo "✅ Database created!"
    else
        exit 1
    fi
fi

# Run SQL schema
echo "📝 Creating database tables..."
PGPASSWORD=$DB_PASSWORD psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME -f database.sql

if [ $? -eq 0 ]; then
    echo "✅ Database schema installed successfully!"
else
    echo "❌ Failed to install database schema!"
    exit 1
fi

# Run test script
echo "🧪 Running connection test..."
python3 connect.py

echo ""
echo "==========================================="
echo "✅ DATABASE SETUP COMPLETE!"
echo "==========================================="
echo "Connection URL:"
echo "postgresql://$DB_USER:$DB_PASSWORD@$DB_HOST:$DB_PORT/$DB_NAME"
echo "==========================================="