#!/usr/bin/env python3
"""
Database Connection Test Script
Run this to verify your database connection
"""

import psycopg2
from psycopg2 import OperationalError
import sys

# Your database configuration
DB_CONFIG = {
    "host": "localhost",
    "port": 5432,
    "database": "xyzcpan2_Xyz",
    "user": "xyzcpan2_Xyz",
    "password": "2J5LaNGVEmHp98MusUMs"
}

def test_connection():
    """Test database connection"""
    print("=" * 60)
    print("🔌 DATABASE CONNECTION TEST")
    print("=" * 60)
    print(f"Host:     {DB_CONFIG['host']}")
    print(f"Port:     {DB_CONFIG['port']}")
    print(f"Database: {DB_CONFIG['database']}")
    print(f"User:     {DB_CONFIG['user']}")
    print("-" * 60)
    
    try:
        # Attempt connection
        conn = psycopg2.connect(**DB_CONFIG)
        print("✅ CONNECTION SUCCESSFUL!")
        
        # Get cursor
        cur = conn.cursor()
        
        # Test query 1: PostgreSQL version
        cur.execute("SELECT version();")
        version = cur.fetchone()[0]
        print(f"\n📊 PostgreSQL Version:")
        print(f"   {version[:100]}...")
        
        # Test query 2: Current database
        cur.execute("SELECT current_database();")
        db_name = cur.fetchone()[0]
        print(f"\n📁 Connected to database: {db_name}")
        
        # Test query 3: List tables
        cur.execute("""
            SELECT table_name 
            FROM information_schema.tables 
            WHERE table_schema = 'public'
            ORDER BY table_name;
        """)
        tables = cur.fetchall()
        print(f"\n📋 Tables in database ({len(tables)}):")
        for table in tables:
            # Count rows in each table
            cur.execute(f"SELECT COUNT(*) FROM {table[0]};")
            count = cur.fetchone()[0]
            print(f"   • {table[0]:<20} → {count} rows")
        
        # Test query 4: Database size
        cur.execute("""
            SELECT pg_size_pretty(pg_database_size(current_database()));
        """)
        size = cur.fetchone()[0]
        print(f"\n💾 Database size: {size}")
        
        # Test query 5: Connection info
        cur.execute("""
            SELECT 
                pid,
                usename,
                application_name,
                state
            FROM pg_stat_activity 
            WHERE datname = current_database();
        """)
        connections = cur.fetchall()
        print(f"\n🔌 Active connections: {len(connections)}")
        
        # Close cursor and connection
        cur.close()
        conn.close()
        print("\n🔒 Connection closed.")
        print("=" * 60)
        
        return True
        
    except OperationalError as e:
        print(f"❌ CONNECTION FAILED!")
        print(f"\nError: {e}")
        print("\nPossible solutions:")
        print("1. Check if PostgreSQL is running")
        print("2. Verify your credentials are correct")
        print("3. Check if database 'xyzcpan2_Xyz' exists")
        print("4. Ensure your IP is allowed to connect")
        print("5. Check firewall settings")
        print("=" * 60)
        return False

if __name__ == "__main__":
    success = test_connection()
    sys.exit(0 if success else 1)