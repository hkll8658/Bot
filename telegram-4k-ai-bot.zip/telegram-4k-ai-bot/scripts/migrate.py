#!/usr/bin/env python3
# scripts/migrate.py - Database migration script

import os
import sys
import logging
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from alembic.config import Config
from alembic import command
from sqlalchemy import create_engine, text
from sqlalchemy.exc import SQLAlchemyError

from config.settings import config as app_config
from models import Base
from bot.utils.database import init_db, get_db_session
from bot.utils.helpers import setup_logging, hash_password

logger = setup_logging(__name__)

def check_database_connection():
    """Check if database is accessible"""
    try:
        engine = create_engine(app_config.DATABASE_URL)
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        logger.info("Database connection successful")
        return True
    except SQLAlchemyError as e:
        logger.error(f"Database connection failed: {e}")
        return False

def create_migration(message=None):
    """Create a new migration"""
    try:
        alembic_cfg = Config("alembic.ini")
        
        if message:
            command.revision(alembic_cfg, autogenerate=True, message=message)
        else:
            command.revision(alembic_cfg, autogenerate=True)
        
        logger.info("Migration created successfully")
        return True
    except Exception as e:
        logger.error(f"Failed to create migration: {e}")
        return False

def run_migrations():
    """Run all pending migrations"""
    try:
        alembic_cfg = Config("alembic.ini")
        command.upgrade(alembic_cfg, "head")
        logger.info("Migrations completed successfully")
        return True
    except Exception as e:
        logger.error(f"Migration failed: {e}")
        return False

def rollback_migration(revision="-1"):
    """Rollback to a previous migration"""
    try:
        alembic_cfg = Config("alembic.ini")
        command.downgrade(alembic_cfg, revision)
        logger.info(f"Rolled back to revision: {revision}")
        return True
    except Exception as e:
        logger.error(f"Rollback failed: {e}")
        return False

def show_current_revision():
    """Show current database revision"""
    try:
        alembic_cfg = Config("alembic.ini")
        command.current(alembic_cfg)
        return True
    except Exception as e:
        logger.error(f"Failed to get current revision: {e}")
        return False

def show_history():
    """Show migration history"""
    try:
        alembic_cfg = Config("alembic.ini")
        command.history(alembic_cfg)
        return True
    except Exception as e:
        logger.error(f"Failed to get history: {e}")
        return False

def init_database():
    """Initialize database from scratch"""
    try:
        # Create tables
        init_db()
        logger.info("Database tables created")
        
        # Create default admin if not exists
        from models import Admin
        session = get_db_session()
        
        admin = session.query(Admin).filter_by(username=app_config.ADMIN_USERNAME).first()
        if not admin:
            admin = Admin(
                username=app_config.ADMIN_USERNAME,
                password_hash=hash_password(app_config.ADMIN_PASSWORD),
                email=app_config.ADMIN_EMAIL,
                role='admin',
                status='active'
            )
            session.add(admin)
            session.commit()
            logger.info(f"Default admin created: {app_config.ADMIN_USERNAME}")
        
        session.close()
        
        logger.info("Database initialization complete")
        return True
    except Exception as e:
        logger.error(f"Database initialization failed: {e}")
        return False

def reset_database(confirm=False):
    """Reset database (drop all tables)"""
    if not confirm:
        logger.warning("Reset requires confirmation. Use --confirm flag")
        return False
    
    try:
        engine = create_engine(app_config.DATABASE_URL)
        Base.metadata.drop_all(engine)
        logger.info("All tables dropped")
        
        # Recreate tables
        Base.metadata.create_all(engine)
        logger.info("Tables recreated")
        
        return True
    except Exception as e:
        logger.error(f"Reset failed: {e}")
        return False

def main():
    """Main migration script"""
    import argparse
    
    parser = argparse.ArgumentParser(description="Database migration tool")
    parser.add_argument("command", choices=[
        "init", "migrate", "create", "rollback", "current", 
        "history", "check", "reset"
    ], help="Migration command")
    parser.add_argument("--message", "-m", help="Migration message")
    parser.add_argument("--revision", "-r", default="-1", help="Revision to rollback to")
    parser.add_argument("--confirm", action="store_true", help="Confirm destructive actions")
    
    args = parser.parse_args()
    
    # Check database connection first
    if args.command != "check" and not check_database_connection():
        logger.error("Cannot proceed without database connection")
        sys.exit(1)
    
    # Execute command
    if args.command == "init":
        success = init_database()
    elif args.command == "migrate":
        success = run_migrations()
    elif args.command == "create":
        success = create_migration(args.message)
    elif args.command == "rollback":
        success = rollback_migration(args.revision)
    elif args.command == "current":
        success = show_current_revision()
    elif args.command == "history":
        success = show_history()
    elif args.command == "check":
        success = check_database_connection()
    elif args.command == "reset":
        success = reset_database(args.confirm)
    else:
        parser.print_help()
        sys.exit(1)
    
    sys.exit(0 if success else 1)

if __name__ == "__main__":
    main()