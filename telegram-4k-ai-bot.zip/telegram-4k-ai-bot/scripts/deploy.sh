#!/bin/bash
# scripts/deploy.sh - Deployment script for Termux/Android

echo "🚀 Starting deployment of AI Image Bot..."

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}[✓]${NC} $1"
}

print_error() {
    echo -e "${RED}[✗]${NC} $1"
}

print_info() {
    echo -e "${YELLOW}[i]${NC} $1"
}

# Check if running in Termux
if [ -d "/data/data/com.termux" ]; then
    print_info "Running in Termux environment"
    IS_TERMUX=true
else
    print_info "Running in standard Linux environment"
    IS_TERMUX=false
fi

# Update packages
print_info "Updating packages..."
if [ "$IS_TERMUX" = true ]; then
    pkg update && pkg upgrade -y
else
    sudo apt-get update && sudo apt-get upgrade -y
fi

# Install dependencies
print_info "Installing dependencies..."
if [ "$IS_TERMUX" = true ]; then
    pkg install -y python postgresql nginx redis git nodejs-lts openssl
else
    sudo apt-get install -y python3 python3-pip postgresql nginx redis-server git nodejs npm
fi

# Install Python packages
print_info "Installing Python packages..."
pip install virtualenv

# Create project directory
print_info "Creating project directory..."
mkdir -p ~/aiimagebot
cd ~/aiimagebot

# Clone repository (if not already cloned)
if [ ! -d ".git" ]; then
    print_info "Cloning repository..."
    git clone https://github.com/yourusername/telegram-ai-bot.git .
else
    print_info "Repository already exists, pulling updates..."
    git pull
fi

# Create virtual environment
print_info "Creating virtual environment..."
virtualenv venv
source venv/bin/activate

# Install Python requirements
print_info "Installing Python requirements..."
pip install -r requirements.txt

# Setup database
print_info "Setting up database..."
if [ "$IS_TERMUX" = true ]; then
    pg_ctl -D $PREFIX/var/lib/postgresql start
else
    sudo systemctl start postgresql
fi

# Create database
print_info "Creating database..."
if [ "$IS_TERMUX" = true ]; then
    createdb aiimagebot 2>/dev/null || print_info "Database may already exist"
else
    sudo -u postgres createdb aiimagebot 2>/dev/null || print_info "Database may already exist"
fi

# Run migrations
print_info "Running database migrations..."
python scripts/migrate.py

# Setup Redis
print_info "Starting Redis..."
if [ "$IS_TERMUX" = true ]; then
    redis-server --daemonize yes
else
    sudo systemctl start redis-server
fi

# Create .env file if it doesn't exist
if [ ! -f ".env" ]; then
    print_info "Creating .env file from example..."
    cp .env.example .env
    print_info "Please edit .env file with your configuration"
fi

# Create necessary directories
print_info "Creating necessary directories..."
mkdir -p logs uploads backups

# Setup SSL certificates (if domain is configured)
if [ -n "$DOMAIN" ]; then
    print_info "Setting up SSL certificates..."
    if command -v certbot &> /dev/null; then
        certbot certonly --nginx -d $DOMAIN
    else
        print_info "Certbot not installed, skipping SSL setup"
    fi
fi

# Setup PM2 for process management
print_info "Setting up PM2..."
if command -v npm &> /dev/null; then
    npm install -g pm2
    
    # Create PM2 ecosystem file
    cat > ecosystem.config.js << EOF
module.exports = {
  apps: [{
    name: 'aiimagebot',
    script: 'main.py',
    interpreter: 'python3',
    watch: false,
    env: {
      NODE_ENV: 'production',
    },
    error_file: 'logs/pm2_error.log',
    out_file: 'logs/pm2_out.log',
    time: true
  }]
}
EOF
    
    # Start with PM2
    pm2 start ecosystem.config.js
    pm2 save
    pm2 startup
else
    print_info "npm not found, skipping PM2 setup"
fi

# Create backup script
print_info "Creating backup script..."
cat > scripts/backup.sh << 'EOF'
#!/bin/bash
# Automatic backup script

BACKUP_DIR="/sdcard/Download/bot_backups"
DATE=$(date +%Y%m%d_%H%M%S)

mkdir -p $BACKUP_DIR

# Backup database
pg_dump aiimagebot > $BACKUP_DIR/db_$DATE.sql

# Backup images
tar -czf $BACKUP_DIR/images_$DATE.tar.gz uploads/

# Backup config
cp .env $BACKUP_DIR/env_$DATE

# Keep only last 7 days of backups
find $BACKUP_DIR -type f -mtime +7 -delete

echo "Backup completed: $BACKUP_DIR/db_$DATE.sql"
EOF

chmod +x scripts/backup.sh

# Setup cron for daily backups
print_info "Setting up daily backups..."
(crontab -l 2>/dev/null; echo "0 2 * * * cd $PWD && ./scripts/backup.sh") | crontab -

# Create startup script
print_info "Creating startup script..."
cat > start.sh << 'EOF'
#!/bin/bash
source venv/bin/activate
python main.py
EOF

chmod +x start.sh

# Final status
print_status "Deployment complete!"
print_info "Next steps:"
echo "  1. Edit .env file with your configuration"
echo "  2. Run './start.sh' to start the bot"
echo "  3. Access admin panel at http://localhost:5000"
echo ""
print_status "Bot is now ready to use!"