#!/usr/bin/env python3
# scripts/setup_db.py - Database setup script

import os
import sys
import logging
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from sqlalchemy import create_engine, text
from sqlalchemy_utils import database_exists, create_database
from config.settings import config
from models import Base
from bot.utils.helpers import setup_logging, hash_password

logger = setup_logging(__name__)

def setup_database():
    """Setup database for first time use"""
    logger.info("Starting database setup...")
    
    # Create database if it doesn't exist
    engine = create_engine(config.DATABASE_URL)
    
    if not database_exists(engine.url):
        logger.info(f"Creating database: {engine.url.database}")
        create_database(engine.url)
    else:
        logger.info(f"Database already exists: {engine.url.database}")
    
    # Create tables
    logger.info("Creating tables...")
    Base.metadata.create_all(engine)
    
    # Import models after tables are created
    from models import Owner, Admin, BotInstance
    
    # Create session
    from sqlalchemy.orm import sessionmaker
    Session = sessionmaker(bind=engine)
    session = Session()
    
    try:
        # Create default owner if not exists
        owner = session.query(Owner).filter_by(username=config.OWNER_USERNAME).first()
        if not owner:
            logger.info("Creating default owner...")
            owner = Owner(
                username=config.OWNER_USERNAME,
                password_hash=hash_password(config.OWNER_PASSWORD),
                email=config.OWNER_EMAIL,
                master_key=config.OWNER_MASTER_KEY,
                settings={
                    'maintenance_mode': False,
                    'rate_limit': 10,
                    'concurrent_limit': 5,
                    'price_plans': {
                        100: 50,
                        500: 200,
                        1000: 400
                    }
                }
            )
            session.add(owner)
            session.flush()
            logger.info(f"Owner created: {config.OWNER_USERNAME}")
        
        # Create default admin
        admin = session.query(Admin).filter_by(username=config.ADMIN_USERNAME).first()
        if not admin:
            logger.info("Creating default admin...")
            admin = Admin(
                username=config.ADMIN_USERNAME,
                password_hash=hash_password(config.ADMIN_PASSWORD),
                email=config.ADMIN_EMAIL,
                role='admin',
                permissions={
                    'manage_users': True,
                    'manage_credits': True,
                    'broadcast': True,
                    'view_analytics': True
                },
                status='active'
            )
            session.add(admin)
            logger.info(f"Admin created: {config.ADMIN_USERNAME}")
        
        # Create default bot instance
        bot = session.query(BotInstance).filter_by(bot_token=config.BOT_TOKEN).first()
        if config.BOT_TOKEN and not bot:
            logger.info("Creating default bot instance...")
            bot = BotInstance(
                bot_token=config.BOT_TOKEN,
                bot_username=config.BOT_USERNAME,
                owner_id=owner.id,
                admin_id=admin.id if admin else None,
                razorpay_key=config.RAZORPAY_KEY_ID,
                razorpay_secret=config.RAZORPAY_KEY_SECRET,
                api_endpoint=config.AI_API_ENDPOINT,
                api_key=config.AI_API_KEY,
                status='inactive',
                config={
                    'price_plans': config.PRICE_PLANS,
                    'generation_cost': config.GENERATION_COST,
                    'welcome_bonus': config.WELCOME_BONUS,
                    'referral_bonus': config.REFERRAL_BONUS
                }
            )
            session.add(bot)
            logger.info(f"Bot instance created: {config.BOT_USERNAME}")
        
        session.commit()
        logger.info("Database setup completed successfully!")
        
    except Exception as e:
        logger.error(f"Database setup failed: {e}")
        session.rollback()
        raise
    finally:
        session.close()

def test_connection():
    """Test database connection"""
    try:
        engine = create_engine(config.DATABASE_URL)
        with engine.connect() as conn:
            result = conn.execute(text("SELECT 1"))
            logger.info("Database connection test: SUCCESS")
            return True
    except Exception as e:
        logger.error(f"Database connection test: FAILED - {e}")
        return False

def create_indexes():
    """Create additional indexes for performance"""
    logger.info("Creating indexes...")
    
    engine = create_engine(config.DATABASE_URL)
    
    with engine.connect() as conn:
        # Users table indexes
        conn.execute(text(
            "CREATE INDEX IF NOT EXISTS idx_users_telegram_id ON users(telegram_id)"
        ))
        conn.execute(text(
            "CREATE INDEX IF NOT EXISTS idx_users_username ON users(username)"
        ))
        conn.execute(text(
            "CREATE INDEX IF NOT EXISTS idx_users_referral_code ON users(referral_code)"
        ))
        conn.execute(text(
            "CREATE INDEX IF NOT EXISTS idx_users_status ON users(status)"
        ))
        conn.execute(text(
            "CREATE INDEX IF NOT EXISTS idx_users_last_active ON users(last_active)"
        ))
        
        # Images table indexes
        conn.execute(text(
            "CREATE INDEX IF NOT EXISTS idx_images_user_id ON generated_images(user_id)"
        ))
        conn.execute(text(
            "CREATE INDEX IF NOT EXISTS idx_images_generation_date ON generated_images(generation_date)"
        ))
        
        # Transactions table indexes
        conn.execute(text(
            "CREATE INDEX IF NOT EXISTS idx_transactions_user_id ON transactions(user_id)"
        ))
        conn.execute(text(
            "CREATE INDEX IF NOT EXISTS idx_transactions_status ON transactions(status)"
        ))
        conn.execute(text(
            "CREATE INDEX IF NOT EXISTS idx_transactions_date ON transactions(date)"
        ))
        
        # Queue table indexes
        conn.execute(text(
            "CREATE INDEX IF NOT EXISTS idx_queue_status ON generation_queue(status)"
        ))
        conn.execute(text(
            "CREATE INDEX IF NOT EXISTS idx_queue_created ON generation_queue(created_at)"
        ))
        
        conn.commit()
    
    logger.info("Indexes created successfully")

def main():
    """Main setup function"""
    logger.info("=" * 50)
    logger.info("Database Setup Script")
    logger.info("=" * 50)
    
    # Test connection first
    if not test_connection():
        logger.error("Cannot proceed without database connection")
        sys.exit(1)
    
    # Setup database
    setup_database()
    
    # Create indexes
    create_indexes()
    
    logger.info("=" * 50)
    logger.info("Setup complete! You can now run the bot.")
    logger.info("=" * 50)

if __name__ == "__main__":
    main()