#!/bin/bash
# scripts/backup.sh - Database and file backup script

# Configuration
BACKUP_DIR="${BACKUP_DIR:-./backups}"
DB_NAME="${DB_NAME:-aiimagebot}"
DB_USER="${DB_USER:-postgres}"
DATE=$(date +%Y%m%d_%H%M%S)
RETENTION_DAYS="${RETENTION_DAYS:-7}"

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Create backup directory
mkdir -p "$BACKUP_DIR"

# Log function
log() {
    echo -e "${GREEN}[$(date '+%Y-%m-%d %H:%M:%S')]${NC} $1"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

# Check if required tools are installed
check_dependencies() {
    if ! command -v pg_dump &> /dev/null; then
        error "pg_dump not found. Please install PostgreSQL client tools."
        exit 1
    fi
    
    if ! command -v tar &> /dev/null; then
        error "tar not found. Please install tar."
        exit 1
    fi
}

# Backup database
backup_database() {
    log "Backing up database..."
    
    DB_BACKUP="$BACKUP_DIR/db_$DATE.sql"
    
    if PGPASSWORD="$DB_PASSWORD" pg_dump -U "$DB_USER" "$DB_NAME" > "$DB_BACKUP"; then
        gzip "$DB_BACKUP"
        log "Database backup created: ${DB_BACKUP}.gz"
        return 0
    else
        error "Database backup failed"
        return 1
    fi
}

# Backup uploaded images
backup_images() {
    log "Backing up images..."
    
    IMAGES_BACKUP="$BACKUP_DIR/images_$DATE.tar.gz"
    
    if [ -d "uploads" ]; then
        tar -czf "$IMAGES_BACKUP" uploads/
        log "Images backup created: $IMAGES_BACKUP"
        return 0
    else
        warn "Uploads directory not found, skipping images backup"
        return 0
    fi
}

# Backup configuration
backup_config() {
    log "Backing up configuration..."
    
    CONFIG_BACKUP="$BACKUP_DIR/config_$DATE.tar.gz"
    
    if tar -czf "$CONFIG_BACKUP" .env config/ 2>/dev/null; then
        log "Configuration backup created: $CONFIG_BACKUP"
        return 0
    else
        warn "Configuration backup failed or no config files found"
        return 0
    fi
}

# Clean old backups
clean_old_backups() {
    log "Cleaning backups older than $RETENTION_DAYS days..."
    
    find "$BACKUP_DIR" -type f -name "*.sql.gz" -mtime +$RETENTION_DAYS -delete
    find "$BACKUP_DIR" -type f -name "*.tar.gz" -mtime +$RETENTION_DAYS -delete
    
    log "Cleanup completed"
}

# Create backup manifest
create_manifest() {
    MANIFEST="$BACKUP_DIR/manifest_$DATE.txt"
    
    cat > "$MANIFEST" << EOF
Backup Manifest
===============
Date: $(date)
Database: $DB_NAME
Backup Directory: $BACKUP_DIR

Files:
$(ls -lh "$BACKUP_DIR" | grep "$DATE")

EOF
    
    log "Manifest created: $MANIFEST"
}

# Upload to cloud storage (optional)
upload_to_cloud() {
    if [ -n "$AWS_ACCESS_KEY" ] && [ -n "$AWS_SECRET_KEY" ]; then
        log "Uploading to AWS S3..."
        
        aws s3 sync "$BACKUP_DIR" "s3://$AWS_BUCKET_NAME/backups/" --exclude "*" --include "*$DATE*"
        
        if [ $? -eq 0 ]; then
            log "Upload to S3 completed"
        else
            error "Upload to S3 failed"
        fi
    fi
    
    if [ -n "$RCLONE_REMOTE" ]; then
        log "Uploading with rclone..."
        
        rclone copy "$BACKUP_DIR" "$RCLONE_REMOTE:backups/" --include "*$DATE*"
        
        if [ $? -eq 0 ]; then
            log "Upload with rclone completed"
        else
            error "Upload with rclone failed"
        fi
    fi
}

# Send notification
send_notification() {
    local status=$1
    local message="Backup completed at $(date). Status: $status"
    
    # Telegram notification
    if [ -n "$TELEGRAM_BOT_TOKEN" ] && [ -n "$TELEGRAM_CHAT_ID" ]; then
        curl -s -X POST "https://api.telegram.org/bot$TELEGRAM_BOT_TOKEN/sendMessage" \
            -d chat_id="$TELEGRAM_CHAT_ID" \
            -d text="$message" \
            -d parse_mode="HTML" > /dev/null
    fi
    
    # Email notification (if configured)
    if [ -n "$EMAIL_RECIPIENT" ]; then
        echo "$message" | mail -s "Backup Status" "$EMAIL_RECIPIENT"
    fi
}

# Main backup function
main() {
    log "Starting backup process..."
    
    check_dependencies
    
    # Load environment variables if .env exists
    if [ -f ".env" ]; then
        export $(grep -v '^#' .env | xargs)
    fi
    
    # Perform backups
    backup_database
    DB_STATUS=$?
    
    backup_images
    IMAGES_STATUS=$?
    
    backup_config
    CONFIG_STATUS=$?
    
    # Create manifest
    create_manifest
    
    # Clean old backups
    clean_old_backups
    
    # Upload to cloud
    upload_to_cloud
    
    # Calculate total size
    TOTAL_SIZE=$(du -sh "$BACKUP_DIR" | cut -f1)
    
    log "Backup summary:"
    log "  Database: $([ $DB_STATUS -eq 0 ] && echo "✓" || echo "✗")"
    log "  Images: $([ $IMAGES_STATUS -eq 0 ] && echo "✓" || echo "✗")"
    log "  Config: $([ $CONFIG_STATUS -eq 0 ] && echo "✓" || echo "✗")"
    log "  Total size: $TOTAL_SIZE"
    
    # Send notification
    if [ $DB_STATUS -eq 0 ] && [ $IMAGES_STATUS -eq 0 ]; then
        send_notification "✅ Success"
        log "${GREEN}Backup completed successfully!${NC}"
    else
        send_notification "⚠️ Partial success"
        warn "Backup completed with warnings"
    fi
}

# Run main function
main