"""
Telegram 4K AI Image Generator Bot
Main package initialization
"""

__version__ = '1.0.0'
__author__ = 'Your Name'
__license__ = 'Proprietary'

from bot.main import AIImageBot, BotManager
from bot.handlers import user, admin, owner
from bot.services import image_generation, payment, queue_manager
from bot.utils import database, decorators, helpers, validators