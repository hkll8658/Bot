"""
Helper functions for bot
"""

import random
import string
import hashlib
import re
import logging
import logging.config
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List
from pathlib import Path

def generate_referral_code(length: int = 8) -> str:
    """Generate unique referral code"""
    chars = string.ascii_uppercase + string.digits
    # Exclude confusing characters
    chars = chars.replace('O', '').replace('0', '').replace('I', '').replace('1', '')
    return ''.join(random.choice(chars) for _ in range(length))

def format_credit_balance(credits: float) -> str:
    """Format credit balance"""
    if credits >= 1000000:
        return f"{credits/1000000:.1f}M"
    elif credits >= 1000:
        return f"{credits/1000:.1f}K"
    return str(int(credits))

def hash_password(password: str) -> str:
    """Hash password for storage"""
    salt = "your_salt_here_change_this_in_production"  # Use proper salt in production
    return hashlib.sha256(f"{password}{salt}".encode()).hexdigest()

def verify_password(password: str, hashed: str) -> bool:
    """Verify password against hash"""
    return hash_password(password) == hashed

def validate_email(email: str) -> bool:
    """Validate email format"""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def validate_prompt(prompt: str) -> bool:
    """Validate image prompt"""
    if not prompt or len(prompt) < 3:
        return False
    if len(prompt) > 1000:
        return False
    # Check for invalid characters
    invalid_chars = ['<', '>', '{', '}', '[', ']', '\\']
    if any(char in prompt for char in invalid_chars):
        return False
    return True

def sanitize_input(text: str) -> str:
    """Sanitize user input"""
    if not text:
        return ""
    # Remove potentially dangerous characters
    text = re.sub(r'[<>{}[\]\\]', '', text)
    # Limit length
    return text[:1000]

def format_size(size_bytes: int) -> str:
    """Format file size"""
    if size_bytes < 0:
        return "0 B"
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size_bytes < 1024.0:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.1f} PB"

def time_ago(dt: datetime) -> str:
    """Format time ago"""
    if not dt:
        return "never"
    
    now = datetime.utcnow()
    diff = now - dt
    
    if diff.days > 365:
        years = diff.days // 365
        return f"{years} year{'s' if years > 1 else ''} ago"
    elif diff.days > 30:
        months = diff.days // 30
        return f"{months} month{'s' if months > 1 else ''} ago"
    elif diff.days > 0:
        return f"{diff.days} day{'s' if diff.days > 1 else ''} ago"
    elif diff.seconds > 3600:
        hours = diff.seconds // 3600
        return f"{hours} hour{'s' if hours > 1 else ''} ago"
    elif diff.seconds > 60:
        minutes = diff.seconds // 60
        return f"{minutes} minute{'s' if minutes > 1 else ''} ago"
    else:
        return "just now"

def setup_logging(name: str = None) -> logging.Logger:
    """Setup logging configuration"""
    log_config = {
        'version': 1,
        'disable_existing_loggers': False,
        'formatters': {
            'verbose': {
                'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                'datefmt': '%Y-%m-%d %H:%M:%S'
            },
            'simple': {
                'format': '%(levelname)s - %(message)s'
            }
        },
        'handlers': {
            'console': {
                'class': 'logging.StreamHandler',
                'level': 'INFO',
                'formatter': 'verbose',
                'stream': 'ext://sys.stdout'
            },
            'file': {
                'class': 'logging.handlers.RotatingFileHandler',
                'level': 'DEBUG',
                'formatter': 'verbose',
                'filename': 'logs/bot.log',
                'maxBytes': 10485760,  # 10MB
                'backupCount': 5
            },
            'error_file': {
                'class': 'logging.handlers.RotatingFileHandler',
                'level': 'ERROR',
                'formatter': 'verbose',
                'filename': 'logs/error.log',
                'maxBytes': 10485760,
                'backupCount': 5
            }
        },
        'loggers': {
            '': {
                'handlers': ['console', 'file', 'error_file'],
                'level': 'DEBUG',
                'propagate': True
            },
            'telegram': {
                'handlers': ['console', 'file'],
                'level': 'INFO',
                'propagate': False
            },
            'urllib3': {
                'handlers': ['console', 'file'],
                'level': 'WARNING',
                'propagate': False
            }
        }
    }
    
    # Create logs directory
    Path('logs').mkdir(exist_ok=True)
    
    logging.config.dictConfig(log_config)
    return logging.getLogger(name or __name__)

class RateLimiter:
    """Rate limiting utility"""
    
    def __init__(self, max_requests: int, time_window: int):
        self.max_requests = max_requests
        self.time_window = time_window
        self.requests: Dict[str, List[datetime]] = {}
        
    def is_allowed(self, user_id: str) -> bool:
        """Check if user is allowed to make request"""
        now = datetime.utcnow()
        
        if user_id not in self.requests:
            self.requests[user_id] = []
        
        # Clean old requests
        cutoff = now - timedelta(seconds=self.time_window)
        self.requests[user_id] = [
            req_time for req_time in self.requests[user_id]
            if req_time > cutoff
        ]
        
        if len(self.requests[user_id]) >= self.max_requests:
            return False
        
        self.requests[user_id].append(now)
        return True
    
    def get_remaining(self, user_id: str) -> int:
        """Get remaining requests for user"""
        if user_id not in self.requests:
            return self.max_requests
        
        now = datetime.utcnow()
        cutoff = now - timedelta(seconds=self.time_window)
        recent = [t for t in self.requests[user_id] if t > cutoff]
        
        return max(0, self.max_requests - len(recent))
    
    def reset(self, user_id: str = None):
        """Reset rate limiter for user or all"""
        if user_id:
            self.requests.pop(user_id, None)
        else:
            self.requests.clear()

class CacheManager:
    """Simple cache manager"""
    
    def __init__(self):
        self.cache: Dict[str, tuple] = {}
        self.default_ttl = 300  # 5 minutes
        
    def get(self, key: str):
        """Get value from cache"""
        if key in self.cache:
            value, expiry = self.cache[key]
            if expiry > datetime.utcnow():
                return value
            else:
                del self.cache[key]
        return None
    
    def set(self, key: str, value: Any, ttl: int = None):
        """Set value in cache with TTL"""
        ttl = ttl or self.default_ttl
        expiry = datetime.utcnow() + timedelta(seconds=ttl)
        self.cache[key] = (value, expiry)
    
    def delete(self, key: str):
        """Delete from cache"""
        self.cache.pop(key, None)
    
    def clear(self):
        """Clear all cache"""
        self.cache.clear()
    
    def cleanup(self):
        """Clear expired cache entries"""
        now = datetime.utcnow()
        expired = [
            key for key, (_, expiry) in self.cache.items()
            if expiry <= now
        ]
        for key in expired:
            del self.cache[key]

class StatsCollector:
    """Collect and store statistics"""
    
    def __init__(self):
        self.stats: Dict[str, Any] = {
            'commands': {},
            'errors': {},
            'generations': {},
            'users': {}
        }
        self.start_time = datetime.utcnow()
        
    def increment(self, category: str, key: str):
        """Increment a counter"""
        if category not in self.stats:
            self.stats[category] = {}
        if key not in self.stats[category]:
            self.stats[category][key] = 0
        self.stats[category][key] += 1
    
    def record_value(self, category: str, key: str, value: float):
        """Record a value"""
        if category not in self.stats:
            self.stats[category] = {}
        if key not in self.stats[category]:
            self.stats[category][key] = []
        self.stats[category][key].append(value)
    
    def get_summary(self) -> Dict:
        """Get statistics summary"""
        now = datetime.utcnow()
        uptime = (now - self.start_time).total_seconds()
        
        summary = {
            'uptime': uptime,
            'uptime_str': str(timedelta(seconds=int(uptime))),
            'commands': self.stats.get('commands', {}),
            'errors': self.stats.get('errors', {}),
            'total_generations': sum(self.stats.get('generations', {}).values()),
            'total_commands': sum(self.stats.get('commands', {}).values()),
            'total_errors': sum(self.stats.get('errors', {}).values())
        }
        
        return summary