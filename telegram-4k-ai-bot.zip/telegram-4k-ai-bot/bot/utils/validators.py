"""
Validation utilities
"""

import re
from typing import Optional, Tuple, Union

def validate_telegram_id(telegram_id: str) -> bool:
    """Validate Telegram ID format"""
    if not telegram_id:
        return False
    # Telegram IDs are positive integers
    try:
        id_int = int(telegram_id)
        return id_int > 0
    except ValueError:
        return False

def validate_username(username: str) -> bool:
    """Validate username format"""
    if not username:
        return False
    # Telegram usernames: 5-32 chars, alphanumeric and underscore
    pattern = r'^[a-zA-Z0-9_]{5,32}$'
    return bool(re.match(pattern, username))

def validate_amount(amount: Union[int, float, str]) -> Tuple[bool, Optional[float]]:
    """Validate payment amount"""
    try:
        amount_float = float(amount)
        if amount_float <= 0:
            return False, None
        if amount_float > 100000:  # Max ₹100,000
            return False, None
        # Check for reasonable decimal places
        if len(str(amount_float).split('.')[-1]) > 2:
            return False, None
        return True, amount_float
    except (ValueError, TypeError):
        return False, None

def validate_credits(credits: Union[int, str]) -> Tuple[bool, Optional[int]]:
    """Validate credit amount"""
    try:
        credits_int = int(credits)
        if credits_int <= 0:
            return False, None
        if credits_int > 1000000:  # Max 1 million credits
            return False, None
        return True, credits_int
    except (ValueError, TypeError):
        return False, None

def validate_prompt_content(prompt: str) -> Tuple[bool, Optional[str]]:
    """Validate image prompt content"""
    if not prompt:
        return False, "Prompt cannot be empty"
    
    if len(prompt) < 3:
        return False, "Prompt too short (minimum 3 characters)"
    
    if len(prompt) > 1000:
        return False, "Prompt too long (maximum 1000 characters)"
    
    # Check for inappropriate content (basic)
    inappropriate_words = ['nsfw', 'porn', 'sex', 'nude', 'explicit']
    prompt_lower = prompt.lower()
    for word in inappropriate_words:
        if word in prompt_lower:
            return False, "Prompt contains inappropriate content"
    
    # Check for invalid characters
    invalid_chars = ['<', '>', '{', '}', '[', ']', '\\', '`']
    for char in invalid_chars:
        if char in prompt:
            return False, f"Prompt contains invalid character: {char}"
    
    return True, None

def validate_style(style: str) -> bool:
    """Validate image style"""
    valid_styles = [
        'realistic', 'anime', 'cinematic', 'oil_painting',
        'sketch', 'fantasy', 'photorealistic', '3d_render',
        'watercolor', 'pixel_art'
    ]
    return style in valid_styles

def validate_aspect_ratio(ratio: str) -> bool:
    """Validate aspect ratio"""
    valid_ratios = ['16:9', '9:16', '1:1', '21:9', '4:3', '3:2']
    return ratio in valid_ratios

def validate_resolution(resolution: str) -> bool:
    """Validate image resolution"""
    valid_resolutions = ['3840x2160', '1920x1080', '1024x1024']
    return resolution in valid_resolutions

def validate_email_format(email: str) -> Tuple[bool, Optional[str]]:
    """Validate email format"""
    if not email:
        return False, "Email cannot be empty"
    
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    if not re.match(pattern, email):
        return False, "Invalid email format"
    
    return True, None

def validate_phone(phone: str) -> Tuple[bool, Optional[str]]:
    """Validate phone number (Indian)"""
    if not phone:
        return False, "Phone number cannot be empty"
    
    # Indian phone numbers: 10 digits, starting with 6-9
    pattern = r'^[6-9]\d{9}$'
    if not re.match(pattern, phone):
        return False, "Invalid phone number (must be 10 digits starting with 6-9)"
    
    return True, None

def validate_password_strength(password: str) -> Tuple[bool, Optional[str]]:
    """Validate password strength"""
    if not password:
        return False, "Password cannot be empty"
    
    if len(password) < 8:
        return False, "Password must be at least 8 characters"
    
    if len(password) > 128:
        return False, "Password too long (maximum 128 characters)"
    
    # Check for at least one uppercase, one lowercase, one digit
    has_upper = any(c.isupper() for c in password)
    has_lower = any(c.islower() for c in password)
    has_digit = any(c.isdigit() for c in password)
    
    if not (has_upper and has_lower and has_digit):
        return False, "Password must contain uppercase, lowercase, and digit"
    
    return True, None

def validate_date_range(start_date: str, end_date: str) -> Tuple[bool, Optional[str]]:
    """Validate date range for reports"""
    from datetime import datetime
    
    try:
        start = datetime.strptime(start_date, '%Y-%m-%d')
        end = datetime.strptime(end_date, '%Y-%m-%d')
        
        if start > end:
            return False, "Start date cannot be after end date"
        
        # Check if range is within reasonable limits (e.g., 1 year)
        if (end - start).days > 365:
            return False, "Date range cannot exceed 365 days"
        
        return True, None
    except ValueError:
        return False, "Invalid date format. Use YYYY-MM-DD"

def sanitize_filename(filename: str) -> str:
    """Sanitize filename to prevent path traversal"""
    # Remove path separators
    filename = filename.replace('/', '_').replace('\\', '_')
    # Remove any double dots
    filename = re.sub(r'\.{2,}', '.', filename)
    # Limit length
    if len(filename) > 255:
        name, ext = filename.rsplit('.', 1) if '.' in filename else (filename, '')
        filename = name[:250] + '.' + ext if ext else name[:255]
    return filename

def validate_file_size(size_bytes: int, max_mb: int = 10) -> Tuple[bool, Optional[str]]:
    """Validate file size"""
    max_bytes = max_mb * 1024 * 1024
    if size_bytes > max_bytes:
        return False, f"File too large (max {max_mb}MB)"
    if size_bytes <= 0:
        return False, "Invalid file size"
    return True, None

def validate_file_type(filename: str, allowed_types: list) -> Tuple[bool, Optional[str]]:
    """Validate file type by extension"""
    ext = filename.lower().split('.')[-1] if '.' in filename else ''
    if ext not in allowed_types:
        return False, f"File type not allowed. Allowed: {', '.join(allowed_types)}"
    return True, None