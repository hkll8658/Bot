"""
Decorators for bot handlers
"""

import functools
import logging
from datetime import datetime, timedelta
from typing import Dict, Any, Callable
from telegram import Update
from telegram.ext import ContextTypes
from bot.utils.database import get_db_session
from bot.utils.helpers import RateLimiter
from models import Admin, Owner, User

logger = logging.getLogger(__name__)

# Global rate limiters
user_limiter = RateLimiter(max_requests=10, time_window=60)
generate_limiter = RateLimiter(max_requests=5, time_window=60)
admin_limiter = RateLimiter(max_requests=30, time_window=60)

def rate_limit(max_requests: int = None, time_window: int = None):
    """
    Rate limiting decorator for user commands
    """
    def decorator(func: Callable):
        @functools.wraps(func)
        async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
            user_id = str(update.effective_user.id)
            
            # Use provided limits or defaults
            limit = max_requests or 10
            window = time_window or 60
            
            # Create limiter for this specific command
            limiter = RateLimiter(max_requests=limit, time_window=window)
            
            if not limiter.is_allowed(user_id):
                await update.message.reply_text(
                    "⏳ **Too many requests!**\n\n"
                    f"Please wait {window} seconds before trying again.",
                    parse_mode='Markdown'
                )
                return
            
            return await func(update, context, *args, **kwargs)
        return wrapper
    return decorator

def admin_required(func: Callable):
    """
    Decorator to restrict access to admins only
    """
    @functools.wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user = update.effective_user
        db_session = get_db_session()
        
        try:
            # Check if user is admin
            admin = db_session.query(Admin).filter_by(
                username=user.username,
                status='active'
            ).first()
            
            if not admin:
                # Also check if user is owner (owner has all admin privileges)
                owner = db_session.query(Owner).filter_by(
                    username=user.username
                ).first()
                
                if not owner:
                    await update.message.reply_text(
                        "⛔ **Access Denied**\n\n"
                        "This command is only available to administrators.",
                        parse_mode='Markdown'
                    )
                    return
            
            # Log admin action
            logger.info(f"Admin command executed by @{user.username}: {func.__name__}")
            
            return await func(update, context, *args, **kwargs)
            
        except Exception as e:
            logger.error(f"Error in admin_required decorator: {e}")
            await update.message.reply_text("An error occurred. Please try again.")
        finally:
            db_session.close()
    
    return wrapper

def owner_required(func: Callable):
    """
    Decorator to restrict access to owner only
    """
    @functools.wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user = update.effective_user
        db_session = get_db_session()
        
        try:
            # Check if user is owner
            owner = db_session.query(Owner).filter_by(
                username=user.username
            ).first()
            
            if not owner:
                await update.message.reply_text(
                    "⛔ **Access Denied**\n\n"
                    "This command is only available to the bot owner.",
                    parse_mode='Markdown'
                )
                return
            
            # Log owner action
            logger.info(f"Owner command executed by @{user.username}: {func.__name__}")
            
            return await func(update, context, *args, **kwargs)
            
        except Exception as e:
            logger.error(f"Error in owner_required decorator: {e}")
            await update.message.reply_text("An error occurred. Please try again.")
        finally:
            db_session.close()
    
    return wrapper

def log_command(func: Callable):
    """
    Decorator to log command usage
    """
    @functools.wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user = update.effective_user
        command = func.__name__
        
        logger.info(f"User @{user.username} ({user.id}) executed command: {command}")
        
        try:
            result = await func(update, context, *args, **kwargs)
            logger.info(f"Command {command} completed successfully")
            return result
        except Exception as e:
            logger.error(f"Command {command} failed: {e}")
            raise
    
    return wrapper

def check_subscription(func: Callable):
    """
    Decorator to check if user is registered
    """
    @functools.wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user_id = str(update.effective_user.id)
        bot_instance_id = context.bot_data.get('bot_instance_id')
        
        db_session = get_db_session()
        try:
            user = db_session.query(User).filter_by(
                telegram_id=user_id,
                bot_instance_id=bot_instance_id
            ).first()
            
            if not user:
                await update.message.reply_text(
                    "Please /start first to register with the bot!"
                )
                return
            
            # Update last active
            user.last_active = datetime.utcnow()
            db_session.commit()
            
            return await func(update, context, *args, **kwargs)
            
        except Exception as e:
            logger.error(f"Error in check_subscription: {e}")
            await update.message.reply_text("An error occurred. Please try again.")
        finally:
            db_session.close()
    
    return wrapper

def check_credits(min_credits: int = 10):
    """
    Decorator to check if user has enough credits
    """
    def decorator(func: Callable):
        @functools.wraps(func)
        async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
            user_id = str(update.effective_user.id)
            bot_instance_id = context.bot_data.get('bot_instance_id')
            
            db_session = get_db_session()
            try:
                user = db_session.query(User).filter_by(
                    telegram_id=user_id,
                    bot_instance_id=bot_instance_id
                ).first()
                
                if not user:
                    await update.message.reply_text("Please /start first!")
                    return
                
                if user.credits_balance < min_credits:
                    await update.message.reply_text(
                        f"❌ **Insufficient credits!**\n\n"
                        f"You need {min_credits} credits for this action.\n"
                        f"Your balance: {user.credits_balance} credits\n\n"
                        f"Use /recharge to buy more credits."
                    )
                    return
                
                return await func(update, context, *args, **kwargs)
                
            except Exception as e:
                logger.error(f"Error in check_credits: {e}")
                await update.message.reply_text("An error occurred. Please try again.")
            finally:
                db_session.close()
        
        return wrapper
    return decorator

def maintenance_mode(func: Callable):
    """
    Decorator to check if bot is in maintenance mode
    """
    @functools.wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        # Check if maintenance mode is enabled
        if context.bot_data.get('maintenance_mode', False):
            # Allow admins and owner to bypass
            user = update.effective_user
            db_session = get_db_session()
            
            try:
                admin = db_session.query(Admin).filter_by(username=user.username).first()
                owner = db_session.query(Owner).filter_by(username=user.username).first()
                
                if not (admin or owner):
                    await update.message.reply_text(
                        "🔧 **Bot Under Maintenance**\n\n"
                        "The bot is currently undergoing maintenance.\n"
                        "Please try again later.",
                        parse_mode='Markdown'
                    )
                    return
            finally:
                db_session.close()
        
        return await func(update, context, *args, **kwargs)
    
    return wrapper

def retry_on_error(max_retries: int = 3, delay: int = 1):
    """
    Decorator to retry function on error
    """
    def decorator(func: Callable):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            import asyncio
            
            for attempt in range(max_retries):
                try:
                    return await func(*args, **kwargs)
                except Exception as e:
                    if attempt == max_retries - 1:
                        raise
                    logger.warning(f"Attempt {attempt + 1} failed: {e}. Retrying...")
                    await asyncio.sleep(delay * (attempt + 1))
            
            return None
        return wrapper
    return decorator

def measure_time(func: Callable):
    """
    Decorator to measure function execution time
    """
    @functools.wraps(func)
    async def wrapper(*args, **kwargs):
        import time
        start = time.time()
        result = await func(*args, **kwargs)
        end = time.time()
        logger.debug(f"{func.__name__} took {end - start:.2f} seconds")
        return result
    return wrapper