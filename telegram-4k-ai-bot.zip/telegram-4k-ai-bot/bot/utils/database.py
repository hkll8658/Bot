"""
Database utilities and connection management
"""

import os
import logging
from contextlib import contextmanager
from datetime import datetime, timedelta
from typing import Optional, Generator, Any, Dict, List
from sqlalchemy import create_engine, event, inspect
from sqlalchemy.orm import sessionmaker, scoped_session, Session
from sqlalchemy.pool import QueuePool
from sqlalchemy.exc import SQLAlchemyError, OperationalError
from config.settings import config
from models import Base, User, BotInstance, Transaction, GeneratedImage, Admin, Owner, GenerationQueue

logger = logging.getLogger(__name__)

# Database configuration
DATABASE_URL = os.getenv(
    'DATABASE_URL',
    config.DATABASE_URL if hasattr(config, 'DATABASE_URL') else 'sqlite:///bot.db'
)

# Create engine with connection pooling
engine = create_engine(
    DATABASE_URL,
    poolclass=QueuePool,
    pool_size=10,
    max_overflow=20,
    pool_pre_ping=True,
    pool_recycle=3600,
    echo=False
)

# Create session factory
SessionFactory = sessionmaker(bind=engine)
Session = scoped_session(SessionFactory)

def init_db():
    """Initialize database tables"""
    try:
        Base.metadata.create_all(engine)
        logger.info("Database tables created/verified")
        
        # Create default owner if not exists
        create_default_owner()
        
    except Exception as e:
        logger.error(f"Database initialization failed: {e}")
        raise

def create_default_owner():
    """Create default owner account if not exists"""
    session = Session()
    try:
        owner = session.query(Owner).filter_by(username=config.OWNER_USERNAME).first()
        if not owner and hasattr(config, 'OWNER_USERNAME'):
            from bot.utils.helpers import hash_password
            owner = Owner(
                username=config.OWNER_USERNAME,
                password_hash=hash_password(config.OWNER_PASSWORD),
                email=os.getenv('OWNER_EMAIL', 'admin@example.com'),
                master_key=config.OWNER_MASTER_KEY if hasattr(config, 'OWNER_MASTER_KEY') else None,
                settings={
                    'maintenance_mode': False,
                    'rate_limit': 10,
                    'concurrent_limit': 5
                }
            )
            session.add(owner)
            session.commit()
            logger.info("Default owner created")
    except Exception as e:
        logger.error(f"Failed to create default owner: {e}")
        session.rollback()
    finally:
        session.close()

def get_db_session() -> Session:
    """Get database session"""
    return Session()

@contextmanager
def session_scope() -> Generator[Session, None, None]:
    """Provide a transactional scope around a series of operations"""
    session = Session()
    try:
        yield session
        session.commit()
    except Exception as e:
        session.rollback()
        logger.error(f"Session error: {e}")
        raise
    finally:
        session.close()

class DatabaseManager:
    """Manage database operations"""
    
    def __init__(self):
        self.engine = engine
        self.Session = Session
        
    def backup_database(self, backup_path: str) -> str:
        """
        Create database backup
        """
        import subprocess
        from datetime import datetime
        
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"{backup_path}/backup_{timestamp}.sql"
        
        try:
            if 'postgresql' in DATABASE_URL:
                # Using pg_dump for PostgreSQL
                cmd = f"pg_dump {DATABASE_URL} > {filename}"
                subprocess.run(cmd, shell=True, check=True)
            elif 'mysql' in DATABASE_URL:
                # Using mysqldump for MySQL
                cmd = f"mysqldump {DATABASE_URL} > {filename}"
                subprocess.run(cmd, shell=True, check=True)
            else:
                # SQLite - just copy the file
                import shutil
                db_path = DATABASE_URL.replace('sqlite:///', '')
                shutil.copy2(db_path, filename)
            
            logger.info(f"Database backup created: {filename}")
            return filename
            
        except Exception as e:
            logger.error(f"Backup failed: {e}")
            raise
    
    def restore_database(self, backup_file: str):
        """
        Restore database from backup
        """
        import subprocess
        
        try:
            if 'postgresql' in DATABASE_URL:
                cmd = f"psql {DATABASE_URL} < {backup_file}"
                subprocess.run(cmd, shell=True, check=True)
            elif 'mysql' in DATABASE_URL:
                cmd = f"mysql {DATABASE_URL} < {backup_file}"
                subprocess.run(cmd, shell=True, check=True)
            else:
                # SQLite
                import shutil
                db_path = DATABASE_URL.replace('sqlite:///', '')
                shutil.copy2(backup_file, db_path)
            
            logger.info(f"Database restored from: {backup_file}")
            
        except Exception as e:
            logger.error(f"Restore failed: {e}")
            raise
    
    def cleanup_old_data(self, days: int = 30):
        """
        Clean up old data (queue entries, logs)
        """
        cutoff_date = datetime.utcnow() - timedelta(days=days)
        
        session = self.Session()
        try:
            # Delete old completed queue entries
            deleted = session.query(GenerationQueue).filter(
                GenerationQueue.status.in_(['completed', 'failed', 'cancelled']),
                GenerationQueue.completed_at < cutoff_date
            ).delete()
            
            logger.info(f"Cleaned up {deleted} old queue entries")
            session.commit()
            
        except Exception as e:
            logger.error(f"Cleanup failed: {e}")
            session.rollback()
        finally:
            session.close()
    
    def get_database_stats(self) -> Dict:
        """Get database statistics"""
        session = self.Session()
        try:
            from sqlalchemy import func
            
            stats = {
                'users': session.query(func.count(User.id)).scalar() or 0,
                'active_users': session.query(User).filter(
                    User.last_active >= datetime.utcnow() - timedelta(days=7)
                ).count(),
                'bot_instances': session.query(func.count(BotInstance.id)).scalar() or 0,
                'images': session.query(func.count(GeneratedImage.id)).scalar() or 0,
                'transactions': session.query(func.count(Transaction.id)).scalar() or 0,
                'completed_transactions': session.query(Transaction).filter_by(
                    status='completed'
                ).count(),
                'queue_pending': session.query(GenerationQueue).filter_by(
                    status='queued'
                ).count(),
                'queue_processing': session.query(GenerationQueue).filter_by(
                    status='processing'
                ).count()
            }
            
            # Get database size
            if 'sqlite' in DATABASE_URL:
                import os
                db_path = DATABASE_URL.replace('sqlite:///', '')
                if os.path.exists(db_path):
                    stats['size_mb'] = os.path.getsize(db_path) / (1024 * 1024)
            
            return stats
            
        except Exception as e:
            logger.error(f"Failed to get database stats: {e}")
            return {}
        finally:
            session.close()
    
    def check_connection(self) -> bool:
        """Check database connection"""
        try:
            session = self.Session()
            session.execute("SELECT 1")
            session.close()
            return True
        except Exception as e:
            logger.error(f"Database connection failed: {e}")
            return False
    
    def vacuum(self):
        """Vacuum database (SQLite only)"""
        if 'sqlite' in DATABASE_URL:
            try:
                session = self.Session()
                session.execute("VACUUM")
                session.commit()
                session.close()
                logger.info("Database vacuum completed")
            except Exception as e:
                logger.error(f"Vacuum failed: {e}")

# Database event listeners
@event.listens_for(engine, "connect")
def connect(dbapi_connection, connection_record):
    """Handle database connection"""
    logger.debug("Database connected")

@event.listens_for(engine, "checkout")
def checkout(dbapi_connection, connection_record, connection_proxy):
    """Handle connection checkout"""
    logger.debug("Database connection checked out")

@event.listens_for(engine, "checkin")
def checkin(dbapi_connection, connection_record):
    """Handle connection checkin"""
    logger.debug("Database connection checked in")