"""
User-facing command handlers
"""

import logging
from typing import Dict, Any, Optional
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler
from bot.utils.database import get_db_session
from bot.utils.helpers import (
    generate_referral_code, format_credit_balance, time_ago,
    validate_prompt, sanitize_input
)
from bot.services.payment import create_razorpay_order, verify_payment
from models import User, GeneratedImage, Transaction

logger = logging.getLogger(__name__)

# Conversation states
PROMPT, STYLE, ASPECT_RATIO = range(3)

# Price plans
PRICE_PLANS = {
    100: 50,
    500: 200,
    1000: 400
}

# Styles available
STYLES = {
    'realistic': '🎨 Realistic',
    'anime': '🌸 Anime',
    'cinematic': '🎬 Cinematic',
    'oil_painting': '🖼️ Oil Painting',
    'sketch': '✏️ Sketch',
    'fantasy': '🌌 Fantasy',
    'photorealistic': '📸 Photorealistic',
    '3d_render': '🎭 3D Render',
    'watercolor': '💧 Watercolor',
    'pixel_art': '🟦 Pixel Art'
}

# Aspect ratios
ASPECT_RATIOS = {
    '16:9': '🖥️ 16:9 (Landscape)',
    '9:16': '📱 9:16 (Portrait)',
    '1:1': '📷 1:1 (Square)',
    '21:9': '🎬 21:9 (Cinematic)',
    '4:3': '📸 4:3 (Classic)',
    '3:2': '🖼️ 3:2 (Photo)'
}

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /start command - Register user"""
    user = update.effective_user
    db_session = get_db_session()
    
    try:
        # Check if user exists
        existing_user = db_session.query(User).filter_by(
            telegram_id=str(user.id),
            bot_instance_id=context.bot_data.get('bot_instance_id')
        ).first()
        
        if not existing_user:
            # Create new user
            referral_code = generate_referral_code()
            new_user = User(
                telegram_id=str(user.id),
                username=user.username,
                first_name=user.first_name or "User",
                last_name=user.last_name,
                referral_code=referral_code,
                bot_instance_id=context.bot_data.get('bot_instance_id'),
                credits_balance=context.bot_data.get('welcome_bonus', 5)
            )
            
            # Check if referred
            args = context.args
            if args and args[0].startswith('ref_'):
                referrer_code = args[0].replace('ref_', '')
                referrer = db_session.query(User).filter_by(
                    referral_code=referrer_code,
                    bot_instance_id=context.bot_data.get('bot_instance_id')
                ).first()
                
                if referrer:
                    new_user.referred_by = referrer.telegram_id
                    # Give referral bonus
                    referrer.credits_balance += context.bot_data.get('referral_bonus', 10)
                    db_session.add(referrer)
                    
                    # Notify referrer
                    try:
                        await context.bot.send_message(
                            chat_id=referrer.telegram_id,
                            text=f"🎉 Someone joined using your referral link!\n"
                                 f"You earned {context.bot_data.get('referral_bonus', 10)} credits!"
                        )
                    except:
                        pass
            
            db_session.add(new_user)
            db_session.commit()
            
            welcome_text = (
                f"🎨 **Welcome to Ultra 4K AI Image Generator!**\n\n"
                f"✨ You've received **{new_user.credits_balance} free credits** to start!\n\n"
                f"**Commands:**\n"
                f"/generate - Create an image\n"
                f"/recharge - Buy more credits\n"
                f"/balance - Check your credits\n"
                f"/referral - Get referral link\n"
                f"/help - More commands\n\n"
                f"Each image costs **10 credits**"
            )
        else:
            existing_user.last_active = datetime.utcnow()
            db_session.commit()
            
            welcome_text = (
                f"👋 **Welcome back {user.first_name}!**\n\n"
                f"💰 **Your Stats:**\n"
                f"• Credits: **{existing_user.credits_balance}**\n"
                f"• Images Generated: **{existing_user.total_generated}**\n"
                f"• Member since: {existing_user.joined_date.strftime('%d %b %Y')}\n\n"
                f"Use /generate to create stunning 4K images!"
            )
        
        # Create keyboard
        keyboard = [
            [InlineKeyboardButton("🎨 Generate Image", callback_data="generate")],
            [InlineKeyboardButton("💰 Buy Credits", callback_data="recharge"),
             InlineKeyboardButton("👤 Profile", callback_data="profile")],
            [InlineKeyboardButton("❓ Help", callback_data="help")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            welcome_text,
            parse_mode='Markdown',
            reply_markup=reply_markup
        )
        
    except Exception as e:
        logger.error(f"Error in start handler: {e}")
        await update.message.reply_text("An error occurred. Please try again.")
    finally:
        db_session.close()

async def generate(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /generate command"""
    user = update.effective_user
    db_session = get_db_session()
    
    try:
        db_user = db_session.query(User).filter_by(
            telegram_id=str(user.id),
            bot_instance_id=context.bot_data.get('bot_instance_id')
        ).first()
        
        if not db_user:
            await update.message.reply_text("Please /start first to register!")
            return ConversationHandler.END
        
        if db_user.credits_balance < 10:
            keyboard = [[InlineKeyboardButton("💰 Buy Credits", callback_data="recharge")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await update.message.reply_text(
                f"❌ **Insufficient credits!**\n\n"
                f"Each generation costs **10 credits**\n"
                f"Your balance: **{db_user.credits_balance} credits**",
                parse_mode='Markdown',
                reply_markup=reply_markup
            )
            return ConversationHandler.END
        
        # Check if user has a prompt in the command
        if context.args:
            prompt = ' '.join(context.args)
            if not validate_prompt(prompt):
                await update.message.reply_text(
                    "❌ Invalid prompt. Please use descriptive text without special characters."
                )
                return ConversationHandler.END
            
            context.user_data['prompt'] = sanitize_input(prompt)
            await show_style_selection(update, context)
            return STYLE
        else:
            await update.message.reply_text(
                "✍️ **Please describe the image you want to generate:**\n\n"
                "Example: `a beautiful sunset over mountains, 4k, photorealistic`\n\n"
                "Send me your prompt:",
                parse_mode='Markdown'
            )
            context.user_data['awaiting_prompt'] = True
            return PROMPT
            
    except Exception as e:
        logger.error(f"Error in generate handler: {e}")
        await update.message.reply_text("An error occurred. Please try again.")
        return ConversationHandler.END
    finally:
        db_session.close()

async def handle_prompt(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle text messages (prompts)"""
    if context.user_data.get('awaiting_prompt'):
        prompt = update.message.text
        
        if not validate_prompt(prompt):
            await update.message.reply_text(
                "❌ Invalid prompt. Please use descriptive text without special characters."
            )
            return PROMPT
        
        context.user_data['prompt'] = sanitize_input(prompt)
        context.user_data['awaiting_prompt'] = False
        await show_style_selection(update, context)
        return STYLE
    else:
        await update.message.reply_text(
            "Use /generate to create images or /help for commands"
        )
        return ConversationHandler.END

async def show_style_selection(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show style selection menu"""
    keyboard = []
    styles_list = list(STYLES.items())
    
    # Create 2-column layout
    for i in range(0, len(styles_list), 2):
        row = []
        for style_value, style_name in styles_list[i:i+2]:
            row.append(InlineKeyboardButton(style_name, callback_data=f"style_{style_value}"))
        keyboard.append(row)
    
    keyboard.append([InlineKeyboardButton("⏭️ Skip (Default)", callback_data="style_skip")])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if update.message:
        await update.message.reply_text(
            "🎨 **Choose a style:**",
            parse_mode='Markdown',
            reply_markup=reply_markup
        )
    else:
        await update.callback_query.edit_message_text(
            "🎨 **Choose a style:**",
            parse_mode='Markdown',
            reply_markup=reply_markup
        )

async def show_aspect_ratio(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show aspect ratio selection"""
    keyboard = []
    for ratio_value, ratio_name in ASPECT_RATIOS.items():
        keyboard.append([InlineKeyboardButton(ratio_name, callback_data=f"ratio_{ratio_value}")])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    query = update.callback_query
    await query.edit_message_text(
        "📐 **Select aspect ratio:**",
        parse_mode='Markdown',
        reply_markup=reply_markup
    )

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle callback queries"""
    query = update.callback_query
    await query.answer()
    
    data = query.data
    
    try:
        if data == "generate":
            await generate(update, context)
        
        elif data == "recharge":
            await show_recharge_options(update, context)
        
        elif data == "profile":
            await show_profile(update, context)
        
        elif data == "help":
            await show_help(update, context)
        
        elif data.startswith("style_"):
            style = data.replace("style_", "")
            if style != "skip":
                context.user_data['style'] = style
            await show_aspect_ratio(update, context)
        
        elif data.startswith("ratio_"):
            ratio = data.replace("ratio_", "")
            context.user_data['aspect_ratio'] = ratio
            await start_generation(update, context)
        
        elif data.startswith("recharge_"):
            credits = int(data.replace("recharge_", ""))
            await process_recharge(update, context, credits)
        
        elif data.startswith("confirm_payment_"):
            payment_id = data.replace("confirm_payment_", "")
            await verify_payment_status(update, context, payment_id)
            
    except Exception as e:
        logger.error(f"Error in callback handler: {e}")
        await query.edit_message_text("❌ An error occurred. Please try again.")

async def start_generation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start image generation"""
    query = update.callback_query
    user = update.effective_user
    
    prompt = context.user_data.get('prompt')
    style = context.user_data.get('style', 'realistic')
    aspect_ratio = context.user_data.get('aspect_ratio', '16:9')
    
    if not prompt:
        await query.edit_message_text("❌ Error: No prompt found. Please try again.")
        return
    
    db_session = get_db_session()
    
    try:
        db_user = db_session.query(User).filter_by(
            telegram_id=str(user.id),
            bot_instance_id=context.bot_data.get('bot_instance_id')
        ).first()
        
        if db_user.credits_balance < 10:
            await query.edit_message_text("❌ Insufficient credits!")
            return
        
        # Deduct credits
        db_user.credits_balance -= 10
        db_user.total_generated += 1
        db_session.commit()
        
        # Send initial message
        await query.edit_message_text(
            f"🎨 **Generating your image...**\n\n"
            f"**Prompt:** {prompt[:100]}{'...' if len(prompt) > 100 else ''}\n"
            f"**Style:** {STYLES.get(style, style)}\n"
            f"**Ratio:** {ASPECT_RATIOS.get(aspect_ratio, aspect_ratio)}\n\n"
            f"⏳ This may take 20-30 seconds...\n\n"
            f"Your remaining credits: **{db_user.credits_balance}**"
        )
        
        # Queue generation
        queue_manager = context.bot_data.get('queue_manager')
        queue_id = await queue_manager.add_to_queue(
            user_id=db_user.id,
            prompt=prompt,
            parameters={
                'style': style,
                'aspect_ratio': aspect_ratio,
                'resolution': "3840x2160",
                'negative_prompt': context.user_data.get('negative_prompt', '')
            }
        )
        
        # Store in context for later retrieval
        context.user_data['queue_id'] = queue_id
        
        # Start generation in background
        context.application.create_task(
            process_generation(context, db_user.id, queue_id)
        )
        
    except Exception as e:
        logger.error(f"Error starting generation: {e}")
        await query.edit_message_text("❌ Failed to start generation. Please try again.")
        
        # Refund credits on error
        if 'db_user' in locals():
            db_user.credits_balance += 10
            db_user.total_generated -= 1
            db_session.commit()
    finally:
        db_session.close()

async def process_generation(context, user_id: int, queue_id: str):
    """Process image generation in background"""
    try:
        # Wait for generation to complete
        queue_manager = context.bot_data.get('queue_manager')
        image_service = context.bot_data.get('image_service')
        
        # Poll for completion
        max_wait = 60  # seconds
        interval = 5
        waited = 0
        
        while waited < max_wait:
            status = await queue_manager.get_queue_status(queue_id)
            if status and status['status'] == 'completed':
                # Get result
                result = {
                    'success': True,
                    'image_url': status['result_url'],
                    'thumbnail_url': status.get('thumbnail_url', status['result_url'])
                }
                break
            elif status and status['status'] == 'failed':
                result = {'success': False, 'error': status.get('error', 'Generation failed')}
                break
            
            await asyncio.sleep(interval)
            waited += interval
        else:
            result = {'success': False, 'error': 'Generation timeout'}
        
        if result['success']:
            # Store in database
            db_session = get_db_session()
            try:
                new_image = GeneratedImage(
                    user_id=user_id,
                    prompt=context.user_data.get('prompt', ''),
                    style=context.user_data.get('style', 'realistic'),
                    aspect_ratio=context.user_data.get('aspect_ratio', '16:9'),
                    resolution="3840x2160",
                    image_url=result['image_url'],
                    thumbnail_url=result['thumbnail_url']
                )
                db_session.add(new_image)
                db_session.commit()
                
                # Send result to user
                await context.bot.send_photo(
                    chat_id=user_id,
                    photo=result['image_url'],
                    caption=f"✅ **Image generated successfully!**\n\n"
                           f"**Prompt:** {context.user_data.get('prompt', '')[:100]}\n"
                           f"**Style:** {context.user_data.get('style', 'realistic')}\n"
                           f"**Cost:** 10 credits\n\n"
                           f"Use /generate to create more!"
                )
            finally:
                db_session.close()
        else:
            # Refund credits on failure
            db_session = get_db_session()
            try:
                db_user = db_session.query(User).get(user_id)
                if db_user:
                    db_user.credits_balance += 10
                    db_user.total_generated -= 1
                    db_session.commit()
            finally:
                db_session.close()
            
            await context.bot.send_message(
                chat_id=user_id,
                text="❌ Generation failed. Your credits have been refunded.\n"
                     "Please try again later."
            )
            
    except Exception as e:
        logger.error(f"Generation error: {e}")
        # Attempt refund
        db_session = get_db_session()
        try:
            db_user = db_session.query(User).get(user_id)
            if db_user:
                db_user.credits_balance += 10
                db_user.total_generated -= 1
                db_session.commit()
        finally:
            db_session.close()
        
        await context.bot.send_message(
            chat_id=user_id,
            text="❌ An error occurred. Your credits have been refunded."
        )

async def show_recharge_options(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show available credit packages"""
    keyboard = []
    for credits, price in PRICE_PLANS.items():
        keyboard.append([
            InlineKeyboardButton(
                f"{credits} credits - ₹{price}",
                callback_data=f"recharge_{credits}"
            )
        ])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if update.message:
        await update.message.reply_text(
            "💰 **Choose a credit package:**",
            parse_mode='Markdown',
            reply_markup=reply_markup
        )
    else:
        await update.callback_query.edit_message_text(
            "💰 **Choose a credit package:**",
            parse_mode='Markdown',
            reply_markup=reply_markup
        )

async def process_recharge(update: Update, context: ContextTypes.DEFAULT_TYPE, credits: int):
    """Process recharge request"""
    query = update.callback_query
    user = update.effective_user
    
    amount = PRICE_PLANS[credits]
    
    # Create Razorpay order
    payment_service = context.bot_data.get('payment_service')
    order = await payment_service.create_order(
        amount=amount,
        currency="INR",
        receipt=f"receipt_{user.id}_{credits}",
        notes={
            'user_id': str(user.id),
            'credits': credits,
            'bot_instance': str(context.bot_data.get('bot_instance_id'))
        }
    )
    
    if order:
        # Store order in database
        db_session = get_db_session()
        try:
            transaction = Transaction(
                transaction_id=order['id'],
                user_id=user.id,
                amount=amount,
                credits=credits,
                payment_method="razorpay",
                status="pending",
                razorpay_order_id=order['id']
            )
            db_session.add(transaction)
            db_session.commit()
            
            # Send payment details
            payment_text = (
                f"💳 **Payment Details**\n\n"
                f"**Package:** {credits} credits\n"
                f"**Amount:** ₹{amount}\n\n"
                f"**UPI ID:** `aiimage@okhdfcbank`\n"
                f"**QR Code:** [Click to view](https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=upi://pay?pa=aiimage@okhdfcbank&pn=AI%20Image%20Bot&am={amount}&cu=INR)\n\n"
                f"**OR**\n\n"
                f"**Payment Link:**\n"
                f"{order.get('short_url', 'https://rzp.io/l/aiimage')}\n\n"
                f"After payment, click the button below to verify:"
            )
            
            keyboard = [[
                InlineKeyboardButton(
                    "✅ I've Completed Payment",
                    callback_data=f"confirm_payment_{order['id']}"
                )
            ]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                payment_text,
                parse_mode='Markdown',
                reply_markup=reply_markup
            )
        finally:
            db_session.close()
    else:
        await query.edit_message_text(
            "❌ Failed to create payment order. Please try again later."
        )

async def verify_payment_status(update: Update, context: ContextTypes.DEFAULT_TYPE, payment_id: str):
    """Verify payment status"""
    query = update.callback_query
    user = update.effective_user
    
    db_session = get_db_session()
    try:
        transaction = db_session.query(Transaction).filter_by(
            transaction_id=payment_id,
            user_id=user.id
        ).first()
        
        if not transaction:
            await query.edit_message_text("❌ Transaction not found!")
            return
        
        # Verify with payment service
        payment_service = context.bot_data.get('payment_service')
        
        # Try to fetch payment details
        payment = await payment_service.fetch_payment(payment_id)
        
        if payment and payment['status'] == 'captured':
            transaction.status = "completed"
            
            # Add credits to user
            db_user = db_session.query(User).filter_by(
                telegram_id=str(user.id),
                bot_instance_id=context.bot_data.get('bot_instance_id')
            ).first()
            
            if db_user:
                db_user.credits_balance += transaction.credits
                db_session.commit()
                
                await query.edit_message_text(
                    f"✅ **Payment verified successfully!**\n\n"
                    f"💰 **{transaction.credits} credits** added to your account\n"
                    f"💳 **New balance:** {db_user.credits_balance} credits\n\n"
                    f"Use /generate to start creating images!"
                )
            else:
                await query.edit_message_text("❌ User not found!")
        else:
            # Payment not yet received
            keyboard = [[
                InlineKeyboardButton(
                    "🔄 Check Again",
                    callback_data=f"confirm_payment_{payment_id}"
                )
            ]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                "⏳ **Payment not yet received.**\n\n"
                "If you've already paid, please wait a few minutes and try again.\n"
                "Payments usually take 1-2 minutes to process.",
                reply_markup=reply_markup
            )
            
    except Exception as e:
        logger.error(f"Payment verification error: {e}")
        await query.edit_message_text("❌ Verification failed. Please try again.")
    finally:
        db_session.close()

async def balance(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Check credit balance"""
    user = update.effective_user
    db_session = get_db_session()
    
    try:
        db_user = db_session.query(User).filter_by(
            telegram_id=str(user.id),
            bot_instance_id=context.bot_data.get('bot_instance_id')
        ).first()
        
        if db_user:
            # Calculate referral earnings
            referral_count = db_session.query(User).filter_by(
                referred_by=str(user.id)
            ).count()
            
            stats_text = (
                f"💰 **Your Account Balance**\n\n"
                f"**Credits:** `{db_user.credits_balance}`\n"
                f"**Images Generated:** `{db_user.total_generated}`\n"
                f"**Referrals:** `{referral_count}`\n"
                f"**Member since:** {db_user.joined_date.strftime('%d %b %Y')}\n\n"
                f"Each image generation costs **10 credits**\n"
                f"Get **10 credits** for each referral!"
            )
            
            keyboard = [
                [InlineKeyboardButton("➕ Buy More Credits", callback_data="recharge")],
                [InlineKeyboardButton("🎨 Generate Image", callback_data="generate")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await update.message.reply_text(
                stats_text,
                parse_mode='Markdown',
                reply_markup=reply_markup
            )
        else:
            await update.message.reply_text("Please /start first!")
            
    except Exception as e:
        logger.error(f"Error in balance handler: {e}")
        await update.message.reply_text("An error occurred.")
    finally:
        db_session.close()

async def history(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """View generation history"""
    user = update.effective_user
    db_session = get_db_session()
    
    try:
        db_user = db_session.query(User).filter_by(
            telegram_id=str(user.id),
            bot_instance_id=context.bot_data.get('bot_instance_id')
        ).first()
        
        if not db_user:
            await update.message.reply_text("Please /start first!")
            return
        
        # Get recent images with pagination
        page = context.user_data.get('history_page', 1)
        per_page = 5
        
        images = db_session.query(GeneratedImage).filter_by(
            user_id=db_user.id
        ).order_by(
            GeneratedImage.generation_date.desc()
        ).offset((page-1)*per_page).limit(per_page).all()
        
        total_images = db_session.query(GeneratedImage).filter_by(
            user_id=db_user.id
        ).count()
        
        if not images:
            await update.message.reply_text(
                "📸 **No images yet!**\n\n"
                "Use /generate to create your first 4K image."
            )
            return
        
        await update.message.reply_text(
            f"📸 **Your Gallery** (Page {page}/{(total_images-1)//per_page + 1})\n\n"
            f"Total images: {total_images}"
        )
        
        for img in images:
            caption = (
                f"**Prompt:** {img.prompt[:100]}{'...' if len(img.prompt) > 100 else ''}\n"
                f"**Style:** {img.style}\n"
                f"**Date:** {img.generation_date.strftime('%d %b %Y %H:%M')}\n"
                f"[Download]({img.image_url})"
            )
            await update.message.reply_photo(
                photo=img.thumbnail_url,
                caption=caption,
                parse_mode='Markdown'
            )
        
        # Navigation buttons
        keyboard = []
        nav_buttons = []
        if page > 1:
            nav_buttons.append(InlineKeyboardButton("◀️ Previous", callback_data="history_prev"))
        if page * per_page < total_images:
            nav_buttons.append(InlineKeyboardButton("Next ▶️", callback_data="history_next"))
        
        if nav_buttons:
            keyboard.append(nav_buttons)
            reply_markup = InlineKeyboardMarkup(keyboard)
            await update.message.reply_text("Navigation:", reply_markup=reply_markup)
        
    except Exception as e:
        logger.error(f"Error in history handler: {e}")
        await update.message.reply_text("An error occurred.")
    finally:
        db_session.close()

async def referral(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Get referral link"""
    user = update.effective_user
    db_session = get_db_session()
    
    try:
        db_user = db_session.query(User).filter_by(
            telegram_id=str(user.id),
            bot_instance_id=context.bot_data.get('bot_instance_id')
        ).first()
        
        if not db_user:
            await update.message.reply_text("Please /start first!")
            return
        
        # Count referrals
        referral_count = db_session.query(User).filter_by(
            referred_by=str(user.id)
        ).count()
        
        referral_link = f"https://t.me/{context.bot.username}?start=ref_{db_user.referral_code}"
        
        referral_text = (
            f"🔗 **Your Referral Link**\n\n"
            f"Share this link with friends:\n"
            f"`{referral_link}`\n\n"
            f"**Benefits:**\n"
            f"• You get **10 credits** when someone joins using your link\n"
            f"• Your friend gets **5 bonus credits** on signup\n\n"
            f"📊 **Your Stats:**\n"
            f"Total Referrals: **{referral_count}**\n"
            f"Credits Earned: **{referral_count * 10}**"
        )
        
        keyboard = [
            [InlineKeyboardButton("📤 Share", switch_inline_query=referral_link)],
            [InlineKeyboardButton("📊 Referral Leaderboard", callback_data="referral_leaderboard")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            referral_text,
            parse_mode='Markdown',
            reply_markup=reply_markup
        )
        
    except Exception as e:
        logger.error(f"Error in referral handler: {e}")
        await update.message.reply_text("An error occurred.")
    finally:
        db_session.close()

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show help information"""
    await show_help(update, context)

async def show_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Display help menu"""
    help_text = (
        "🎨 **Ultra 4K AI Image Generator - Help**\n\n"
        "**Commands:**\n"
        "/start - Start the bot and register\n"
        "/generate [prompt] - Generate an image\n"
        "/balance - Check your credit balance\n"
        "/recharge - Buy more credits\n"
        "/history - View your generated images\n"
        "/referral - Get your referral link\n"
        "/settings - Configure preferences\n"
        "/help - Show this message\n\n"
        "**How to generate images:**\n"
        "1. Use /generate command\n"
        "2. Describe what you want\n"
        "3. Choose a style\n"
        "4. Select aspect ratio\n"
        "5. Wait 20-30 seconds\n\n"
        "**Pricing:**\n"
        "• 10 credits per image\n"
        "• 100 credits - ₹50\n"
        "• 500 credits - ₹200\n"
        "• 1000 credits - ₹400\n\n"
        "**Need help?** Contact @admin for support"
    )
    
    keyboard = [
        [InlineKeyboardButton("📘 FAQ", callback_data="faq")],
        [InlineKeyboardButton("📞 Contact Support", url="https://t.me/support")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if update.message:
        await update.message.reply_text(help_text, parse_mode='Markdown', reply_markup=reply_markup)
    else:
        await update.callback_query.edit_message_text(
            help_text, parse_mode='Markdown', reply_markup=reply_markup
        )

async def settings(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """User preferences"""
    user = update.effective_user
    db_session = get_db_session()
    
    try:
        db_user = db_session.query(User).filter_by(
            telegram_id=str(user.id),
            bot_instance_id=context.bot_data.get('bot_instance_id')
        ).first()
        
        if not db_user:
            await update.message.reply_text("Please /start first!")
            return
        
        # Get current preferences
        prefs = db_user.preferences or {
            'default_style': 'realistic',
            'default_ratio': '16:9',
            'notifications': True,
            'save_history': True,
            'nsfw_filter': True
        }
        
        settings_text = (
            "⚙️ **User Settings**\n\n"
            f"**Default Style:** {STYLES.get(prefs['default_style'], prefs['default_style'])}\n"
            f"**Default Ratio:** {ASPECT_RATIOS.get(prefs['default_ratio'], prefs['default_ratio'])}\n"
            f"**Notifications:** {'✅ ON' if prefs['notifications'] else '❌ OFF'}\n"
            f"**Save History:** {'✅ ON' if prefs['save_history'] else '❌ OFF'}\n"
            f"**NSFW Filter:** {'✅ ON' if prefs['nsfw_filter'] else '❌ OFF'}\n\n"
            "Click below to change settings:"
        )
        
        keyboard = [
            [InlineKeyboardButton("🎨 Default Style", callback_data="settings_style")],
            [InlineKeyboardButton("📐 Default Ratio", callback_data="settings_ratio")],
            [InlineKeyboardButton("🔔 Notifications", callback_data="settings_notifications")],
            [InlineKeyboardButton("💾 Save History", callback_data="settings_history")],
            [InlineKeyboardButton("🔞 NSFW Filter", callback_data="settings_nsfw")],
            [InlineKeyboardButton("🔙 Back", callback_data="settings_back")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            settings_text,
            parse_mode='Markdown',
            reply_markup=reply_markup
        )
        
    except Exception as e:
        logger.error(f"Error in settings handler: {e}")
        await update.message.reply_text("An error occurred.")
    finally:
        db_session.close()

async def show_profile(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show user profile"""
    query = update.callback_query
    user = update.effective_user
    
    db_session = get_db_session()
    try:
        db_user = db_session.query(User).filter_by(
            telegram_id=str(user.id),
            bot_instance_id=context.bot_data.get('bot_instance_id')
        ).first()
        
        if not db_user:
            await query.edit_message_text("User not found!")
            return
        
        # Get statistics
        referral_count = db_session.query(User).filter_by(
            referred_by=str(user.id)
        ).count()
        
        total_spent = db_session.query(Transaction).filter_by(
            user_id=user.id,
            status='completed'
        ).with_entities(func.sum(Transaction.amount)).scalar() or 0
        
        profile_text = (
            f"👤 **User Profile**\n\n"
            f"**Name:** {db_user.first_name} {db_user.last_name or ''}\n"
            f"**Username:** @{db_user.username or 'N/A'}\n"
            f"**User ID:** `{db_user.telegram_id}`\n\n"
            f"📊 **Statistics:**\n"
            f"• Credits Balance: **{db_user.credits_balance}**\n"
            f"• Images Generated: **{db_user.total_generated}**\n"
            f"• Total Spent: **₹{total_spent:,.2f}**\n"
            f"• Referrals: **{referral_count}**\n"
            f"• Joined: {db_user.joined_date.strftime('%d %b %Y')}\n"
            f"• Last Active: {time_ago(db_user.last_active)}\n\n"
            f"🎨 Each image costs **10 credits**"
        )
        
        keyboard = [
            [InlineKeyboardButton("💰 Buy Credits", callback_data="recharge")],
            [InlineKeyboardButton("🎨 Generate", callback_data="generate")],
            [InlineKeyboardButton("🔗 Referral Link", callback_data="referral")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(
            profile_text,
            parse_mode='Markdown',
            reply_markup=reply_markup
        )
        
    except Exception as e:
        logger.error(f"Error in profile handler: {e}")
        await query.edit_message_text("❌ An error occurred.")
    finally:
        db_session.close()