"""
Admin command handlers
"""

import logging
import csv
from io import StringIO, BytesIO
from datetime import datetime, timedelta
from typing import Optional, List, Dict
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler
from sqlalchemy import func
from bot.utils.database import get_db_session
from bot.utils.decorators import admin_required
from bot.utils.helpers import format_credit_balance, time_ago
from models import User, GeneratedImage, Transaction, Admin, BotInstance

logger = logging.getLogger(__name__)

# Admin conversation states
SELECT_USER, ADD_CREDITS_AMOUNT, BROADCAST_MESSAGE, CONFIRM_BROADCAST = range(4, 8)

@admin_required
async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Main admin panel"""
    keyboard = [
        [InlineKeyboardButton("📊 Dashboard", callback_data="admin_dashboard")],
        [InlineKeyboardButton("👥 User Management", callback_data="admin_users")],
        [InlineKeyboardButton("💰 Credit Management", callback_data="admin_credits")],
        [InlineKeyboardButton("📢 Broadcast", callback_data="admin_broadcast")],
        [InlineKeyboardButton("📈 Analytics", callback_data="admin_analytics")],
        [InlineKeyboardButton("⚙️ Settings", callback_data="admin_settings")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        "🛠️ **Admin Control Panel**\n\n"
        "Select an option:",
        parse_mode='Markdown',
        reply_markup=reply_markup
    )

async def admin_dashboard(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show admin dashboard"""
    query = update.callback_query
    await query.answer()
    
    db_session = get_db_session()
    bot_instance_id = context.bot_data.get('bot_instance_id')
    
    try:
        # Get statistics
        total_users = db_session.query(User).filter_by(
            bot_instance_id=bot_instance_id
        ).count()
        
        active_today = db_session.query(User).filter(
            User.bot_instance_id == bot_instance_id,
            User.last_active >= datetime.utcnow() - timedelta(days=1)
        ).count()
        
        active_week = db_session.query(User).filter(
            User.bot_instance_id == bot_instance_id,
            User.last_active >= datetime.utcnow() - timedelta(days=7)
        ).count()
        
        total_images = db_session.query(GeneratedImage).join(User).filter(
            User.bot_instance_id == bot_instance_id
        ).count()
        
        images_today = db_session.query(GeneratedImage).join(User).filter(
            User.bot_instance_id == bot_instance_id,
            GeneratedImage.generation_date >= datetime.utcnow() - timedelta(days=1)
        ).count()
        
        total_revenue = db_session.query(Transaction).filter(
            Transaction.status == 'completed'
        ).with_entities(func.sum(Transaction.amount)).scalar() or 0
        
        revenue_today = db_session.query(Transaction).filter(
            Transaction.status == 'completed',
            Transaction.date >= datetime.utcnow() - timedelta(days=1)
        ).with_entities(func.sum(Transaction.amount)).scalar() or 0
        
        # Get recent users
        recent_users = db_session.query(User).filter_by(
            bot_instance_id=bot_instance_id
        ).order_by(User.joined_date.desc()).limit(5).all()
        
        dashboard_text = (
            "📊 **Admin Dashboard**\n\n"
            f"**Overview:**\n"
            f"👥 Total Users: **{total_users}**\n"
            f"📱 Active Today: **{active_today}**\n"
            f"📱 Active This Week: **{active_week}**\n\n"
            f"**Images:**\n"
            f"🖼️ Total Generated: **{total_images}**\n"
            f"🖼️ Today: **{images_today}**\n\n"
            f"**Revenue:**\n"
            f"💰 Total: **₹{total_revenue:,.2f}**\n"
            f"💰 Today: **₹{revenue_today:,.2f}**\n\n"
            f"**Recent Users:**\n"
        )
        
        for user in recent_users:
            dashboard_text += f"• {user.first_name} (@{user.username or 'N/A'}) - {time_ago(user.joined_date)}\n"
        
        keyboard = [
            [InlineKeyboardButton("🔄 Refresh", callback_data="admin_dashboard"),
             InlineKeyboardButton("🔙 Back", callback_data="admin_back")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(
            dashboard_text,
            parse_mode='Markdown',
            reply_markup=reply_markup
        )
        
    except Exception as e:
        logger.error(f"Error in admin dashboard: {e}")
        await query.edit_message_text("❌ An error occurred.")
    finally:
        db_session.close()

async def admin_users(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """User management panel"""
    query = update.callback_query
    await query.answer()
    
    keyboard = [
        [InlineKeyboardButton("🔍 Search User", callback_data="admin_search_user")],
        [InlineKeyboardButton("📋 List All Users", callback_data="admin_list_users")],
        [InlineKeyboardButton("🚫 Block User", callback_data="admin_block_user")],
        [InlineKeyboardButton("✅ Unblock User", callback_data="admin_unblock_user")],
        [InlineKeyboardButton("➕ Add Credits", callback_data="admin_add_credits")],
        [InlineKeyboardButton("➖ Remove Credits", callback_data="admin_remove_credits")],
        [InlineKeyboardButton("📤 Export Users", callback_data="admin_export_users")],
        [InlineKeyboardButton("🔙 Back", callback_data="admin_back")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        "👥 **User Management**\n\n"
        "Select an action:",
        parse_mode='Markdown',
        reply_markup=reply_markup
    )

async def admin_search_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Search for a user"""
    query = update.callback_query
    await query.edit_message_text(
        "🔍 **Search User**\n\n"
        "Enter user ID, username, or name to search:"
    )
    context.user_data['admin_action'] = 'search'
    return SELECT_USER

async def handle_user_search(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle user search input"""
    search_term = update.message.text.strip()
    db_session = get_db_session()
    bot_instance_id = context.bot_data.get('bot_instance_id')
    
    try:
        # Search by various fields
        users = db_session.query(User).filter(
            User.bot_instance_id == bot_instance_id,
            (
                User.telegram_id.contains(search_term) |
                User.username.contains(search_term.lower()) |
                User.first_name.contains(search_term) |
                User.last_name.contains(search_term)
            )
        ).limit(10).all()
        
        if not users:
            await update.message.reply_text("❌ No users found.")
            return ConversationHandler.END
        
        text = "🔍 **Search Results:**\n\n"
        for user in users:
            text += (
                f"**{user.first_name}** (@{user.username or 'N/A'})\n"
                f"ID: `{user.telegram_id}`\n"
                f"Credits: {user.credits_balance} | Images: {user.total_generated}\n"
                f"Status: {user.status}\n\n"
            )
        
        keyboard = [
            [InlineKeyboardButton("🔙 Back to User Management", callback_data="admin_users")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(text, reply_markup=reply_markup)
        
    except Exception as e:
        logger.error(f"Error searching users: {e}")
        await update.message.reply_text("❌ An error occurred.")
    finally:
        db_session.close()
    
    return ConversationHandler.END

async def admin_list_users(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """List all users with pagination"""
    query = update.callback_query
    await query.answer()
    
    db_session = get_db_session()
    bot_instance_id = context.bot_data.get('bot_instance_id')
    
    try:
        page = context.user_data.get('user_page', 1)
        per_page = 10
        
        users = db_session.query(User).filter_by(
            bot_instance_id=bot_instance_id
        ).order_by(User.joined_date.desc()).offset((page-1)*per_page).limit(per_page).all()
        
        total_users = db_session.query(User).filter_by(
            bot_instance_id=bot_instance_id
        ).count()
        
        total_pages = (total_users + per_page - 1) // per_page
        
        text = f"📋 **Users List (Page {page}/{total_pages})**\n\n"
        
        for i, user in enumerate(users, 1):
            text += (
                f"{i}. **{user.first_name}** (@{user.username or 'N/A'})\n"
                f"   ID: `{user.telegram_id}`\n"
                f"   Credits: {user.credits_balance} | Images: {user.total_generated}\n"
                f"   Status: {user.status}\n\n"
            )
        
        keyboard = []
        nav_buttons = []
        
        if page > 1:
            nav_buttons.append(InlineKeyboardButton("◀️ Prev", callback_data="admin_users_prev"))
        if page < total_pages:
            nav_buttons.append(InlineKeyboardButton("Next ▶️", callback_data="admin_users_next"))
        
        if nav_buttons:
            keyboard.append(nav_buttons)
        
        keyboard.append([InlineKeyboardButton("🔙 Back", callback_data="admin_users")])
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(text, parse_mode='Markdown', reply_markup=reply_markup)
        
        context.user_data['user_page'] = page
        
    except Exception as e:
        logger.error(f"Error listing users: {e}")
        await query.edit_message_text("❌ An error occurred.")
    finally:
        db_session.close()

async def admin_add_credits(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Add credits to user"""
    query = update.callback_query
    await query.edit_message_text(
        "➕ **Add Credits**\n\n"
        "Enter user ID:"
    )
    context.user_data['admin_action'] = 'add_credits_user'
    return SELECT_USER

async def handle_add_credits_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle user ID for adding credits"""
    user_id = update.message.text.strip()
    context.user_data['target_user_id'] = user_id
    
    await update.message.reply_text(
        f"Enter amount of credits to add to user {user_id}:"
    )
    return ADD_CREDITS_AMOUNT

async def handle_add_credits_amount(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle credit amount and add to user"""
    try:
        credits = int(update.message.text.strip())
        user_id = context.user_data.get('target_user_id')
        
        db_session = get_db_session()
        bot_instance_id = context.bot_data.get('bot_instance_id')
        
        user = db_session.query(User).filter_by(
            telegram_id=user_id,
            bot_instance_id=bot_instance_id
        ).first()
        
        if not user:
            await update.message.reply_text("❌ User not found!")
            db_session.close()
            return ConversationHandler.END
        
        # Add credits
        old_balance = user.credits_balance
        user.credits_balance += credits
        db_session.commit()
        
        # Notify user
        try:
            await context.bot.send_message(
                chat_id=user_id,
                text=f"✨ **Credits Added!**\n\n"
                     f"Admin has added **{credits} credits** to your account.\n"
                     f"**Old balance:** {old_balance}\n"
                     f"**New balance:** {user.credits_balance}\n\n"
                     f"Use /generate to create images!"
            )
        except Exception as e:
            logger.error(f"Failed to notify user: {e}")
        
        await update.message.reply_text(
            f"✅ **Success!**\n\n"
            f"Added **{credits} credits** to user {user_id}\n"
            f"New balance: **{user.credits_balance}**"
        )
        
        db_session.close()
        
    except ValueError:
        await update.message.reply_text("❌ Please enter a valid number.")
        return ADD_CREDITS_AMOUNT
    except Exception as e:
        logger.error(f"Error adding credits: {e}")
        await update.message.reply_text("❌ An error occurred.")
    
    return ConversationHandler.END

async def admin_remove_credits(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Remove credits from user"""
    query = update.callback_query
    await query.edit_message_text(
        "➖ **Remove Credits**\n\n"
        "Enter user ID:"
    )
    context.user_data['admin_action'] = 'remove_credits_user'
    return SELECT_USER

async def handle_remove_credits_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle user ID for removing credits"""
    user_id = update.message.text.strip()
    context.user_data['target_user_id'] = user_id
    
    await update.message.reply_text(
        f"Enter amount of credits to remove from user {user_id}:"
    )
    return ADD_CREDITS_AMOUNT

async def handle_remove_credits_amount(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle credit amount and remove from user"""
    try:
        credits = int(update.message.text.strip())
        user_id = context.user_data.get('target_user_id')
        
        db_session = get_db_session()
        bot_instance_id = context.bot_data.get('bot_instance_id')
        
        user = db_session.query(User).filter_by(
            telegram_id=user_id,
            bot_instance_id=bot_instance_id
        ).first()
        
        if not user:
            await update.message.reply_text("❌ User not found!")
            db_session.close()
            return ConversationHandler.END
        
        if user.credits_balance < credits:
            await update.message.reply_text(
                f"❌ User only has {user.credits_balance} credits!"
            )
            db_session.close()
            return ConversationHandler.END
        
        # Remove credits
        old_balance = user.credits_balance
        user.credits_balance -= credits
        db_session.commit()
        
        # Notify user
        try:
            await context.bot.send_message(
                chat_id=user_id,
                text=f"⚠️ **Credits Removed**\n\n"
                     f"Admin has removed **{credits} credits** from your account.\n"
                     f"**Old balance:** {old_balance}\n"
                     f"**New balance:** {user.credits_balance}"
            )
        except Exception as e:
            logger.error(f"Failed to notify user: {e}")
        
        await update.message.reply_text(
            f"✅ **Success!**\n\n"
            f"Removed **{credits} credits** from user {user_id}\n"
            f"New balance: **{user.credits_balance}**"
        )
        
        db_session.close()
        
    except ValueError:
        await update.message.reply_text("❌ Please enter a valid number.")
        return ADD_CREDITS_AMOUNT
    except Exception as e:
        logger.error(f"Error removing credits: {e}")
        await update.message.reply_text("❌ An error occurred.")
    
    return ConversationHandler.END

async def admin_block_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Block a user"""
    query = update.callback_query
    await query.edit_message_text(
        "🚫 **Block User**\n\n"
        "Enter user ID to block:"
    )
    context.user_data['admin_action'] = 'block_user'
    return SELECT_USER

async def handle_block_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle user blocking"""
    user_id = update.message.text.strip()
    
    db_session = get_db_session()
    bot_instance_id = context.bot_data.get('bot_instance_id')
    
    try:
        user = db_session.query(User).filter_by(
            telegram_id=user_id,
            bot_instance_id=bot_instance_id
        ).first()
        
        if not user:
            await update.message.reply_text("❌ User not found!")
            return ConversationHandler.END
        
        if user.status == 'blocked':
            await update.message.reply_text(f"User {user_id} is already blocked.")
            return ConversationHandler.END
        
        user.status = 'blocked'
        db_session.commit()
        
        # Notify user
        try:
            await context.bot.send_message(
                chat_id=user_id,
                text="🚫 Your account has been blocked. Contact support for more information."
            )
        except:
            pass
        
        await update.message.reply_text(f"✅ User {user_id} has been blocked.")
        
    except Exception as e:
        logger.error(f"Error blocking user: {e}")
        await update.message.reply_text("❌ An error occurred.")
    finally:
        db_session.close()
    
    return ConversationHandler.END

async def admin_unblock_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Unblock a user"""
    query = update.callback_query
    await query.edit_message_text(
        "✅ **Unblock User**\n\n"
        "Enter user ID to unblock:"
    )
    context.user_data['admin_action'] = 'unblock_user'
    return SELECT_USER

async def handle_unblock_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle user unblocking"""
    user_id = update.message.text.strip()
    
    db_session = get_db_session()
    bot_instance_id = context.bot_data.get('bot_instance_id')
    
    try:
        user = db_session.query(User).filter_by(
            telegram_id=user_id,
            bot_instance_id=bot_instance_id
        ).first()
        
        if not user:
            await update.message.reply_text("❌ User not found!")
            return ConversationHandler.END
        
        if user.status == 'active':
            await update.message.reply_text(f"User {user_id} is already active.")
            return ConversationHandler.END
        
        user.status = 'active'
        db_session.commit()
        
        # Notify user
        try:
            await context.bot.send_message(
                chat_id=user_id,
                text="✅ Your account has been unblocked. You can now use the bot again."
            )
        except:
            pass
        
        await update.message.reply_text(f"✅ User {user_id} has been unblocked.")
        
    except Exception as e:
        logger.error(f"Error unblocking user: {e}")
        await update.message.reply_text("❌ An error occurred.")
    finally:
        db_session.close()
    
    return ConversationHandler.END

async def admin_export_users(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Export users to CSV"""
    query = update.callback_query
    await query.answer()
    
    db_session = get_db_session()
    bot_instance_id = context.bot_data.get('bot_instance_id')
    
    try:
        users = db_session.query(User).filter_by(
            bot_instance_id=bot_instance_id
        ).all()
        
        # Create CSV
        output = StringIO()
        writer = csv.writer(output)
        writer.writerow([
            'User ID', 'Username', 'First Name', 'Last Name', 
            'Credits', 'Images Generated', 'Joined Date', 
            'Last Active', 'Status', 'Referred By', 'Referral Count'
        ])
        
        for user in users:
            referral_count = db_session.query(User).filter_by(
                referred_by=user.telegram_id
            ).count()
            
            writer.writerow([
                user.telegram_id,
                user.username or '',
                user.first_name,
                user.last_name or '',
                user.credits_balance,
                user.total_generated,
                user.joined_date.strftime('%Y-%m-%d %H:%M:%S'),
                user.last_active.strftime('%Y-%m-%d %H:%M:%S'),
                user.status,
                user.referred_by or '',
                referral_count
            ])
        
        # Send file
        await context.bot.send_document(
            chat_id=update.effective_user.id,
            document=output.getvalue().encode('utf-8'),
            filename=f'users_export_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv',
            caption=f"📊 Users Export - {len(users)} users"
        )
        
        await query.edit_message_text(f"✅ Exported {len(users)} users successfully!")
        
    except Exception as e:
        logger.error(f"Error exporting users: {e}")
        await query.edit_message_text("❌ Failed to export users.")
    finally:
        db_session.close()

async def admin_broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Broadcast message to users"""
    query = update.callback_query
    await query.edit_message_text(
        "📢 **Broadcast Message**\n\n"
        "Send the message you want to broadcast to all users:\n"
        "(You can use Markdown formatting and send images)"
    )
    context.user_data['admin_action'] = 'broadcast'
    return BROADCAST_MESSAGE

async def handle_broadcast_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle broadcast message input"""
    message = update.message
    
    context.user_data['broadcast_text'] = message.text_html if message.text else message.caption_html
    context.user_data['broadcast_has_media'] = bool(message.photo or message.document or message.video)
    
    if message.photo:
        context.user_data['broadcast_photo'] = message.photo[-1].file_id
        context.user_data['broadcast_caption'] = message.caption_html
    elif message.document:
        context.user_data['broadcast_document'] = message.document.file_id
        context.user_data['broadcast_caption'] = message.caption_html
    elif message.video:
        context.user_data['broadcast_video'] = message.video.file_id
        context.user_data['broadcast_caption'] = message.caption_html
    
    # Get user count
    db_session = get_db_session()
    bot_instance_id = context.bot_data.get('bot_instance_id')
    user_count = db_session.query(User).filter_by(
        bot_instance_id=bot_instance_id,
        status='active'
    ).count()
    db_session.close()
    
    preview_text = (
        "📢 **Broadcast Preview**\n\n"
        f"**Message:**\n{message.text_html if message.text else message.caption_html}\n\n"
        f"**Recipients:** {user_count} active users\n\n"
        "Send this message to all users?"
    )
    
    keyboard = [
        [InlineKeyboardButton("✅ Send to All", callback_data="broadcast_confirm")],
        [InlineKeyboardButton("❌ Cancel", callback_data="broadcast_cancel")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        preview_text,
        parse_mode='HTML',
        reply_markup=reply_markup
    )
    
    return CONFIRM_BROADCAST

async def execute_broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Execute broadcast to all users"""
    query = update.callback_query
    await query.answer()
    
    await query.edit_message_text("📤 Broadcasting message... This may take a while.")
    
    db_session = get_db_session()
    bot_instance_id = context.bot_data.get('bot_instance_id')
    
    try:
        users = db_session.query(User).filter_by(
            bot_instance_id=bot_instance_id,
            status='active'
        ).all()
        
        success_count = 0
        fail_count = 0
        
        for user in users:
            try:
                if 'broadcast_photo' in context.user_data:
                    await context.bot.send_photo(
                        chat_id=user.telegram_id,
                        photo=context.user_data['broadcast_photo'],
                        caption=context.user_data.get('broadcast_caption', ''),
                        parse_mode='HTML'
                    )
                elif 'broadcast_document' in context.user_data:
                    await context.bot.send_document(
                        chat_id=user.telegram_id,
                        document=context.user_data['broadcast_document'],
                        caption=context.user_data.get('broadcast_caption', ''),
                        parse_mode='HTML'
                    )
                elif 'broadcast_video' in context.user_data:
                    await context.bot.send_video(
                        chat_id=user.telegram_id,
                        video=context.user_data['broadcast_video'],
                        caption=context.user_data.get('broadcast_caption', ''),
                        parse_mode='HTML'
                    )
                else:
                    await context.bot.send_message(
                        chat_id=user.telegram_id,
                        text=context.user_data['broadcast_text'],
                        parse_mode='HTML'
                    )
                success_count += 1
            except Exception as e:
                logger.error(f"Broadcast failed for user {user.telegram_id}: {e}")
                fail_count += 1
        
        # Clear broadcast data
        for key in ['broadcast_text', 'broadcast_photo', 'broadcast_document', 
                   'broadcast_video', 'broadcast_caption', 'broadcast_has_media']:
            context.user_data.pop(key, None)
        
        await query.edit_message_text(
            f"✅ **Broadcast Complete**\n\n"
            f"✓ Sent: {success_count}\n"
            f"✗ Failed: {fail_count}\n"
            f"📊 Total: {len(users)}"
        )
        
    except Exception as e:
        logger.error(f"Broadcast error: {e}")
        await query.edit_message_text("❌ Broadcast failed.")
    finally:
        db_session.close()

async def admin_analytics(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show detailed analytics"""
    query = update.callback_query
    await query.answer()
    
    db_session = get_db_session()
    bot_instance_id = context.bot_data.get('bot_instance_id')
    
    try:
        # Time periods
        today = datetime.utcnow().date()
        week_ago = today - timedelta(days=7)
        month_ago = today - timedelta(days=30)
        
        # User growth
        new_users_today = db_session.query(User).filter(
            User.bot_instance_id == bot_instance_id,
            func.date(User.joined_date) == today
        ).count()
        
        new_users_week = db_session.query(User).filter(
            User.bot_instance_id == bot_instance_id,
            func.date(User.joined_date) >= week_ago
        ).count()
        
        new_users_month = db_session.query(User).filter(
            User.bot_instance_id == bot_instance_id,
            func.date(User.joined_date) >= month_ago
        ).count()
        
        # Revenue
        revenue_today = db_session.query(Transaction).filter(
            Transaction.status == 'completed',
            func.date(Transaction.date) == today
        ).with_entities(func.sum(Transaction.amount)).scalar() or 0
        
        revenue_week = db_session.query(Transaction).filter(
            Transaction.status == 'completed',
            func.date(Transaction.date) >= week_ago
        ).with_entities(func.sum(Transaction.amount)).scalar() or 0
        
        revenue_month = db_session.query(Transaction).filter(
            Transaction.status == 'completed',
            func.date(Transaction.date) >= month_ago
        ).with_entities(func.sum(Transaction.amount)).scalar() or 0
        
        # Image generation
        images_today = db_session.query(GeneratedImage).join(User).filter(
            User.bot_instance_id == bot_instance_id,
            func.date(GeneratedImage.generation_date) == today
        ).count()
        
        images_week = db_session.query(GeneratedImage).join(User).filter(
            User.bot_instance_id == bot_instance_id,
            func.date(GeneratedImage.generation_date) >= week_ago
        ).count()
        
        images_month = db_session.query(GeneratedImage).join(User).filter(
            User.bot_instance_id == bot_instance_id,
            func.date(GeneratedImage.generation_date) >= month_ago
        ).count()
        
        # Top users by spending
        top_users = db_session.query(
            User,
            func.sum(Transaction.amount).label('total_spent')
        ).join(Transaction).filter(
            User.bot_instance_id == bot_instance_id,
            Transaction.status == 'completed'
        ).group_by(User).order_by(func.sum(Transaction.amount).desc()).limit(5).all()
        
        # Popular prompts
        popular_prompts = db_session.query(
            GeneratedImage.prompt,
            func.count().label('count')
        ).join(User).filter(
            User.bot_instance_id == bot_instance_id
        ).group_by(GeneratedImage.prompt).order_by(func.count().desc()).limit(5).all()
        
        analytics_text = (
            "📈 **Analytics Dashboard**\n\n"
            "**User Growth:**\n"
            f"Today: **+{new_users_today}**\n"
            f"This Week: **+{new_users_week}**\n"
            f"This Month: **+{new_users_month}**\n\n"
            "**Revenue:**\n"
            f"Today: **₹{revenue_today:,.2f}**\n"
            f"This Week: **₹{revenue_week:,.2f}**\n"
            f"This Month: **₹{revenue_month:,.2f}**\n\n"
            "**Image Generation:**\n"
            f"Today: **{images_today}**\n"
            f"This Week: **{images_week}**\n"
            f"This Month: **{images_month}**\n\n"
        )
        
        if top_users:
            analytics_text += "**Top Spenders:**\n"
            for user, spent in top_users:
                analytics_text += f"• {user.first_name}: **₹{spent:,.2f}**\n"
            analytics_text += "\n"
        
        if popular_prompts:
            analytics_text += "**Popular Prompts:**\n"
            for prompt, count in popular_prompts:
                analytics_text += f"• {prompt[:30]}...: **{count}** times\n"
        
        keyboard = [
            [InlineKeyboardButton("📊 Export Report", callback_data="admin_export_report")],
            [InlineKeyboardButton("🔙 Back", callback_data="admin_back")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(
            analytics_text,
            parse_mode='Markdown',
            reply_markup=reply_markup
        )
        
    except Exception as e:
        logger.error(f"Error in analytics: {e}")
        await query.edit_message_text("❌ An error occurred.")
    finally:
        db_session.close()

async def admin_export_report(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Export analytics report"""
    query = update.callback_query
    await query.answer()
    
    db_session = get_db_session()
    bot_instance_id = context.bot_data.get('bot_instance_id')
    
    try:
        # Create report data
        output = StringIO()
        writer = csv.writer(output)
        
        # User summary
        writer.writerow(['User Summary'])
        writer.writerow(['Total Users', db_session.query(User).filter_by(bot_instance_id=bot_instance_id).count()])
        writer.writerow(['Active Today', db_session.query(User).filter(
            User.bot_instance_id == bot_instance_id,
            User.last_active >= datetime.utcnow() - timedelta(days=1)
        ).count()])
        writer.writerow([])
        
        # Revenue summary
        total_revenue = db_session.query(Transaction).filter(
            Transaction.status == 'completed'
        ).with_entities(func.sum(Transaction.amount)).scalar() or 0
        
        writer.writerow(['Revenue Summary'])
        writer.writerow(['Total Revenue', f"₹{total_revenue:,.2f}"])
        writer.writerow([])
        
        # Recent transactions
        writer.writerow(['Recent Transactions'])
        writer.writerow(['Date', 'User', 'Amount', 'Credits', 'Status'])
        
        transactions = db_session.query(Transaction).order_by(
            Transaction.date.desc()
        ).limit(50).all()
        
        for t in transactions:
            writer.writerow([
                t.date.strftime('%Y-%m-%d %H:%M'),
                t.user_id,
                f"₹{t.amount}",
                t.credits,
                t.status
            ])
        
        # Send file
        await context.bot.send_document(
            chat_id=update.effective_user.id,
            document=output.getvalue().encode('utf-8'),
            filename=f'report_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv',
            caption="📊 Analytics Report"
        )
        
        await query.edit_message_text("✅ Report exported successfully!")
        
    except Exception as e:
        logger.error(f"Error exporting report: {e}")
        await query.edit_message_text("❌ Failed to export report.")
    finally:
        db_session.close()

@admin_required
async def block_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Block a user (command version)"""
    try:
        user_id = context.args[0]
        db_session = get_db_session()
        bot_instance_id = context.bot_data.get('bot_instance_id')
        
        user = db_session.query(User).filter_by(
            telegram_id=user_id,
            bot_instance_id=bot_instance_id
        ).first()
        
        if user:
            user.status = 'blocked'
            db_session.commit()
            await update.message.reply_text(f"✅ User {user_id} has been blocked.")
        else:
            await update.message.reply_text("❌ User not found.")
        
        db_session.close()
    except IndexError:
        await update.message.reply_text("Usage: /block <user_id>")

@admin_required
async def unblock_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Unblock a user (command version)"""
    try:
        user_id = context.args[0]
        db_session = get_db_session()
        bot_instance_id = context.bot_data.get('bot_instance_id')
        
        user = db_session.query(User).filter_by(
            telegram_id=user_id,
            bot_instance_id=bot_instance_id
        ).first()
        
        if user:
            user.status = 'active'
            db_session.commit()
            await update.message.reply_text(f"✅ User {user_id} has been unblocked.")
        else:
            await update.message.reply_text("❌ User not found.")
        
        db_session.close()
    except IndexError:
        await update.message.reply_text("Usage: /unblock <user_id>")

@admin_required
async def add_credits(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Add credits to user (command version)"""
    try:
        user_id = context.args[0]
        credits = int(context.args[1])
        
        db_session = get_db_session()
        bot_instance_id = context.bot_data.get('bot_instance_id')
        
        user = db_session.query(User).filter_by(
            telegram_id=user_id,
            bot_instance_id=bot_instance_id
        ).first()
        
        if user:
            old_balance = user.credits_balance
            user.credits_balance += credits
            db_session.commit()
            
            # Notify user
            try:
                await context.bot.send_message(
                    chat_id=user_id,
                    text=f"✨ **Credits Added!**\n\n"
                         f"Admin has added **{credits} credits** to your account.\n"
                         f"New balance: **{user.credits_balance} credits**"
                )
            except:
                pass
            
            await update.message.reply_text(
                f"✅ Added {credits} credits to user {user_id}\n"
                f"Old balance: {old_balance}\n"
                f"New balance: {user.credits_balance}"
            )
        else:
            await update.message.reply_text("❌ User not found.")
        
        db_session.close()
    except (IndexError, ValueError):
        await update.message.reply_text("Usage: /addcredits <user_id> <amount>")

@admin_required
async def broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Broadcast message (command version)"""
    if not context.args:
        await update.message.reply_text(
            "Usage: /broadcast <message>\n"
            "Example: /broadcast Hello everyone!"
        )
        return
    
    message = ' '.join(context.args)
    context.user_data['broadcast_text'] = message
    
    # Get user count
    db_session = get_db_session()
    bot_instance_id = context.bot_data.get('bot_instance_id')
    user_count = db_session.query(User).filter_by(
        bot_instance_id=bot_instance_id,
        status='active'
    ).count()
    db_session.close()
    
    keyboard = [
        [InlineKeyboardButton("✅ Send to All", callback_data="broadcast_confirm")],
        [InlineKeyboardButton("❌ Cancel", callback_data="broadcast_cancel")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        f"📢 **Broadcast Preview**\n\n"
        f"Message: {message}\n"
        f"Recipients: {user_count} active users\n\n"
        "Send this message?",
        reply_markup=reply_markup
    )

@admin_required
async def stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Quick stats command"""
    db_session = get_db_session()
    bot_instance_id = context.bot_data.get('bot_instance_id')
    
    try:
        total_users = db_session.query(User).filter_by(bot_instance_id=bot_instance_id).count()
        active_today = db_session.query(User).filter(
            User.bot_instance_id == bot_instance_id,
            User.last_active >= datetime.utcnow() - timedelta(days=1)
        ).count()
        
        total_images = db_session.query(GeneratedImage).join(User).filter(
            User.bot_instance_id == bot_instance_id
        ).count()
        
        total_revenue = db_session.query(Transaction).filter(
            Transaction.status == 'completed'
        ).with_entities(func.sum(Transaction.amount)).scalar() or 0
        
        stats_text = (
            "📊 **Quick Stats**\n\n"
            f"👥 Total Users: **{total_users}**\n"
            f"📱 Active Today: **{active_today}**\n"
            f"🖼️ Images Generated: **{total_images}**\n"
            f"💰 Total Revenue: **₹{total_revenue:,.2f}**"
        )
        
        await update.message.reply_text(stats_text, parse_mode='Markdown')
        
    except Exception as e:
        logger.error(f"Error in stats: {e}")
        await update.message.reply_text("❌ An error occurred.")
    finally:
        db_session.close()