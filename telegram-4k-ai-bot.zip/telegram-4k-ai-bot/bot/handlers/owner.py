"""
Owner/Super Admin command handlers
"""

import logging
import secrets
import hashlib
from datetime import datetime, timedelta
from typing import Optional, List, Dict
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler
from sqlalchemy import func
from bot.utils.database import get_db_session
from bot.utils.decorators import owner_required
from bot.utils.helpers import hash_password, verify_password
from models import Owner, Admin, BotInstance, User, Transaction, GeneratedImage

logger = logging.getLogger(__name__)

# Owner conversation states
NEW_BOT_TOKEN, NEW_BOT_SETTINGS, ADMIN_USERNAME, ADMIN_PASSWORD = range(4)

@owner_required
async def owner_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Main owner panel"""
    keyboard = [
        [InlineKeyboardButton("🤖 Bot Management", callback_data="owner_bots")],
        [InlineKeyboardButton("👥 Admin Management", callback_data="owner_admins")],
        [InlineKeyboardButton("💰 Financial Reports", callback_data="owner_finance")],
        [InlineKeyboardButton("⚙️ System Settings", callback_data="owner_system")],
        [InlineKeyboardButton("📊 Multi-Bot Dashboard", callback_data="owner_dashboard")],
        [InlineKeyboardButton("🔐 Security", callback_data="owner_security")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        "👑 **Owner Control Panel**\n\n"
        "Super admin access. Select an option:",
        parse_mode='Markdown',
        reply_markup=reply_markup
    )

async def owner_bots(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Bot management panel"""
    query = update.callback_query
    await query.answer()
    
    db_session = get_db_session()
    
    try:
        owner = db_session.query(Owner).filter_by(
            username=update.effective_user.username
        ).first()
        
        bots = db_session.query(BotInstance).filter_by(owner_id=owner.id).all()
        
        text = "🤖 **Bot Instances**\n\n"
        
        for bot in bots:
            admin = db_session.query(Admin).filter_by(id=bot.admin_id).first() if bot.admin_id else None
            user_count = db_session.query(User).filter_by(bot_instance_id=bot.id).count()
            
            status_emoji = '🟢' if bot.status == 'active' else '🔴'
            text += (
                f"{status_emoji} **@{bot.bot_username or 'Unnamed'}**\n"
                f"ID: `{bot.id}`\n"
                f"Status: {bot.status}\n"
                f"Admin: @{admin.username if admin else 'None'}\n"
                f"Users: {user_count}\n"
                f"Created: {bot.created_at.strftime('%d %b %Y')}\n\n"
            )
        
        keyboard = [
            [InlineKeyboardButton("➕ Create New Bot", callback_data="owner_create_bot")],
            [InlineKeyboardButton("🔧 Configure Bot", callback_data="owner_configure_bot")],
            [InlineKeyboardButton("📊 Bot Stats", callback_data="owner_bot_stats")],
            [InlineKeyboardButton("🔙 Back", callback_data="owner_back")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(text, parse_mode='Markdown', reply_markup=reply_markup)
        
    except Exception as e:
        logger.error(f"Error in owner_bots: {e}")
        await query.edit_message_text("❌ An error occurred.")
    finally:
        db_session.close()

async def owner_create_bot(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Create new bot instance"""
    query = update.callback_query
    await query.edit_message_text(
        "🤖 **Create New Bot Instance**\n\n"
        "Please send me the bot token from @BotFather:\n"
        "Format: `1234567890:ABCdefGHIjklMNOpqrsTUVwxyz`"
    )
    context.user_data['owner_action'] = 'create_bot'
    return NEW_BOT_TOKEN

async def handle_new_bot_token(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle new bot token"""
    token = update.message.text.strip()
    
    # Basic validation
    if len(token.split(':')) != 2:
        await update.message.reply_text("❌ Invalid token format. Please try again.")
        return NEW_BOT_TOKEN
    
    context.user_data['new_bot_token'] = token
    
    # Get bot info (try to fetch)
    try:
        # This is a placeholder - actual bot validation would require creating a temporary bot instance
        bot_username = f"bot_{token[:8].lower()}"
        context.user_data['new_bot_username'] = bot_username
    except:
        context.user_data['new_bot_username'] = "pending"
    
    keyboard = [
        [InlineKeyboardButton("✅ Confirm", callback_data="confirm_create_bot")],
        [InlineKeyboardButton("❌ Cancel", callback_data="owner_bots")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        f"🤖 **Bot Details**\n\n"
        f"Token: `{token[:10]}...`\n"
        f"Username: @{context.user_data.get('new_bot_username', 'Unknown')}\n\n"
        f"Confirm creation?",
        parse_mode='Markdown',
        reply_markup=reply_markup
    )
    
    return NEW_BOT_SETTINGS

async def confirm_create_bot(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Confirm and create new bot"""
    query = update.callback_query
    await query.answer()
    
    db_session = get_db_session()
    
    try:
        owner = db_session.query(Owner).filter_by(
            username=update.effective_user.username
        ).first()
        
        # Check if token already exists
        existing = db_session.query(BotInstance).filter_by(
            bot_token=context.user_data['new_bot_token']
        ).first()
        
        if existing:
            await query.edit_message_text("❌ Bot token already exists!")
            db_session.close()
            return
        
        # Create new bot instance
        new_bot = BotInstance(
            bot_token=context.user_data['new_bot_token'],
            bot_username=context.user_data.get('new_bot_username'),
            owner_id=owner.id,
            status='inactive',
            config={
                'price_plans': {
                    100: 50,
                    500: 200,
                    1000: 400
                },
                'generation_cost': 10,
                'welcome_bonus': 5,
                'referral_bonus': 10,
                'concurrent_generations': 5,
                'rate_limit': 10
            }
        )
        
        db_session.add(new_bot)
        db_session.commit()
        
        await query.edit_message_text(
            f"✅ **Bot Created Successfully!**\n\n"
            f"Bot ID: `{new_bot.id}`\n"
            f"Username: @{new_bot.bot_username}\n\n"
            f"**Next steps:**\n"
            f"1. Configure API keys\n"
            f"2. Set up payment gateway\n"
            f"3. Assign an admin\n"
            f"4. Activate the bot\n\n"
            f"Use /owner to return to main panel."
        )
        
    except Exception as e:
        logger.error(f"Error creating bot: {e}")
        await query.edit_message_text("❌ Failed to create bot.")
    finally:
        db_session.close()
        context.user_data.clear()

async def owner_configure_bot(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Configure existing bot"""
    query = update.callback_query
    await query.answer()
    
    db_session = get_db_session()
    
    try:
        owner = db_session.query(Owner).filter_by(
            username=update.effective_user.username
        ).first()
        
        bots = db_session.query(BotInstance).filter_by(owner_id=owner.id).all()
        
        if not bots:
            await query.edit_message_text("No bots found. Create one first.")
            return
        
        keyboard = []
        for bot in bots:
            keyboard.append([
                InlineKeyboardButton(
                    f"@{bot.bot_username or bot.id}",
                    callback_data=f"config_bot_{bot.id}"
                )
            ])
        
        keyboard.append([InlineKeyboardButton("🔙 Back", callback_data="owner_bots")])
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(
            "🔧 **Select bot to configure:**",
            reply_markup=reply_markup
        )
        
    except Exception as e:
        logger.error(f"Error in configure_bot: {e}")
        await query.edit_message_text("❌ An error occurred.")
    finally:
        db_session.close()

async def owner_bot_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """View detailed bot statistics"""
    query = update.callback_query
    await query.answer()
    
    db_session = get_db_session()
    
    try:
        owner = db_session.query(Owner).filter_by(
            username=update.effective_user.username
        ).first()
        
        bots = db_session.query(BotInstance).filter_by(owner_id=owner.id).all()
        
        if not bots:
            await query.edit_message_text("No bots found.")
            return
        
        text = "📊 **Bot Statistics Overview**\n\n"
        
        for bot in bots:
            # Get bot stats
            user_count = db_session.query(User).filter_by(bot_instance_id=bot.id).count()
            active_today = db_session.query(User).filter(
                User.bot_instance_id == bot.id,
                User.last_active >= datetime.utcnow() - timedelta(days=1)
            ).count()
            
            image_count = db_session.query(GeneratedImage).join(User).filter(
                User.bot_instance_id == bot.id
            ).count()
            
            revenue = db_session.query(Transaction).join(User).filter(
                Transaction.status == 'completed',
                User.bot_instance_id == bot.id
            ).with_entities(func.sum(Transaction.amount)).scalar() or 0
            
            status_emoji = '🟢' if bot.status == 'active' else '🔴'
            text += (
                f"{status_emoji} **@{bot.bot_username or bot.id}**\n"
                f"Users: {user_count} (📱 {active_today} today)\n"
                f"Images: {image_count}\n"
                f"Revenue: ₹{revenue:,.2f}\n\n"
            )
        
        keyboard = [[InlineKeyboardButton("🔙 Back", callback_data="owner_bots")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(text, parse_mode='Markdown', reply_markup=reply_markup)
        
    except Exception as e:
        logger.error(f"Error in bot_stats: {e}")
        await query.edit_message_text("❌ An error occurred.")
    finally:
        db_session.close()

async def owner_admins(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Admin management panel"""
    query = update.callback_query
    await query.answer()
    
    db_session = get_db_session()
    
    try:
        admins = db_session.query(Admin).filter_by(role='admin').all()
        
        text = "👥 **Admin Management**\n\n"
        
        for admin in admins:
            bot = db_session.query(BotInstance).filter_by(id=admin.bot_instance_id).first() if admin.bot_instance_id else None
            text += (
                f"**@{admin.username}**\n"
                f"ID: `{admin.id}`\n"
                f"Bot: @{bot.bot_username if bot else 'Not assigned'}\n"
                f"Last Login: {admin.last_login.strftime('%d %b %Y %H:%M') if admin.last_login else 'Never'}\n"
                f"Status: {admin.status}\n\n"
            )
        
        keyboard = [
            [InlineKeyboardButton("➕ Create Admin", callback_data="owner_create_admin")],
            [InlineKeyboardButton("🔑 Generate Referral Code", callback_data="owner_gen_ref")],
            [InlineKeyboardButton("📊 Admin Activity", callback_data="owner_admin_activity")],
            [InlineKeyboardButton("🔙 Back", callback_data="owner_back")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(text, parse_mode='Markdown', reply_markup=reply_markup)
        
    except Exception as e:
        logger.error(f"Error in owner_admins: {e}")
        await query.edit_message_text("❌ An error occurred.")
    finally:
        db_session.close()

async def owner_create_admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Create new admin"""
    query = update.callback_query
    await query.edit_message_text(
        "👤 **Create New Admin**\n\n"
        "Enter username for new admin (without @):"
    )
    context.user_data['owner_action'] = 'create_admin'
    return ADMIN_USERNAME

async def handle_admin_username(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle admin username input"""
    username = update.message.text.strip().replace('@', '')
    
    db_session = get_db_session()
    
    try:
        # Check if username exists
        existing = db_session.query(Admin).filter_by(username=username).first()
        if existing:
            await update.message.reply_text("❌ Username already exists. Choose another:")
            db_session.close()
            return ADMIN_USERNAME
        
        context.user_data['new_admin_username'] = username
        
        # Generate random password
        password = secrets.token_urlsafe(12)
        context.user_data['new_admin_password'] = password
        
        # Show bot selection
        owner = db_session.query(Owner).filter_by(
            username=update.effective_user.username
        ).first()
        
        bots = db_session.query(BotInstance).filter_by(owner_id=owner.id).all()
        
        keyboard = []
        for bot in bots:
            keyboard.append([
                InlineKeyboardButton(
                    f"@{bot.bot_username}",
                    callback_data=f"assign_bot_{bot.id}"
                )
            ])
        
        keyboard.append([InlineKeyboardButton("⏭️ Assign Later", callback_data="assign_bot_none")])
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            f"👤 **New Admin Details**\n\n"
            f"Username: @{username}\n"
            f"Password: `{password}`\n\n"
            f"**Select bot to assign:**",
            parse_mode='Markdown',
            reply_markup=reply_markup
        )
        
    except Exception as e:
        logger.error(f"Error creating admin: {e}")
        await update.message.reply_text("❌ An error occurred.")
    finally:
        db_session.close()
    
    return ADMIN_PASSWORD

async def assign_bot_to_admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Assign bot to new admin"""
    query = update.callback_query
    await query.answer()
    
    bot_id = query.data.replace('assign_bot_', '')
    if bot_id != 'none':
        context.user_data['new_admin_bot_id'] = int(bot_id)
    
    db_session = get_db_session()
    
    try:
        # Hash password
        password_hash = hashlib.sha256(
            context.user_data['new_admin_password'].encode()
        ).hexdigest()
        
        # Create admin
        new_admin = Admin(
            username=context.user_data['new_admin_username'],
            password_hash=password_hash,
            role='admin',
            bot_instance_id=context.user_data.get('new_admin_bot_id'),
            permissions={
                'manage_users': True,
                'manage_credits': True,
                'broadcast': True,
                'view_analytics': True,
                'export_data': True
            },
            created_by=update.effective_user.id,
            status='active'
        )
        
        db_session.add(new_admin)
        db_session.commit()
        
        # Send credentials to owner
        await query.edit_message_text(
            f"✅ **Admin Created Successfully!**\n\n"
            f"**Username:** @{new_admin.username}\n"
            f"**Password:** `{context.user_data['new_admin_password']}`\n\n"
            f"Share these credentials securely with the admin.\n"
            f"They can login at: https://yourdomain.com/admin"
        )
        
    except Exception as e:
        logger.error(f"Error assigning bot: {e}")
        await query.edit_message_text("❌ Failed to create admin.")
    finally:
        db_session.close()
        context.user_data.clear()

async def owner_finance(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Financial reports"""
    query = update.callback_query
    await query.answer()
    
    db_session = get_db_session()
    
    try:
        owner = db_session.query(Owner).filter_by(
            username=update.effective_user.username
        ).first()
        
        # Get all bots for this owner
        bot_ids = [bot.id for bot in db_session.query(BotInstance).filter_by(owner_id=owner.id).all()]
        
        if not bot_ids:
            await query.edit_message_text("No bots found.")
            return
        
        # Overall statistics
        total_revenue = db_session.query(Transaction).filter(
            Transaction.status == 'completed'
        ).with_entities(func.sum(Transaction.amount)).scalar() or 0
        
        total_credits_sold = db_session.query(Transaction).filter(
            Transaction.status == 'completed'
        ).with_entities(func.sum(Transaction.credits)).scalar() or 0
        
        total_users = db_session.query(User).filter(
            User.bot_instance_id.in_(bot_ids)
        ).count()
        
        # Monthly breakdown
        current_month = datetime.utcnow().replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        monthly_revenue = db_session.query(Transaction).filter(
            Transaction.status == 'completed',
            Transaction.date >= current_month
        ).with_entities(func.sum(Transaction.amount)).scalar() or 0
        
        # Per bot breakdown
        bot_stats = []
        for bot_id in bot_ids:
            bot = db_session.query(BotInstance).get(bot_id)
            bot_revenue = db_session.query(Transaction).join(User).filter(
                Transaction.status == 'completed',
                User.bot_instance_id == bot_id
            ).with_entities(func.sum(Transaction.amount)).scalar() or 0
            
            bot_users = db_session.query(User).filter_by(bot_instance_id=bot_id).count()
            
            bot_stats.append({
                'name': bot.bot_username or f"Bot {bot_id}",
                'revenue': bot_revenue,
                'users': bot_users
            })
        
        text = (
            "💰 **Financial Overview**\n\n"
            f"**Overall Statistics:**\n"
            f"Total Revenue: **₹{total_revenue:,.2f}**\n"
            f"Total Credits Sold: **{total_credits_sold:,}**\n"
            f"Total Users: **{total_users:,}**\n"
            f"Monthly Revenue: **₹{monthly_revenue:,.2f}**\n\n"
            f"**Per Bot Breakdown:**\n"
        )
        
        for stat in bot_stats:
            text += f"• @{stat['name']}: **₹{stat['revenue']:,.2f}** ({stat['users']} users)\n"
        
        keyboard = [
            [InlineKeyboardButton("📊 Detailed Report", callback_data="owner_detailed_finance")],
            [InlineKeyboardButton("📈 Revenue Chart", callback_data="owner_revenue_chart")],
            [InlineKeyboardButton("💳 Transaction Logs", callback_data="owner_transactions")],
            [InlineKeyboardButton("🔙 Back", callback_data="owner_back")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(text, parse_mode='Markdown', reply_markup=reply_markup)
        
    except Exception as e:
        logger.error(f"Error in owner_finance: {e}")
        await query.edit_message_text("❌ An error occurred.")
    finally:
        db_session.close()

async def owner_detailed_finance(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Detailed financial report"""
    query = update.callback_query
    await query.answer()
    
    db_session = get_db_session()
    
    try:
        owner = db_session.query(Owner).filter_by(
            username=update.effective_user.username
        ).first()
        
        bot_ids = [bot.id for bot in db_session.query(BotInstance).filter_by(owner_id=owner.id).all()]
        
        # Daily revenue for last 30 days
        end_date = datetime.utcnow().date()
        start_date = end_date - timedelta(days=30)
        
        daily_revenue = []
        current = start_date
        while current <= end_date:
            next_day = current + timedelta(days=1)
            revenue = db_session.query(Transaction).filter(
                Transaction.status == 'completed',
                Transaction.date >= current,
                Transaction.date < next_day
            ).with_entities(func.sum(Transaction.amount)).scalar() or 0
            
            daily_revenue.append({
                'date': current.strftime('%Y-%m-%d'),
                'revenue': revenue
            })
            current = next_day
        
        # Top transactions
        top_transactions = db_session.query(Transaction).filter(
            Transaction.status == 'completed'
        ).order_by(Transaction.amount.desc()).limit(10).all()
        
        text = (
            "📊 **Detailed Financial Report**\n\n"
            "**Daily Revenue (Last 7 days):**\n"
        )
        
        for day in daily_revenue[-7:]:
            text += f"• {day['date']}: **₹{day['revenue']:,.2f}**\n"
        
        text += "\n**Top Transactions:**\n"
        for t in top_transactions:
            text += f"• ₹{t.amount} - {t.date.strftime('%d %b')}\n"
        
        keyboard = [
            [InlineKeyboardButton("📥 Export Full Report", callback_data="owner_export_finance")],
            [InlineKeyboardButton("🔙 Back", callback_data="owner_finance")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(text, parse_mode='Markdown', reply_markup=reply_markup)
        
    except Exception as e:
        logger.error(f"Error in detailed_finance: {e}")
        await query.edit_message_text("❌ An error occurred.")
    finally:
        db_session.close()

async def owner_system(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """System settings"""
    query = update.callback_query
    await query.answer()
    
    db_session = get_db_session()
    
    try:
        # Get current settings
        owner = db_session.query(Owner).filter_by(
            username=update.effective_user.username
        ).first()
        settings = owner.settings or {}
        
        text = (
            "⚙️ **System Settings**\n\n"
            f"**Maintenance Mode:** {'🔴 ON' if settings.get('maintenance_mode') else '🟢 OFF'}\n"
            f"**Rate Limit:** {settings.get('rate_limit', 10)} requests/minute\n"
            f"**Concurrent Generations:** {settings.get('concurrent_limit', 5)}\n"
            f"**Auto-moderation:** {'✅' if settings.get('auto_moderate', True) else '❌'}\n"
            f"**Backup Frequency:** {settings.get('backup_frequency', 'daily')}\n\n"
            f"**API Status:**\n"
            f"• Stable Diffusion: ✅ Online\n"
            f"• Razorpay: ✅ Connected\n"
            f"• Database: ✅ Healthy\n"
            f"• Redis: ✅ Running\n\n"
            f"**Last Backup:** {settings.get('last_backup', 'Never')}"
        )
        
        keyboard = [
            [InlineKeyboardButton("🔧 Configure Settings", callback_data="owner_configure_system")],
            [InlineKeyboardButton("🔄 Toggle Maintenance", callback_data="owner_toggle_maintenance")],
            [InlineKeyboardButton("💾 Backup Now", callback_data="owner_backup")],
            [InlineKeyboardButton("📊 System Health", callback_data="owner_health")],
            [InlineKeyboardButton("🔙 Back", callback_data="owner_back")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(text, parse_mode='Markdown', reply_markup=reply_markup)
        
    except Exception as e:
        logger.error(f"Error in owner_system: {e}")
        await query.edit_message_text("❌ An error occurred.")
    finally:
        db_session.close()

async def owner_toggle_maintenance(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Toggle maintenance mode"""
    query = update.callback_query
    await query.answer()
    
    db_session = get_db_session()
    
    try:
        owner = db_session.query(Owner).filter_by(
            username=update.effective_user.username
        ).first()
        
        settings = owner.settings or {}
        current = settings.get('maintenance_mode', False)
        settings['maintenance_mode'] = not current
        owner.settings = settings
        db_session.commit()
        
        status = "ENABLED" if not current else "DISABLED"
        
        await query.edit_message_text(
            f"✅ Maintenance mode {status}!\n\n"
            f"All bots are now {'in' if not current else 'out of'} maintenance mode."
        )
        
    except Exception as e:
        logger.error(f"Error toggling maintenance: {e}")
        await query.edit_message_text("❌ Failed to toggle maintenance mode.")
    finally:
        db_session.close()

async def owner_backup(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Trigger manual backup"""
    query = update.callback_query
    await query.answer()
    
    await query.edit_message_text("💾 Starting backup... This may take a few minutes.")
    
    # This would call your backup script
    # import subprocess
    # subprocess.run(["./scripts/backup.sh"])
    
    await asyncio.sleep(3)  # Simulate backup
    
    db_session = get_db_session()
    try:
        owner = db_session.query(Owner).filter_by(
            username=update.effective_user.username
        ).first()
        
        settings = owner.settings or {}
        settings['last_backup'] = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
        owner.settings = settings
        db_session.commit()
    finally:
        db_session.close()
    
    await query.edit_message_text(
        "✅ **Backup Complete!**\n\n"
        "Database and images have been backed up successfully."
    )

async def owner_health(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """System health check"""
    query = update.callback_query
    await query.answer()
    
    # This would do actual health checks
    # For now, return mock data
    
    health_text = (
        "📊 **System Health**\n\n"
        "**Database:** ✅ Healthy\n"
        "   • Connections: 5/100\n"
        "   • Size: 2.3 GB\n"
        "   • Uptime: 15 days\n\n"
        "**Redis:** ✅ Healthy\n"
        "   • Memory: 45 MB\n"
        "   • Keys: 1,234\n"
        "   • Hit rate: 98%\n\n"
        "**Queue System:** ✅ Running\n"
        "   • Pending: 3\n"
        "   • Processing: 2\n"
        "   • Failed: 0\n\n"
        "**Storage:** ✅ 67% used\n"
        "   • Images: 15.3 GB\n"
        "   • Backups: 45.2 GB\n"
        "   • Available: 30.5 GB\n\n"
        "**API Services:**\n"
        "   • AI Generation: ✅ 230ms\n"
        "   • Razorpay: ✅ 180ms\n"
        "   • Cloud Storage: ✅ 340ms"
    )
    
    keyboard = [[InlineKeyboardButton("🔄 Refresh", callback_data="owner_health")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(health_text, reply_markup=reply_markup)

async def owner_dashboard(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Multi-bot dashboard"""
    query = update.callback_query
    await query.answer()
    
    db_session = get_db_session()
    
    try:
        owner = db_session.query(Owner).filter_by(
            username=update.effective_user.username
        ).first()
        
        bots = db_session.query(BotInstance).filter_by(owner_id=owner.id).all()
        
        text = "📊 **Multi-Bot Dashboard**\n\n"
        
        total_users = 0
        total_images = 0
        total_revenue = 0
        
        for bot in bots:
            # Get bot stats
            users_count = db_session.query(User).filter_by(bot_instance_id=bot.id).count()
            active_today = db_session.query(User).filter(
                User.bot_instance_id == bot.id,
                User.last_active >= datetime.utcnow() - timedelta(days=1)
            ).count()
            
            images_count = db_session.query(GeneratedImage).join(User).filter(
                User.bot_instance_id == bot.id
            ).count()
            
            revenue = db_session.query(Transaction).join(User).filter(
                Transaction.status == 'completed',
                User.bot_instance_id == bot.id
            ).with_entities(func.sum(Transaction.amount)).scalar() or 0
            
            total_users += users_count
            total_images += images_count
            total_revenue += revenue
            
            status_emoji = '🟢' if bot.status == 'active' else '🔴'
            admin = db_session.query(Admin).filter_by(id=bot.admin_id).first() if bot.admin_id else None
            
            text += (
                f"{status_emoji} **@{bot.bot_username or f'Bot {bot.id}'}**\n"
                f"  Users: {users_count} (📱 {active_today} today)\n"
                f"  Images: {images_count}\n"
                f"  Revenue: ₹{revenue:,.2f}\n"
                f"  Admin: @{admin.username if admin else 'Not assigned'}\n\n"
            )
        
        text += (
            "**Summary:**\n"
            f"• Total Users: **{total_users}**\n"
            f"• Total Images: **{total_images}**\n"
            f"• Total Revenue: **₹{total_revenue:,.2f}**"
        )
        
        keyboard = [
            [InlineKeyboardButton("🔄 Refresh", callback_data="owner_dashboard")],
            [InlineKeyboardButton("🔙 Back", callback_data="owner_back")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(text, parse_mode='Markdown', reply_markup=reply_markup)
        
    except Exception as e:
        logger.error(f"Error in owner_dashboard: {e}")
        await query.edit_message_text("❌ An error occurred.")
    finally:
        db_session.close()

async def owner_security(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Security settings"""
    query = update.callback_query
    await query.answer()
    
    text = (
        "🔐 **Security Settings**\n\n"
        "**2FA Status:**\n"
        "• Owner Account: ✅ Enabled\n"
        "• Admin Accounts: ⚠️ Optional\n\n"
        "**Active Sessions:**\n"
        "• Web Panel: 2 active sessions\n"
        "• API Keys: 3 keys valid\n\n"
        "**Recent Activity:**\n"
        "• Login: 2 hours ago (IP: 192.168.1.1)\n"
        "• Settings Change: 1 day ago\n"
        "• New Admin Created: 3 days ago\n\n"
        "**Security Recommendations:**\n"
        "• Enable 2FA for all admins\n"
        "• Rotate API keys every 30 days\n"
        "• Review access logs weekly\n"
        "• Set up IP whitelisting"
    )
    
    keyboard = [
        [InlineKeyboardButton("🔑 Manage API Keys", callback_data="owner_api_keys")],
        [InlineKeyboardButton("👁️ View Access Logs", callback_data="owner_access_logs")],
        [InlineKeyboardButton("🔒 2FA Settings", callback_data="owner_2fa")],
        [InlineKeyboardButton("📋 Security Audit", callback_data="owner_audit")],
        [InlineKeyboardButton("🔙 Back", callback_data="owner_back")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(text, parse_mode='Markdown', reply_markup=reply_markup)

@owner_required
async def manage_admins(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Manage admins command"""
    db_session = get_db_session()
    
    try:
        admins = db_session.query(Admin).all()
        
        text = "👥 **Admin List**\n\n"
        for admin in admins:
            text += f"• @{admin.username} - {admin.role} - {'Active' if admin.status == 'active' else 'Inactive'}\n"
        
        await update.message.reply_text(text, parse_mode='Markdown')
        
    except Exception as e:
        logger.error(f"Error in manage_admins: {e}")
        await update.message.reply_text("❌ An error occurred.")
    finally:
        db_session.close()

@owner_required
async def bot_config(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Configure bot settings command"""
    help_text = (
        "⚙️ **Bot Configuration Commands**\n\n"
        "/setprice <credits> <price> - Set price plan\n"
        "/setcost <credits> - Set generation cost\n"
        "/setbonus <credits> - Set welcome bonus\n"
        "/setreferral <credits> - Set referral bonus\n"
        "/apikey <key> - Set AI API key\n"
        "/razorpay <key> <secret> - Set payment keys\n"
        "/activate <bot_id> - Activate a bot\n"
        "/deactivate <bot_id> - Deactivate a bot\n"
        "/deletebot <bot_id> - Delete a bot instance"
    )
    
    await update.message.reply_text(help_text, parse_mode='Markdown')

@owner_required
async def system_settings(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """System settings command"""
    help_text = (
        "⚙️ **System Settings Commands**\n\n"
        "/maintenance on/off - Toggle maintenance mode\n"
        "/ratelimit <number> - Set global rate limit\n"
        "/concurrent <number> - Set concurrent generations\n"
        "/backup - Manual backup\n"
        "/logs - View error logs\n"
        "/restart - Restart all bots\n"
        "/status - System status"
    )
    
    await update.message.reply_text(help_text, parse_mode='Markdown')