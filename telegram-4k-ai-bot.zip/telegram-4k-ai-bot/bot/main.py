#!/usr/bin/env python3
"""
Main bot application with multi-instance support
"""

import logging
import asyncio
from typing import Dict, Optional
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    MessageHandler, filters, ConversationHandler
)
from telegram import Update
from config.settings import config
from bot.handlers.user import (
    start, balance, generate, recharge, history,
    referral, help_command, settings, handle_prompt,
    handle_callback, PROMPT, STYLE, ASPECT_RATIO
)
from bot.handlers.admin import (
    admin_panel, block_user, unblock_user, add_credits, broadcast,
    admin_dashboard, admin_users, admin_analytics, SELECT_USER,
    ADD_CREDITS_AMOUNT, BROADCAST_MESSAGE, CONFIRM_BROADCAST
)
from bot.handlers.owner import (
    owner_panel, manage_admins, bot_config, system_settings,
    owner_bots, owner_admins, owner_finance, owner_system,
    owner_dashboard, owner_security, NEW_BOT_TOKEN, NEW_BOT_SETTINGS,
    ADMIN_USERNAME, ADMIN_PASSWORD
)
from bot.services.image_generation import ImageGenerationService, QueueManager
from bot.services.payment import PaymentService
from bot.utils.database import init_db, get_db_session, DatabaseManager
from bot.utils.decorators import rate_limit, admin_required, owner_required
from bot.utils.helpers import setup_logging
from models import BotInstance, Admin, Owner

# Configure logging
logger = setup_logging(__name__)

class AIImageBot:
    """Single bot instance handler"""
    
    def __init__(self, bot_instance: BotInstance):
        self.bot_instance = bot_instance
        self.bot_id = bot_instance.id
        self.bot_token = bot_instance.bot_token
        self.bot_username = bot_instance.bot_username
        self.config = bot_instance.config or {}
        
        # Initialize services
        self.image_service = ImageGenerationService(
            api_endpoint=bot_instance.api_endpoint or config.AI_API_ENDPOINT,
            api_key=bot_instance.api_key or config.AI_API_KEY,
            config=self.config.get('image_config', {})
        )
        
        self.payment_service = PaymentService(
            key_id=bot_instance.razorpay_key or config.RAZORPAY_KEY_ID,
            key_secret=bot_instance.razorpay_secret or config.RAZORPAY_KEY_SECRET
        )
        
        self.queue_manager = QueueManager(
            max_concurrent=self.config.get('concurrent_generations', config.CONCURRENT_GENERATIONS)
        )
        
        self.db_manager = DatabaseManager()
        
        # Initialize application
        self.application = Application.builder().token(self.bot_token).build()
        self.setup_handlers()
        
    def setup_handlers(self):
        """Setup all bot handlers with conversation states"""
        
        # User conversation handler for image generation
        gen_conv_handler = ConversationHandler(
            entry_points=[CommandHandler('generate', generate)],
            states={
                PROMPT: [MessageHandler(filters.TEXT & ~filters.COMMAND, handle_prompt)],
                STYLE: [CallbackQueryHandler(handle_callback, pattern='^style_')],
                ASPECT_RATIO: [CallbackQueryHandler(handle_callback, pattern='^ratio_')]
            },
            fallbacks=[CommandHandler('cancel', lambda u,c: ConversationHandler.END)]
        )
        
        # Admin conversation handlers
        admin_conv_handler = ConversationHandler(
            entry_points=[CallbackQueryHandler(admin_users, pattern='^admin_')],
            states={
                SELECT_USER: [MessageHandler(filters.TEXT & ~filters.COMMAND, admin_search_user)],
                ADD_CREDITS_AMOUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, admin_add_credits_amount)],
                BROADCAST_MESSAGE: [MessageHandler(filters.ALL, handle_broadcast_message)],
                CONFIRM_BROADCAST: [CallbackQueryHandler(execute_broadcast, pattern='^broadcast_')]
            },
            fallbacks=[CommandHandler('cancel', lambda u,c: ConversationHandler.END)]
        )
        
        # Owner conversation handlers
        owner_conv_handler = ConversationHandler(
            entry_points=[CallbackQueryHandler(owner_bots, pattern='^owner_')],
            states={
                NEW_BOT_TOKEN: [MessageHandler(filters.TEXT & ~filters.COMMAND, handle_new_bot_token)],
                NEW_BOT_SETTINGS: [CallbackQueryHandler(confirm_create_bot, pattern='^confirm_')],
                ADMIN_USERNAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, handle_admin_username)],
                ADMIN_PASSWORD: [CallbackQueryHandler(assign_bot_to_admin, pattern='^assign_bot_')]
            },
            fallbacks=[CommandHandler('cancel', lambda u,c: ConversationHandler.END)]
        )
        
        # Add all handlers
        self.application.add_handler(CommandHandler("start", start))
        self.application.add_handler(CommandHandler("balance", balance))
        self.application.add_handler(gen_conv_handler)
        self.application.add_handler(CommandHandler("recharge", recharge))
        self.application.add_handler(CommandHandler("history", history))
        self.application.add_handler(CommandHandler("referral", referral))
        self.application.add_handler(CommandHandler("help", help_command))
        self.application.add_handler(CommandHandler("settings", settings))
        
        # Admin handlers
        self.application.add_handler(CommandHandler("admin", admin_panel))
        self.application.add_handler(CommandHandler("block", block_user))
        self.application.add_handler(CommandHandler("unblock", unblock_user))
        self.application.add_handler(CommandHandler("addcredits", add_credits))
        self.application.add_handler(CommandHandler("broadcast", broadcast))
        self.application.add_handler(admin_conv_handler)
        
        # Owner handlers
        self.application.add_handler(CommandHandler("owner", owner_panel))
        self.application.add_handler(CommandHandler("manage_admins", manage_admins))
        self.application.add_handler(CommandHandler("botconfig", bot_config))
        self.application.add_handler(CommandHandler("system", system_settings))
        self.application.add_handler(owner_conv_handler)
        
        # Message handlers
        self.application.add_handler(MessageHandler(
            filters.TEXT & ~filters.COMMAND, 
            lambda u,c: self.handle_message(u, c)
        ))
        
        # Callback query handler
        self.application.add_handler(CallbackQueryHandler(
            self.handle_callback_wrapper
        ))
        
        # Error handler
        self.application.add_error_handler(self.error_handler)
        
        # Set bot data
        self.application.bot_data['bot_instance_id'] = self.bot_id
        self.application.bot_data['image_service'] = self.image_service
        self.application.bot_data['payment_service'] = self.payment_service
        self.application.bot_data['queue_manager'] = self.queue_manager
        self.application.bot_data['db_manager'] = self.db_manager
        
    async def handle_message(self, update: Update, context):
        """Handle regular messages"""
        # Check if user is in any conversation
        if context.user_data.get('awaiting_prompt'):
            await handle_prompt(update, context)
        else:
            await update.message.reply_text(
                "Use /generate to create images or /help for commands"
            )
    
    async def handle_callback_wrapper(self, update: Update, context):
        """Wrapper for callback handler with bot instance context"""
        await handle_callback(update, context)
    
    async def error_handler(self, update, context):
        """Handle errors"""
        logger.error(f"Update {update} caused error {context.error}")
        
        try:
            if update and update.effective_chat:
                await context.bot.send_message(
                    chat_id=update.effective_chat.id,
                    text="❌ An error occurred. Please try again later."
                )
        except:
            pass
    
    async def start_services(self):
        """Start background services"""
        await self.queue_manager.start_workers()
        logger.info(f"Started queue workers for bot {self.bot_username}")
    
    async def stop_services(self):
        """Stop background services"""
        await self.queue_manager.stop_workers()
        await self.image_service.close()
        logger.info(f"Stopped services for bot {self.bot_username}")
    
    def run(self):
        """Start the bot"""
        try:
            logger.info(f"Starting bot: {self.bot_username}")
            
            # Run startup tasks
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            loop.run_until_complete(self.start_services())
            
            # Start polling
            self.application.run_polling()
            
        except KeyboardInterrupt:
            logger.info("Bot stopped by user")
        except Exception as e:
            logger.error(f"Bot crashed: {e}")
        finally:
            loop = asyncio.get_event_loop()
            loop.run_until_complete(self.stop_services())
            loop.close()

class BotManager:
    """Manage multiple bot instances"""
    
    def __init__(self):
        self.bots: Dict[int, AIImageBot] = {}
        self.db_session = get_db_session()
        self.running = False
        
    def load_all_bots(self):
        """Load all active bot instances from database"""
        try:
            bot_instances = self.db_session.query(BotInstance).filter_by(
                status='active'
            ).all()
            
            logger.info(f"Found {len(bot_instances)} active bot instances")
            
            for instance in bot_instances:
                self.start_bot(instance)
                
        except Exception as e:
            logger.error(f"Failed to load bots: {e}")
    
    def start_bot(self, bot_instance: BotInstance):
        """Start a single bot instance"""
        try:
            bot = AIImageBot(bot_instance)
            self.bots[bot_instance.id] = bot
            
            # Start bot in a separate thread
            import threading
            thread = threading.Thread(target=bot.run, daemon=True)
            thread.start()
            
            logger.info(f"Started bot: {bot_instance.bot_username or bot_instance.id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to start bot {bot_instance.id}: {e}")
            return False
    
    def stop_bot(self, bot_id: int):
        """Stop a bot instance"""
        if bot_id in self.bots:
            # Implement graceful shutdown
            del self.bots[bot_id]
            logger.info(f"Stopped bot {bot_id}")
            return True
        return False
    
    def restart_bot(self, bot_id: int):
        """Restart a bot instance"""
        if self.stop_bot(bot_id):
            db_session = get_db_session()
            bot_instance = db_session.query(BotInstance).get(bot_id)
            db_session.close()
            
            if bot_instance:
                return self.start_bot(bot_instance)
        return False
    
    def create_new_bot(self, bot_token: str, owner_id: int, **kwargs) -> Optional[BotInstance]:
        """Create a new bot instance"""
        try:
            db_session = get_db_session()
            
            # Check if token already exists
            existing = db_session.query(BotInstance).filter_by(bot_token=bot_token).first()
            if existing:
                logger.error(f"Bot token already exists: {bot_token[:10]}...")
                db_session.close()
                return None
            
            # Create new instance
            bot_instance = BotInstance(
                bot_token=bot_token,
                owner_id=owner_id,
                status='inactive',
                config={
                    'price_plans': config.PRICE_PLANS,
                    'generation_cost': config.GENERATION_COST,
                    'welcome_bonus': config.WELCOME_BONUS,
                    'referral_bonus': config.REFERRAL_BONUS
                },
                **kwargs
            )
            
            db_session.add(bot_instance)
            db_session.commit()
            
            logger.info(f"Created new bot instance: {bot_instance.id}")
            
            # Auto-start if configured
            if kwargs.get('auto_start', True):
                self.start_bot(bot_instance)
            
            db_session.close()
            return bot_instance
            
        except Exception as e:
            logger.error(f"Failed to create bot: {e}")
            return None
    
    def get_bot_status(self, bot_id: int) -> Dict:
        """Get status of a bot instance"""
        if bot_id in self.bots:
            return {
                'id': bot_id,
                'status': 'running',
                'users': len(self.bots[bot_id].application.bot_data.get('users', {}))
            }
        return {
            'id': bot_id,
            'status': 'stopped',
            'users': 0
        }
    
    def get_all_bots_status(self) -> List[Dict]:
        """Get status of all bot instances"""
        statuses = []
        db_session = get_db_session()
        
        instances = db_session.query(BotInstance).all()
        for instance in instances:
            status = self.get_bot_status(instance.id)
            status['name'] = instance.bot_username
            status['token'] = instance.bot_token[:10] + '...'
            status['created'] = instance.created_at.isoformat()
            statuses.append(status)
        
        db_session.close()
        return statuses
    
    def shutdown(self):
        """Shutdown all bots"""
        logger.info("Shutting down all bots...")
        for bot_id in list(self.bots.keys()):
            self.stop_bot(bot_id)
        self.running = False

def main():
    """Main entry point"""
    # Initialize database
    init_db()
    
    # Create bot manager
    manager = BotManager()
    
    try:
        # Load and start all bots
        manager.load_all_bots()
        
        # Keep main thread alive
        import time
        while True:
            time.sleep(60)
            # Periodic tasks
            logger.debug("Bot manager heartbeat")
            
    except KeyboardInterrupt:
        logger.info("Shutting down...")
    finally:
        manager.shutdown()

if __name__ == "__main__":
    main()