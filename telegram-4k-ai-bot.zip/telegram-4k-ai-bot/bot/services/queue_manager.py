"""
Queue management for image generation
"""

import asyncio
import uuid
from datetime import datetime
from typing import Dict, Optional, Any, List
import logging
from bot.utils.database import get_db_session
from models import GenerationQueue

logger = logging.getLogger(__name__)

class QueueManager:
    """Manage generation queue"""
    
    def __init__(self, max_concurrent: int = 5):
        self.queue = asyncio.Queue()
        self.active = {}
        self.max_concurrent = max_concurrent
        self.workers = []
        self.running = False
        self.processing_tasks = {}
        
    async def start_workers(self):
        """Start queue workers"""
        self.running = True
        for i in range(self.max_concurrent):
            worker = asyncio.create_task(self.worker_loop(i), name=f"worker_{i}")
            self.workers.append(worker)
        logger.info(f"Started {self.max_concurrent} queue workers")
    
    async def worker_loop(self, worker_id: int):
        """Worker process for queue"""
        logger.info(f"Worker {worker_id} started")
        
        while self.running:
            try:
                # Get next job from queue with timeout
                try:
                    job = await asyncio.wait_for(self.queue.get(), timeout=1.0)
                except asyncio.TimeoutError:
                    continue
                
                if job is None:  # Shutdown signal
                    break
                
                job_id = job['id']
                self.active[job_id] = job
                self.processing_tasks[job_id] = asyncio.current_task()
                
                logger.info(f"Worker {worker_id} processing job {job_id}")
                
                # Update status
                await self.update_job_status(job_id, 'processing')
                
                # Process job
                try:
                    result = await self.process_job(job)
                    
                    if result['success']:
                        await self.update_job_status(job_id, 'completed', result=result)
                        logger.info(f"Job {job_id} completed successfully")
                    else:
                        await self.update_job_status(job_id, 'failed', error=result.get('error'))
                        logger.error(f"Job {job_id} failed: {result.get('error')}")
                        
                except Exception as e:
                    logger.error(f"Job {job_id} processing error: {e}")
                    await self.update_job_status(job_id, 'failed', error=str(e))
                
                # Remove from active
                del self.active[job_id]
                if job_id in self.processing_tasks:
                    del self.processing_tasks[job_id]
                
                self.queue.task_done()
                
            except Exception as e:
                logger.error(f"Worker {worker_id} error: {e}")
                await asyncio.sleep(1)
        
        logger.info(f"Worker {worker_id} stopped")
    
    async def add_to_queue(self, user_id: int, prompt: str, 
                          parameters: Dict) -> str:
        """Add job to queue"""
        job_id = str(uuid.uuid4())
        
        job = {
            'id': job_id,
            'user_id': user_id,
            'prompt': prompt,
            'parameters': parameters,
            'status': 'queued',
            'created_at': datetime.utcnow()
        }
        
        # Store in database
        db_session = get_db_session()
        try:
            queue_entry = GenerationQueue(
                queue_id=job_id,
                user_id=user_id,
                prompt=prompt,
                parameters=parameters,
                status='queued',
                created_at=job['created_at']
            )
            db_session.add(queue_entry)
            db_session.commit()
            
            # Add to queue
            await self.queue.put(job)
            
            logger.info(f"Added job {job_id} to queue for user {user_id}")
            
        except Exception as e:
            logger.error(f"Error adding job to queue: {e}")
            db_session.rollback()
            raise
        finally:
            db_session.close()
        
        return job_id
    
    async def process_job(self, job: Dict) -> Dict:
        """
        Process a queue job - this should be overridden or connected to actual generation
        """
        # This is a placeholder - actual implementation would call image generation service
        # For now, simulate processing
        await asyncio.sleep(10)  # Simulate generation time
        
        return {
            'success': True,
            'image_url': f"https://example.com/images/{job['id']}.png",
            'thumbnail_url': f"https://example.com/thumbnails/{job['id']}.png"
        }
    
    async def update_job_status(self, job_id: str, status: str, 
                               result: Dict = None, error: str = None):
        """Update job status in database"""
        db_session = get_db_session()
        try:
            queue_entry = db_session.query(GenerationQueue).filter_by(
                queue_id=job_id
            ).first()
            
            if queue_entry:
                queue_entry.status = status
                
                if status == 'processing':
                    queue_entry.started_at = datetime.utcnow()
                elif status == 'completed':
                    queue_entry.completed_at = datetime.utcnow()
                    if result:
                        queue_entry.result_url = result.get('image_url')
                        queue_entry.thumbnail_url = result.get('thumbnail_url')
                elif status == 'failed':
                    queue_entry.completed_at = datetime.utcnow()
                    queue_entry.error = error
                
                db_session.commit()
                
        except Exception as e:
            logger.error(f"Error updating job status: {e}")
            db_session.rollback()
        finally:
            db_session.close()
    
    async def get_queue_status(self, queue_id: str) -> Optional[Dict]:
        """Get status of a queue item"""
        db_session = get_db_session()
        try:
            queue_entry = db_session.query(GenerationQueue).filter_by(
                queue_id=queue_id
            ).first()
            
            if queue_entry:
                status = {
                    'id': queue_entry.queue_id,
                    'status': queue_entry.status,
                    'created_at': queue_entry.created_at,
                    'started_at': queue_entry.started_at,
                    'completed_at': queue_entry.completed_at,
                    'result_url': queue_entry.result_url,
                    'thumbnail_url': queue_entry.thumbnail_url,
                    'error': queue_entry.error,
                    'position': await self.get_queue_position(queue_id)
                }
                return status
            return None
            
        except Exception as e:
            logger.error(f"Error getting queue status: {e}")
            return None
        finally:
            db_session.close()
    
    async def get_queue_position(self, queue_id: str) -> int:
        """Get position in queue"""
        # Count queued items before this one
        db_session = get_db_session()
        try:
            # Find the job
            job = db_session.query(GenerationQueue).filter_by(
                queue_id=queue_id
            ).first()
            
            if not job or job.status != 'queued':
                return 0
            
            # Count queued jobs created before this one
            position = db_session.query(GenerationQueue).filter(
                GenerationQueue.status == 'queued',
                GenerationQueue.created_at < job.created_at
            ).count()
            
            return position + 1  # 1-based position
            
        except Exception as e:
            logger.error(f"Error getting queue position: {e}")
            return 0
        finally:
            db_session.close()
    
    async def get_queue_stats(self) -> Dict:
        """Get queue statistics"""
        db_session = get_db_session()
        try:
            queued = db_session.query(GenerationQueue).filter_by(
                status='queued'
            ).count()
            
            processing = db_session.query(GenerationQueue).filter_by(
                status='processing'
            ).count()
            
            completed_today = db_session.query(GenerationQueue).filter(
                GenerationQueue.status == 'completed',
                GenerationQueue.completed_at >= datetime.utcnow().replace(
                    hour=0, minute=0, second=0, microsecond=0
                )
            ).count()
            
            failed_today = db_session.query(GenerationQueue).filter(
                GenerationQueue.status == 'failed',
                GenerationQueue.completed_at >= datetime.utcnow().replace(
                    hour=0, minute=0, second=0, microsecond=0
                )
            ).count()
            
            return {
                'queued': queued,
                'processing': processing,
                'completed_today': completed_today,
                'failed_today': failed_today,
                'total_active': queued + processing,
                'max_concurrent': self.max_concurrent
            }
            
        except Exception as e:
            logger.error(f"Error getting queue stats: {e}")
            return {}
        finally:
            db_session.close()
    
    async def cancel_job(self, job_id: str) -> bool:
        """Cancel a queued job"""
        db_session = get_db_session()
        try:
            job = db_session.query(GenerationQueue).filter_by(
                queue_id=job_id
            ).first()
            
            if job and job.status == 'queued':
                job.status = 'cancelled'
                db_session.commit()
                
                # Remove from queue (if possible)
                # Note: asyncio.Queue doesn't support removal, so job will be skipped when processed
                
                logger.info(f"Cancelled job {job_id}")
                return True
                
            return False
            
        except Exception as e:
            logger.error(f"Error cancelling job: {e}")
            db_session.rollback()
            return False
        finally:
            db_session.close()
    
    async def stop_workers(self):
        """Stop all workers"""
        logger.info("Stopping queue workers...")
        self.running = False
        
        # Send stop signal to all workers
        for _ in self.workers:
            await self.queue.put(None)
        
        # Wait for workers to finish
        if self.workers:
            await asyncio.gather(*self.workers, return_exceptions=True)
            self.workers.clear()
        
        # Cancel any processing jobs
        for job_id, task in self.processing_tasks.items():
            if not task.done():
                task.cancel()
        
        logger.info("All queue workers stopped")
    
    async def clear_queue(self):
        """Clear all queued jobs"""
        # Clear asyncio queue
        while not self.queue.empty():
            try:
                self.queue.get_nowait()
                self.queue.task_done()
            except asyncio.QueueEmpty:
                break
        
        # Update database
        db_session = get_db_session()
        try:
            db_session.query(GenerationQueue).filter_by(
                status='queued'
            ).update({'status': 'cancelled'})
            db_session.commit()
            
            logger.info("Cleared all queued jobs")
            
        except Exception as e:
            logger.error(f"Error clearing queue: {e}")
            db_session.rollback()
        finally:
            db_session.close()