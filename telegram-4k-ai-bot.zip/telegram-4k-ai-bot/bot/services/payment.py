"""
Payment Integration Service (Razorpay)
"""

import razorpay
import hmac
import hashlib
import json
from typing import Optional, Dict, Any
from datetime import datetime
import logging
from bot.utils.database import get_db_session
from models import Transaction, User

logger = logging.getLogger(__name__)

class PaymentService:
    """Handle payment processing with Razorpay"""
    
    def __init__(self, key_id: str, key_secret: str):
        self.key_id = key_id
        self.key_secret = key_secret
        self.client = razorpay.Client(auth=(key_id, key_secret))
        
    async def create_order(self, amount: int, currency: str = "INR",
                          receipt: str = None, notes: Dict = None) -> Optional[Dict]:
        """
        Create a Razorpay order
        """
        try:
            # Amount in paise (multiply by 100)
            amount_paise = amount * 100
            
            order_data = {
                "amount": amount_paise,
                "currency": currency,
                "receipt": receipt,
                "notes": notes or {}
            }
            
            # Create order synchronously (razorpay client is synchronous)
            order = self.client.order.create(data=order_data)
            
            return {
                'id': order['id'],
                'amount': order['amount'] / 100,  # Convert back to rupees
                'amount_paise': order['amount'],
                'currency': order['currency'],
                'receipt': order['receipt'],
                'status': order['status'],
                'short_url': f"https://rzp.io/l/{order['id']}"  # Generate short URL
            }
            
        except Exception as e:
            logger.error(f"Order creation failed: {e}")
            return None
    
    async def verify_payment(self, order_id: str, payment_id: str,
                            signature: str) -> bool:
        """
        Verify payment signature
        """
        try:
            # Generate signature for verification
            generated_signature = hmac.new(
                key=self.key_secret.encode(),
                msg=f"{order_id}|{payment_id}".encode(),
                digestmod=hashlib.sha256
            ).hexdigest()
            
            return hmac.compare_digest(generated_signature, signature)
            
        except Exception as e:
            logger.error(f"Payment verification failed: {e}")
            return False
    
    async def fetch_payment(self, payment_id: str) -> Optional[Dict]:
        """
        Fetch payment details from Razorpay
        """
        try:
            payment = self.client.payment.fetch(payment_id)
            return {
                'id': payment['id'],
                'order_id': payment['order_id'],
                'amount': payment['amount'] / 100,
                'currency': payment['currency'],
                'status': payment['status'],
                'method': payment['method'],
                'description': payment.get('description', ''),
                'email': payment.get('email', ''),
                'contact': payment.get('contact', ''),
                'fee': payment.get('fee', 0) / 100 if payment.get('fee') else 0,
                'tax': payment.get('tax', 0) / 100 if payment.get('tax') else 0,
                'created_at': datetime.fromtimestamp(payment.get('created_at', 0))
            }
        except Exception as e:
            logger.error(f"Fetch payment failed: {e}")
            return None
    
    async def capture_payment(self, payment_id: str, amount: int = None) -> bool:
        """
        Capture a payment (if not auto-captured)
        """
        try:
            if amount:
                payment = self.client.payment.capture(payment_id, amount * 100)
            else:
                payment = self.client.payment.fetch(payment_id)
                payment = self.client.payment.capture(payment_id, payment['amount'])
            
            return payment['status'] == 'captured'
        except Exception as e:
            logger.error(f"Payment capture failed: {e}")
            return False
    
    async def process_refund(self, payment_id: str, amount: int = None) -> bool:
        """
        Process refund for a payment
        """
        try:
            if amount:
                # Partial refund
                refund = self.client.payment.refund(payment_id, {
                    "amount": amount * 100  # Convert to paise
                })
            else:
                # Full refund
                refund = self.client.payment.refund(payment_id)
            
            return refund['status'] == 'processed'
            
        except Exception as e:
            logger.error(f"Refund failed: {e}")
            return False
    
    async def get_transaction_status(self, transaction_id: str) -> Optional[Dict]:
        """
        Get transaction status from Razorpay
        """
        try:
            # First try as order ID
            orders = self.client.order.all({'receipt': transaction_id})
            if orders and orders['items']:
                order = orders['items'][0]
                payments = self.client.order.payments(order['id'])
                if payments and payments['items']:
                    payment = payments['items'][0]
                    return {
                        'order_id': order['id'],
                        'payment_id': payment['id'],
                        'amount': order['amount'] / 100,
                        'status': payment['status'],
                        'method': payment['method'],
                        'created_at': datetime.fromtimestamp(order['created_at'])
                    }
            
            # Try as payment ID
            payment = self.client.payment.fetch(transaction_id)
            return {
                'order_id': payment['order_id'],
                'payment_id': payment['id'],
                'amount': payment['amount'] / 100,
                'status': payment['status'],
                'method': payment['method'],
                'created_at': datetime.fromtimestamp(payment['created_at'])
            }
            
        except Exception as e:
            logger.error(f"Transaction status check failed: {e}")
            return None

class WebhookHandler:
    """Handle Razorpay webhooks"""
    
    def __init__(self, key_secret: str):
        self.key_secret = key_secret
        
    async def verify_webhook_signature(self, payload: bytes,
                                      signature: str, webhook_secret: str) -> bool:
        """
        Verify webhook signature
        """
        try:
            generated_signature = hmac.new(
                key=webhook_secret.encode(),
                msg=payload,
                digestmod=hashlib.sha256
            ).hexdigest()
            
            return hmac.compare_digest(generated_signature, signature)
            
        except Exception as e:
            logger.error(f"Webhook verification failed: {e}")
            return False
    
    async def handle_webhook(self, payload: Dict, event_type: str):
        """
        Handle different webhook events
        """
        if event_type == "payment.captured":
            await self.handle_payment_captured(payload)
        elif event_type == "payment.failed":
            await self.handle_payment_failed(payload)
        elif event_type == "refund.created":
            await self.handle_refund_created(payload)
        elif event_type == "refund.processed":
            await self.handle_refund_processed(payload)
    
    async def handle_payment_captured(self, payload: Dict):
        """Handle successful payment"""
        payment = payload['payload']['payment']['entity']
        payment_id = payment['id']
        order_id = payment['order_id']
        
        db_session = get_db_session()
        
        try:
            # Find transaction
            transaction = db_session.query(Transaction).filter_by(
                razorpay_order_id=order_id
            ).first()
            
            if transaction and transaction.status == 'pending':
                # Update transaction
                transaction.status = 'completed'
                transaction.razorpay_payment_id = payment_id
                transaction.metadata = {
                    'method': payment.get('method'),
                    'bank': payment.get('bank'),
                    'wallet': payment.get('wallet'),
                    'vpa': payment.get('vpa'),
                    'fee': payment.get('fee', 0) / 100,
                    'tax': payment.get('tax', 0) / 100
                }
                
                # Add credits to user
                user = db_session.query(User).get(transaction.user_id)
                if user:
                    old_balance = user.credits_balance
                    user.credits_balance += transaction.credits
                    
                    logger.info(f"Payment successful: {payment_id} for user {user.telegram_id}")
                    logger.info(f"Credits added: {transaction.credits} (was {old_balance}, now {user.credits_balance})")
                    
                    db_session.commit()
                    
                    # Return user data for notification
                    return {
                        'user_id': user.telegram_id,
                        'credits': transaction.credits,
                        'new_balance': user.credits_balance,
                        'amount': transaction.amount
                    }
            
        except Exception as e:
            logger.error(f"Error handling payment captured: {e}")
            db_session.rollback()
        finally:
            db_session.close()
        
        return None
    
    async def handle_payment_failed(self, payload: Dict):
        """Handle failed payment"""
        payment = payload['payload']['payment']['entity']
        payment_id = payment['id']
        order_id = payment['order_id']
        
        db_session = get_db_session()
        
        try:
            transaction = db_session.query(Transaction).filter_by(
                razorpay_order_id=order_id
            ).first()
            
            if transaction:
                transaction.status = 'failed'
                transaction.metadata = {
                    'error_code': payment.get('error_code'),
                    'error_description': payment.get('error_description'),
                    'error_source': payment.get('error_source'),
                    'error_step': payment.get('error_step'),
                    'error_reason': payment.get('error_reason')
                }
                db_session.commit()
                
                logger.info(f"Payment failed: {payment_id} - {payment.get('error_description')}")
                
                return {
                    'user_id': transaction.user_id,
                    'error': payment.get('error_description')
                }
                
        except Exception as e:
            logger.error(f"Error handling payment failed: {e}")
            db_session.rollback()
        finally:
            db_session.close()
        
        return None
    
    async def handle_refund_created(self, payload: Dict):
        """Handle refund created"""
        refund = payload['payload']['refund']['entity']
        payment_id = refund['payment_id']
        refund_id = refund['id']
        
        db_session = get_db_session()
        
        try:
            transaction = db_session.query(Transaction).filter_by(
                razorpay_payment_id=payment_id
            ).first()
            
            if transaction:
                transaction.status = 'refunded'
                transaction.metadata = {
                    **transaction.metadata,
                    'refund_id': refund_id,
                    'refund_amount': refund['amount'] / 100,
                    'refund_status': refund['status']
                }
                db_session.commit()
                
                # Remove credits if already added
                if transaction.status == 'completed':
                    user = db_session.query(User).get(transaction.user_id)
                    if user:
                        user.credits_balance -= transaction.credits
                        db_session.commit()
                
        except Exception as e:
            logger.error(f"Error handling refund created: {e}")
        finally:
            db_session.close()
    
    async def handle_refund_processed(self, payload: Dict):
        """Handle refund processed"""
        refund = payload['payload']['refund']['entity']
        # Update refund status
        logger.info(f"Refund processed: {refund['id']}")

# Helper functions for bot integration
async def create_razorpay_order(amount: int, currency: str = "INR",
                               receipt: str = None, notes: Dict = None) -> Optional[Dict]:
    """
    Create Razorpay order (wrapper for bot)
    """
    from config.settings import config
    
    payment_service = PaymentService(
        key_id=config.RAZORPAY_KEY_ID,
        key_secret=config.RAZORPAY_KEY_SECRET
    )
    
    return await payment_service.create_order(amount, currency, receipt, notes)

async def verify_payment(order_id: str, payment_id: str,
                        signature: str) -> bool:
    """
    Verify payment (wrapper for bot)
    """
    from config.settings import config
    
    payment_service = PaymentService(
        key_id=config.RAZORPAY_KEY_ID,
        key_secret=config.RAZORPAY_KEY_SECRET
    )
    
    return await payment_service.verify_payment(order_id, payment_id, signature)