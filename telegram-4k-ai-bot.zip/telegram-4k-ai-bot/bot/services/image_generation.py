"""
AI Image Generation Service
"""

import aiohttp
import asyncio
import base64
import uuid
from typing import Optional, Dict, Any, List
from datetime import datetime
import logging
from io import BytesIO
from bot.utils.database import get_db_session
from models import GenerationQueue, GeneratedImage, User

logger = logging.getLogger(__name__)

class ImageGenerationService:
    """Service for AI image generation"""
    
    def __init__(self, api_endpoint: str, api_key: str, config: Dict = None):
        self.api_endpoint = api_endpoint
        self.api_key = api_key
        self.config = config or {}
        self.session = None
        self.timeout = aiohttp.ClientTimeout(total=60)
        
    async def get_session(self):
        """Get or create aiohttp session"""
        if not self.session or self.session.closed:
            self.session = aiohttp.ClientSession(timeout=self.timeout)
        return self.session
    
    async def generate_image(self, prompt: str, style: str = "realistic", 
                            aspect_ratio: str = "16:9", 
                            resolution: str = "3840x2160",
                            negative_prompt: Optional[str] = None,
                            num_images: int = 1) -> Dict[str, Any]:
        """
        Generate image using AI API
        """
        try:
            session = await self.get_session()
            
            # Prepare request payload based on API type
            # This is a generic implementation - adjust based on your API
            if 'stability.ai' in self.api_endpoint:
                payload = self._prepare_stability_payload(
                    prompt, negative_prompt, aspect_ratio, num_images
                )
            elif 'openai' in self.api_endpoint:
                payload = self._prepare_openai_payload(
                    prompt, style, resolution, num_images
                )
            else:
                # Generic API
                payload = {
                    "prompt": prompt,
                    "negative_prompt": negative_prompt or "",
                    "style": style,
                    "aspect_ratio": aspect_ratio,
                    "resolution": resolution,
                    "num_images": num_images,
                    "quality": "4k"
                }
            
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            
            logger.info(f"Sending generation request: {prompt[:50]}...")
            
            async with session.post(
                f"{self.api_endpoint}/generate",
                json=payload,
                headers=headers
            ) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    # Process and store image
                    results = await self.process_generated_images(data)
                    return {
                        'success': True,
                        'images': results,
                        'metadata': data.get('metadata', {})
                    }
                else:
                    error_text = await response.text()
                    logger.error(f"API error: {response.status} - {error_text}")
                    return {
                        'success': False,
                        'error': f"API error: {response.status}",
                        'details': error_text
                    }
                    
        except asyncio.TimeoutError:
            logger.error("Generation timeout")
            return {'success': False, 'error': 'Generation timeout'}
        except Exception as e:
            logger.error(f"Generation error: {e}")
            return {'success': False, 'error': str(e)}
    
    def _prepare_stability_payload(self, prompt: str, negative_prompt: str,
                                  aspect_ratio: str, num_images: int) -> Dict:
        """Prepare payload for Stability AI API"""
        # Map aspect ratio to dimensions
        dimensions = {
            '16:9': (1344, 768),
            '9:16': (768, 1344),
            '1:1': (1024, 1024),
            '21:9': (1536, 640),
            '4:3': (1152, 896),
            '3:2': (1216, 832)
        }
        
        width, height = dimensions.get(aspect_ratio, (1024, 1024))
        
        return {
            "text_prompts": [
                {
                    "text": prompt,
                    "weight": 1.0
                }
            ],
            "cfg_scale": 7,
            "height": height,
            "width": width,
            "samples": num_images,
            "steps": 30,
            "style_preset": "photographic"
        }
    
    def _prepare_openai_payload(self, prompt: str, style: str,
                               resolution: str, num_images: int) -> Dict:
        """Prepare payload for OpenAI DALL-E API"""
        # Map resolution to OpenAI size
        size_map = {
            '3840x2160': '1024x1024',  # DALL-E doesn't support 4K
            '1920x1080': '1024x1024',
            '1024x1024': '1024x1024'
        }
        
        return {
            "model": "dall-e-3",
            "prompt": prompt,
            "n": num_images,
            "size": size_map.get(resolution, "1024x1024"),
            "quality": "hd" if resolution == "3840x2160" else "standard",
            "style": "vivid" if style == "realistic" else "natural"
        }
    
    async def process_generated_images(self, data: Dict) -> List[Dict]:
        """
        Process and store generated images
        """
        results = []
        
        # Handle different API response formats
        if 'artifacts' in data:  # Stability AI
            for i, artifact in enumerate(data['artifacts']):
                if artifact['finishReason'] == 'SUCCESS':
                    image_data = base64.b64decode(artifact['base64'])
                    result = await self.save_image(image_data, f"image_{i}.png")
                    results.append(result)
                    
        elif 'data' in data:  # OpenAI
            for i, item in enumerate(data['data']):
                if 'url' in item:
                    # Download from URL
                    result = await self.download_and_save(item['url'], f"image_{i}.png")
                    results.append(result)
                elif 'b64_json' in item:
                    image_data = base64.b64decode(item['b64_json'])
                    result = await self.save_image(image_data, f"image_{i}.png")
                    results.append(result)
        
        return results
    
    async def save_image(self, image_bytes: bytes, filename: str) -> Dict:
        """
        Save image to storage
        """
        # Generate unique filename
        unique_id = str(uuid.uuid4())
        ext = filename.split('.')[-1]
        storage_filename = f"{unique_id}.{ext}"
        thumb_filename = f"thumb_{unique_id}.{ext}"
        
        # In production, upload to cloud storage (S3/Cloudinary)
        # This is a placeholder - implement your storage logic
        image_url = await self.upload_to_storage(image_bytes, storage_filename)
        thumbnail_url = await self.create_thumbnail(image_bytes, thumb_filename)
        
        return {
            'image_url': image_url,
            'thumbnail_url': thumbnail_url,
            'filename': storage_filename
        }
    
    async def download_and_save(self, url: str, filename: str) -> Dict:
        """Download image from URL and save"""
        session = await self.get_session()
        async with session.get(url) as response:
            if response.status == 200:
                image_bytes = await response.read()
                return await self.save_image(image_bytes, filename)
        return {
            'image_url': url,
            'thumbnail_url': url,
            'filename': filename
        }
    
    async def upload_to_storage(self, image_bytes: bytes, filename: str) -> str:
        """
        Upload image to cloud storage
        """
        # Implement your cloud storage logic here
        # Example with AWS S3:
        """
        import boto3
        s3 = boto3.client('s3')
        s3.upload_fileobj(
            BytesIO(image_bytes),
            'your-bucket',
            f'images/{filename}',
            ExtraArgs={'ACL': 'public-read', 'ContentType': 'image/png'}
        )
        return f"https://your-bucket.s3.amazonaws.com/images/{filename}"
        """
        
        # Example with Cloudinary:
        """
        import cloudinary
        import cloudinary.uploader
        result = cloudinary.uploader.upload(
            image_bytes,
            public_id=filename.split('.')[0],
            resource_type="image"
        )
        return result['secure_url']
        """
        
        # Placeholder - return local URL (for development)
        return f"https://storage.example.com/images/{filename}"
    
    async def create_thumbnail(self, image_bytes: bytes, filename: str) -> str:
        """
        Create thumbnail from image
        """
        try:
            from PIL import Image
            
            # Open image with PIL
            img = Image.open(BytesIO(image_bytes))
            
            # Create thumbnail (max 512x512)
            img.thumbnail((512, 512), Image.Resampling.LANCZOS)
            
            # Save to bytes
            thumb_bytes = BytesIO()
            img.save(thumb_bytes, format='PNG', optimize=True)
            thumb_bytes = thumb_bytes.getvalue()
            
            # Upload thumbnail
            return await self.upload_to_storage(thumb_bytes, filename)
            
        except Exception as e:
            logger.error(f"Thumbnail creation failed: {e}")
            # Return original image URL as fallback
            return f"https://storage.example.com/images/{filename.replace('thumb_', '')}"
    
    async def close(self):
        """Close session"""
        if self.session and not self.session.closed:
            await self.session.close()