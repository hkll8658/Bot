"""
Flask web application for admin panel
"""

import os
import logging
from datetime import datetime, timedelta
from flask import Flask, render_template, request, jsonify, session, redirect, url_for, flash
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from werkzeug.security import check_password_hash, generate_password_hash
from sqlalchemy import func, desc
from web.models import db, Admin, Owner, User, BotInstance, Transaction, GeneratedImage
from web.forms import LoginForm, AdminForm, BotConfigForm
from config.settings import config

# Configure logging
logger = logging.getLogger(__name__)

def create_app():
    """Create and configure Flask app"""
    app = Flask(__name__)
    
    # Configuration
    app.config['SECRET_KEY'] = os.getenv('FLASK_SECRET_KEY', 'dev-secret-key-change-in-production')
    app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL', 'sqlite:///bot.db')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['SESSION_TYPE'] = 'filesystem'
    app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(hours=24)
    
    # Initialize extensions
    db.init_app(app)
    
    login_manager = LoginManager()
    login_manager.init_app(app)
    login_manager.login_view = 'login'
    login_manager.login_message = 'Please log in to access this page.'
    
    @login_manager.user_loader
    def load_user(user_id):
        """Load user from session"""
        # Check if admin
        admin = Admin.query.get(int(user_id))
        if admin:
            return admin
        # Check if owner
        return Owner.query.get(int(user_id))
    
    # Register routes
    register_routes(app)
    
    return app

def register_routes(app):
    """Register all routes"""
    
    @app.route('/')
    def index():
        """Home page redirect"""
        if current_user.is_authenticated:
            return redirect(url_for('dashboard'))
        return redirect(url_for('login'))
    
    @app.route('/login', methods=['GET', 'POST'])
    def login():
        """Login page"""
        if current_user.is_authenticated:
            return redirect(url_for('dashboard'))
        
        form = LoginForm()
        if form.validate_on_submit():
            username = form.username.data
            password = form.password.data
            
            # Check owner first
            owner = Owner.query.filter_by(username=username).first()
            if owner and check_password_hash(owner.password_hash, password):
                login_user(owner, remember=form.remember.data)
                owner.last_login = datetime.utcnow()
                db.session.commit()
                logger.info(f"Owner logged in: {username}")
                return redirect(url_for('dashboard'))
            
            # Check admin
            admin = Admin.query.filter_by(username=username, status='active').first()
            if admin and check_password_hash(admin.password_hash, password):
                login_user(admin, remember=form.remember.data)
                admin.last_login = datetime.utcnow()
                db.session.commit()
                logger.info(f"Admin logged in: {username}")
                return redirect(url_for('dashboard'))
            
            flash('Invalid username or password', 'danger')
        
        return render_template('login.html', form=form)
    
    @app.route('/logout')
    @login_required
    def logout():
        """Logout user"""
        username = current_user.username
        logout_user()
        logger.info(f"User logged out: {username}")
        flash('You have been logged out.', 'success')
        return redirect(url_for('login'))
    
    @app.route('/dashboard')
    @login_required
    def dashboard():
        """Main dashboard"""
        # Get statistics
        total_users = User.query.count()
        active_today = User.query.filter(
            User.last_active >= datetime.utcnow() - timedelta(days=1)
        ).count()
        
        total_images = GeneratedImage.query.count()
        images_today = GeneratedImage.query.filter(
            GeneratedImage.generation_date >= datetime.utcnow() - timedelta(days=1)
        ).count()
        
        total_revenue = db.session.query(func.sum(Transaction.amount)).filter_by(
            status='completed'
        ).scalar() or 0
        
        revenue_today = db.session.query(func.sum(Transaction.amount)).filter(
            Transaction.status == 'completed',
            Transaction.date >= datetime.utcnow() - timedelta(days=1)
        ).scalar() or 0
        
        # Get recent users
        recent_users = User.query.order_by(User.joined_date.desc()).limit(5).all()
        
        # Get popular prompts
        popular_prompts = db.session.query(
            GeneratedImage.prompt, func.count().label('count')
        ).group_by(GeneratedImage.prompt).order_by(desc('count')).limit(5).all()
        
        return render_template(
            'dashboard.html',
            total_users=total_users,
            active_today=active_today,
            total_images=total_images,
            images_today=images_today,
            total_revenue=total_revenue,
            revenue_today=revenue_today,
            recent_users=recent_users,
            popular_prompts=popular_prompts
        )
    
    @app.route('/users')
    @login_required
    def users():
        """User management page"""
        page = request.args.get('page', 1, type=int)
        per_page = 20
        
        users = User.query.order_by(User.joined_date.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        return render_template('users.html', users=users)
    
    @app.route('/user/<int:user_id>')
    @login_required
    def user_detail(user_id):
        """User detail page"""
        user = User.query.get_or_404(user_id)
        
        # Get user's images
        images = GeneratedImage.query.filter_by(user_id=user.id).order_by(
            GeneratedImage.generation_date.desc()
        ).limit(10).all()
        
        # Get user's transactions
        transactions = Transaction.query.filter_by(user_id=user.id).order_by(
            Transaction.date.desc()
        ).all()
        
        return render_template(
            'user_detail.html',
            user=user,
            images=images,
            transactions=transactions
        )
    
    @app.route('/user/<int:user_id>/block', methods=['POST'])
    @login_required
    def block_user(user_id):
        """Block a user"""
        user = User.query.get_or_404(user_id)
        user.status = 'blocked'
        db.session.commit()
        flash(f'User {user.username or user.first_name} has been blocked.', 'success')
        return redirect(url_for('user_detail', user_id=user_id))
    
    @app.route('/user/<int:user_id>/unblock', methods=['POST'])
    @login_required
    def unblock_user(user_id):
        """Unblock a user"""
        user = User.query.get_or_404(user_id)
        user.status = 'active'
        db.session.commit()
        flash(f'User {user.username or user.first_name} has been unblocked.', 'success')
        return redirect(url_for('user_detail', user_id=user_id))
    
    @app.route('/user/<int:user_id>/add_credits', methods=['POST'])
    @login_required
    def add_credits(user_id):
        """Add credits to user"""
        user = User.query.get_or_404(user_id)
        credits = request.form.get('credits', type=int)
        
        if credits and credits > 0:
            user.credits_balance += credits
            db.session.commit()
            flash(f'Added {credits} credits to user.', 'success')
        else:
            flash('Invalid credit amount.', 'danger')
        
        return redirect(url_for('user_detail', user_id=user_id))
    
    @app.route('/analytics')
    @login_required
    def analytics():
        """Analytics page"""
        # Time periods
        today = datetime.utcnow().date()
        week_ago = today - timedelta(days=7)
        month_ago = today - timedelta(days=30)
        
        # Daily user growth for chart
        daily_users = db.session.query(
            func.date(User.joined_date).label('date'),
            func.count().label('count')
        ).group_by(func.date(User.joined_date)).order_by('date').limit(30).all()
        
        # Daily revenue for chart
        daily_revenue = db.session.query(
            func.date(Transaction.date).label('date'),
            func.sum(Transaction.amount).label('total')
        ).filter(Transaction.status == 'completed').group_by(
            func.date(Transaction.date)
        ).order_by('date').limit(30).all()
        
        # Top users by spending
        top_users = db.session.query(
            User, func.sum(Transaction.amount).label('total_spent')
        ).join(Transaction).filter(
            Transaction.status == 'completed'
        ).group_by(User).order_by(desc('total_spent')).limit(10).all()
        
        return render_template(
            'analytics.html',
            daily_users=daily_users,
            daily_revenue=daily_revenue,
            top_users=top_users
        )
    
    @app.route('/bots')
    @login_required
    def bots():
        """Bot management page (owner only)"""
        if not current_user.is_owner:
            flash('Access denied.', 'danger')
            return redirect(url_for('dashboard'))
        
        bots = BotInstance.query.all()
        return render_template('bots.html', bots=bots)
    
    @app.route('/bot/create', methods=['GET', 'POST'])
    @login_required
    def create_bot():
        """Create new bot (owner only)"""
        if not current_user.is_owner:
            flash('Access denied.', 'danger')
            return redirect(url_for('dashboard'))
        
        form = BotConfigForm()
        if form.validate_on_submit():
            bot = BotInstance(
                bot_token=form.bot_token.data,
                bot_username=form.bot_username.data,
                owner_id=current_user.id,
                razorpay_key=form.razorpay_key.data,
                razorpay_secret=form.razorpay_secret.data,
                api_endpoint=form.api_endpoint.data,
                api_key=form.api_key.data,
                status='inactive',
                config={
                    'price_plans': {
                        100: 50,
                        500: 200,
                        1000: 400
                    },
                    'generation_cost': 10,
                    'welcome_bonus': 5,
                    'referral_bonus': 10
                }
            )
            db.session.add(bot)
            db.session.commit()
            flash('Bot created successfully!', 'success')
            return redirect(url_for('bots'))
        
        return render_template('bot_form.html', form=form, title='Create Bot')
    
    @app.route('/bot/<int:bot_id>/edit', methods=['GET', 'POST'])
    @login_required
    def edit_bot(bot_id):
        """Edit bot configuration (owner only)"""
        if not current_user.is_owner:
            flash('Access denied.', 'danger')
            return redirect(url_for('dashboard'))
        
        bot = BotInstance.query.get_or_404(bot_id)
        form = BotConfigForm(obj=bot)
        
        if form.validate_on_submit():
            bot.bot_token = form.bot_token.data
            bot.bot_username = form.bot_username.data
            bot.razorpay_key = form.razorpay_key.data
            bot.razorpay_secret = form.razorpay_secret.data
            bot.api_endpoint = form.api_endpoint.data
            bot.api_key = form.api_key.data
            db.session.commit()
            flash('Bot updated successfully!', 'success')
            return redirect(url_for('bots'))
        
        return render_template('bot_form.html', form=form, title='Edit Bot')
    
    @app.route('/api/stats')
    @login_required
    def api_stats():
        """API endpoint for real-time stats"""
        stats = {
            'users': User.query.count(),
            'active_today': User.query.filter(
                User.last_active >= datetime.utcnow() - timedelta(days=1)
            ).count(),
            'images_today': GeneratedImage.query.filter(
                GeneratedImage.generation_date >= datetime.utcnow() - timedelta(days=1)
            ).count(),
            'revenue_today': db.session.query(func.sum(Transaction.amount)).filter(
                Transaction.status == 'completed',
                Transaction.date >= datetime.utcnow() - timedelta(days=1)
            ).scalar() or 0
        }
        return jsonify(stats)
    
    @app.errorhandler(404)
    def not_found_error(error):
        return render_template('404.html'), 404
    
    @app.errorhandler(500)
    def internal_error(error):
        db.session.rollback()
        return render_template('500.html'), 500