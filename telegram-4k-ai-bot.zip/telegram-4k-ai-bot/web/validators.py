"""
Web form validators for admin panel
"""

import re
from datetime import datetime
from typing import Tuple, Optional
from wtforms.validators import ValidationError

def validate_bot_token(form, field):
    """Validate bot token format"""
    token = field.data
    if not token:
        return
    
    # Bot token format: 1234567890:ABCdefGHIjklMNOpqrsTUVwxyz
    pattern = r'^\d+:[\w-]+$'
    if not re.match(pattern, token):
        raise ValidationError('Invalid bot token format')

def validate_razorpay_key(form, field):
    """Validate Razorpay key format"""
    key = field.data
    if not key:
        return
    
    # Razorpay key format: rzp_test_xxxxxxxxxx or rzp_live_xxxxxxxxxx
    pattern = r'^rzp_(test|live)_[\w]+$'
    if not re.match(pattern, key):
        raise ValidationError('Invalid Razorpay key format')

def validate_upi_id(form, field):
    """Validate UPI ID format"""
    upi = field.data
    if not upi:
        return
    
    # UPI format: username@bank
    pattern = r'^[\w\.\-]+@[\w]+$'
    if not re.match(pattern, upi):
        raise ValidationError('Invalid UPI ID format')

def validate_phone_number(form, field):
    """Validate phone number (Indian)"""
    phone = field.data
    if not phone:
        return
    
    # Indian phone: 10 digits, starting with 6-9
    pattern = r'^[6-9]\d{9}$'
    if not re.match(pattern, phone):
        raise ValidationError('Invalid phone number (must be 10 digits starting with 6-9)')

def validate_date_range(form, field):
    """Validate date range"""
    date_str = field.data
    if not date_str:
        return
    
    try:
        date = datetime.strptime(date_str, '%Y-%m-%d')
        if date > datetime.now():
            raise ValidationError('Date cannot be in the future')
    except ValueError:
        raise ValidationError('Invalid date format. Use YYYY-MM-DD')

def validate_positive_integer(form, field):
    """Validate positive integer"""
    value = field.data
    if value is not None and value <= 0:
        raise ValidationError('Value must be positive')

def validate_percentage(form, field):
    """Validate percentage (0-100)"""
    value = field.data
    if value is not None and (value < 0 or value > 100):
        raise ValidationError('Value must be between 0 and 100')

def validate_username_format(form, field):
    """Validate username format"""
    username = field.data
    if not username:
        return
    
    # Username: alphanumeric, underscore, 3-32 chars
    pattern = r'^[a-zA-Z0-9_]{3,32}$'
    if not re.match(pattern, username):
        raise ValidationError('Username must be 3-32 characters (letters, numbers, underscore)')

def validate_password_strength(form, field):
    """Validate password strength"""
    password = field.data
    if not password:
        return
    
    if len(password) < 8:
        raise ValidationError('Password must be at least 8 characters')
    
    if not any(c.isupper() for c in password):
        raise ValidationError('Password must contain at least one uppercase letter')
    
    if not any(c.islower() for c in password):
        raise ValidationError('Password must contain at least one lowercase letter')
    
    if not any(c.isdigit() for c in password):
        raise ValidationError('Password must contain at least one number')

def validate_credit_amount(form, field):
    """Validate credit amount"""
    amount = field.data
    if amount is not None:
        if amount <= 0:
            raise ValidationError('Credit amount must be positive')
        if amount > 1000000:
            raise ValidationError('Credit amount cannot exceed 1,000,000')

def validate_price(form, field):
    """Validate price amount"""
    price = field.data
    if price is not None:
        if price <= 0:
            raise ValidationError('Price must be positive')
        if price > 100000:
            raise ValidationError('Price cannot exceed ₹100,000')

def validate_image_prompt(form, field):
    """Validate image generation prompt"""
    prompt = field.data
    if not prompt:
        return
    
    if len(prompt) < 3:
        raise ValidationError('Prompt too short (minimum 3 characters)')
    
    if len(prompt) > 1000:
        raise ValidationError('Prompt too long (maximum 1000 characters)')
    
    # Check for invalid characters
    invalid_chars = ['<', '>', '{', '}', '[', ']', '\\', '`']
    for char in invalid_chars:
        if char in prompt:
            raise ValidationError(f'Prompt contains invalid character: {char}')

def validate_file_extension(form, field):
    """Validate file extension"""
    filename = field.data.filename if field.data else None
    if filename:
        allowed = ['.jpg', '.jpeg', '.png', '.gif', '.webp']
        ext = filename.lower()[-4:] if len(filename) > 4 else filename.lower()
        if ext not in allowed and ext not in ['.txt', '.csv', '.xlsx']:
            raise ValidationError(f'File type not allowed. Allowed: {", ".join(allowed)}')

def validate_file_size(max_size_mb=10):
    """Validate file size"""
    def _validate(form, field):
        file = field.data
        if file:
            max_bytes = max_size_mb * 1024 * 1024
            if file.content_length > max_bytes:
                raise ValidationError(f'File too large (max {max_size_mb}MB)')
    return _validate

def validate_json_format(form, field):
    """Validate JSON format"""
    data = field.data
    if data:
        try:
            import json
            if isinstance(data, str):
                json.loads(data)
        except:
            raise ValidationError('Invalid JSON format')

def validate_url(form, field):
    """Validate URL format"""
    url = field.data
    if url:
        pattern = r'^https?://(?:[-\w.]|(?:%[\da-fA-F]{2}))+'
        if not re.match(pattern, url):
            raise ValidationError('Invalid URL format')

def validate_bot_token_unique(form, field):
    """Validate bot token uniqueness"""
    from web.models import BotInstance
    token = field.data
    if token:
        existing = BotInstance.query.filter_by(bot_token=token).first()
        if existing and (not form._obj or existing.id != form._obj.id):
            raise ValidationError('Bot token already exists')

def validate_username_unique(form, field):
    """Validate username uniqueness"""
    from web.models import Admin, Owner
    username = field.data
    if username:
        admin = Admin.query.filter_by(username=username).first()
        owner = Owner.query.filter_by(username=username).first()
        if (admin or owner) and (not form._obj or 
            (admin and admin.id != form._obj.id) or 
            (owner and owner.id != form._obj.id)):
            raise ValidationError('Username already exists')