"""
Flask-WTF forms for admin panel
"""

from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, IntegerField, FloatField, TextAreaField, SelectField
from wtforms.validators import DataRequired, Length, Email, EqualTo, ValidationError, Optional, NumberRange
from web.models import Admin, Owner

class LoginForm(FlaskForm):
    """Login form"""
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=64)])
    password = PasswordField('Password', validators=[DataRequired()])
    remember = BooleanField('Remember Me')

class AdminForm(FlaskForm):
    """Admin creation/editing form"""
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=64)])
    email = StringField('Email', validators=[Optional(), Email(), Length(max=255)])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=8, max=128)])
    confirm_password = PasswordField('Confirm Password', validators=[
        DataRequired(), EqualTo('password', message='Passwords must match')
    ])
    role = SelectField('Role', choices=[('admin', 'Admin'), ('super_admin', 'Super Admin')])
    bot_instance_id = SelectField('Assigned Bot', coerce=int, validators=[Optional()])
    
    def validate_username(self, username):
        admin = Admin.query.filter_by(username=username.data).first()
        if admin:
            raise ValidationError('Username already exists.')

class BotConfigForm(FlaskForm):
    """Bot configuration form"""
    bot_token = StringField('Bot Token', validators=[DataRequired(), Length(min=30, max=255)])
    bot_username = StringField('Bot Username', validators=[Optional(), Length(max=100)])
    razorpay_key = StringField('Razorpay Key ID', validators=[Optional(), Length(max=255)])
    razorpay_secret = StringField('Razorpay Key Secret', validators=[Optional(), Length(max=255)])
    api_endpoint = StringField('AI API Endpoint', validators=[Optional(), Length(max=500)])
    api_key = StringField('AI API Key', validators=[Optional(), Length(max=500)])

class CreditPackageForm(FlaskForm):
    """Credit package configuration"""
    credits_100 = IntegerField('100 Credits Price (₹)', validators=[Optional(), NumberRange(min=0)])
    credits_500 = IntegerField('500 Credits Price (₹)', validators=[Optional(), NumberRange(min=0)])
    credits_1000 = IntegerField('1000 Credits Price (₹)', validators=[Optional(), NumberRange(min=0)])
    generation_cost = IntegerField('Generation Cost (Credits)', validators=[DataRequired(), NumberRange(min=1)])
    welcome_bonus = IntegerField('Welcome Bonus (Credits)', validators=[DataRequired(), NumberRange(min=0)])
    referral_bonus = IntegerField('Referral Bonus (Credits)', validators=[DataRequired(), NumberRange(min=0)])

class BroadcastForm(FlaskForm):
    """Broadcast message form"""
    message = TextAreaField('Message', validators=[DataRequired(), Length(max=4000)])
    parse_mode = SelectField('Format', choices=[('HTML', 'HTML'), ('Markdown', 'Markdown'), ('Plain', 'Plain Text')])
    send_to = SelectField('Send To', choices=[
        ('all', 'All Users'),
        ('active', 'Active Users (last 7 days)'),
        ('inactive', 'Inactive Users'),
        ('premium', 'Premium Users')
    ])
    schedule_time = StringField('Schedule Time (optional)', validators=[Optional()])

class SystemSettingsForm(FlaskForm):
    """System settings form"""
    maintenance_mode = BooleanField('Maintenance Mode')
    rate_limit = IntegerField('Rate Limit (requests/minute)', validators=[DataRequired(), NumberRange(min=1, max=100)])
    concurrent_limit = IntegerField('Concurrent Generations', validators=[DataRequired(), NumberRange(min=1, max=20)])
    auto_moderate = BooleanField('Auto-moderate Content')
    backup_frequency = SelectField('Backup Frequency', choices=[
        ('daily', 'Daily'),
        ('weekly', 'Weekly'),
        ('monthly', 'Monthly')
    ])