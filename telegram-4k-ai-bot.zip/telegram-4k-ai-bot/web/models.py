"""
Database models for web admin panel
"""

from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()

class User(UserMixin, db.Model):
    """User model (matches bot models.User)"""
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    telegram_id = db.Column(db.String(100), unique=True, nullable=False)
    username = db.Column(db.String(100))
    first_name = db.Column(db.String(100))
    last_name = db.Column(db.String(100))
    credits_balance = db.Column(db.Float, default=0)
    total_generated = db.Column(db.Integer, default=0)
    joined_date = db.Column(db.DateTime, default=datetime.utcnow)
    last_active = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(50), default='active')
    referred_by = db.Column(db.String(100))
    referral_code = db.Column(db.String(50), unique=True)
    bot_instance_id = db.Column(db.Integer, db.ForeignKey('bot_instances.id'))
    
    # Relationships
    images = db.relationship('GeneratedImage', backref='user', lazy='dynamic')
    transactions = db.relationship('Transaction', backref='user', lazy='dynamic')
    
    def get_id(self):
        return str(self.id)
    
    @property
    def is_admin(self):
        return False
    
    @property
    def is_owner(self):
        return False

class Admin(UserMixin, db.Model):
    """Admin model"""
    __tablename__ = 'admins'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    email = db.Column(db.String(255))
    role = db.Column(db.String(50), default='admin')
    bot_instance_id = db.Column(db.Integer, db.ForeignKey('bot_instances.id'))
    permissions = db.Column(db.JSON, default={})
    two_factor_secret = db.Column(db.String(255))
    last_login = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    created_by = db.Column(db.Integer)
    status = db.Column(db.String(50), default='active')
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def get_id(self):
        return str(self.id)
    
    @property
    def is_admin(self):
        return True
    
    @property
    def is_owner(self):
        return False

class Owner(UserMixin, db.Model):
    """Owner/Super Admin model"""
    __tablename__ = 'owners'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    email = db.Column(db.String(255))
    master_key = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    settings = db.Column(db.JSON, default={})
    
    # Relationships
    bot_instances = db.relationship('BotInstance', backref='owner', lazy='dynamic')
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def get_id(self):
        return str(self.id)
    
    @property
    def is_admin(self):
        return True
    
    @property
    def is_owner(self):
        return True

class BotInstance(db.Model):
    """Bot instance model"""
    __tablename__ = 'bot_instances'
    
    id = db.Column(db.Integer, primary_key=True)
    bot_token = db.Column(db.String(255), unique=True, nullable=False)
    bot_username = db.Column(db.String(100))
    owner_id = db.Column(db.Integer, db.ForeignKey('owners.id'))
    admin_id = db.Column(db.Integer, db.ForeignKey('admins.id'))
    razorpay_key = db.Column(db.String(255))
    razorpay_secret = db.Column(db.String(255))
    api_endpoint = db.Column(db.String(500))
    api_key = db.Column(db.String(500))
    status = db.Column(db.String(50), default='inactive')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    config = db.Column(db.JSON, default={})
    
    # Relationships
    users = db.relationship('User', backref='bot', lazy='dynamic')
    admins = db.relationship('Admin', backref='bot', lazy='dynamic')

class GeneratedImage(db.Model):
    """Generated image model"""
    __tablename__ = 'generated_images'
    
    id = db.Column(db.Integer, primary_key=True)
    image_id = db.Column(db.String(100), unique=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    prompt = db.Column(db.Text)
    negative_prompt = db.Column(db.Text)
    style = db.Column(db.String(100))
    resolution = db.Column(db.String(50))
    aspect_ratio = db.Column(db.String(20))
    generation_date = db.Column(db.DateTime, default=datetime.utcnow)
    cost = db.Column(db.Integer, default=10)
    image_url = db.Column(db.String(500))
    thumbnail_url = db.Column(db.String(500))
    status = db.Column(db.String(50), default='completed')
    metadata = db.Column(db.JSON, default={})

class Transaction(db.Model):
    """Transaction model"""
    __tablename__ = 'transactions'
    
    id = db.Column(db.Integer, primary_key=True)
    transaction_id = db.Column(db.String(100), unique=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    amount = db.Column(db.Float)
    credits = db.Column(db.Integer)
    payment_method = db.Column(db.String(50))
    status = db.Column(db.String(50), default='pending')
    razorpay_payment_id = db.Column(db.String(100))
    razorpay_order_id = db.Column(db.String(100))
    date = db.Column(db.DateTime, default=datetime.utcnow)
    metadata = db.Column(db.JSON, default={})

class GenerationQueue(db.Model):
    """Generation queue model"""
    __tablename__ = 'generation_queue'
    
    id = db.Column(db.Integer, primary_key=True)
    queue_id = db.Column(db.String(100), unique=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    prompt = db.Column(db.Text)
    parameters = db.Column(db.JSON)
    status = db.Column(db.String(50), default='queued')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    started_at = db.Column(db.DateTime)
    completed_at = db.Column(db.DateTime)
    result_url = db.Column(db.String(500))
    error = db.Column(db.Text)