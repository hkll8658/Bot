"""
Web admin panel package initialization
"""

from web.app import create_app
from web.models import db, User, Admin, Owner, BotInstance, Transaction, GeneratedImage

__all__ = [
    'create_app',
    'db',
    'User',
    'Admin',
    'Owner',
    'BotInstance',
    'Transaction',
    'GeneratedImage'
]

__version__ = '1.0.0'