"""
Database models for the bot
"""

from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, Boolean, Text, ForeignKey, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime
import uuid

Base = declarative_base()

class BotInstance(Base):
    """Bot instance model for multi-bot support"""
    __tablename__ = 'bot_instances'
    
    id = Column(Integer, primary_key=True)
    bot_token = Column(String(255), unique=True, nullable=False)
    bot_username = Column(String(100))
    owner_id = Column(Integer, ForeignKey('owners.id'))
    admin_id = Column(Integer, ForeignKey('admins.id'))
    razorpay_key = Column(String(255))
    razorpay_secret = Column(String(255))
    api_endpoint = Column(String(500))
    api_key = Column(String(500))
    status = Column(String(50), default='inactive')
    created_at = Column(DateTime, default=datetime.utcnow)
    config = Column(JSON, default={})
    
    # Relationships
    users = relationship("User", back_populates="bot")
    admins = relationship("Admin", back_populates="bot")

class User(Base):
    """User model"""
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    telegram_id = Column(String(100), nullable=False)
    bot_instance_id = Column(Integer, ForeignKey('bot_instances.id'))
    username = Column(String(100))
    first_name = Column(String(100))
    last_name = Column(String(100))
    credits_balance = Column(Float, default=0)
    total_generated = Column(Integer, default=0)
    joined_date = Column(DateTime, default=datetime.utcnow)
    last_active = Column(DateTime, default=datetime.utcnow)
    status = Column(String(50), default='active')
    referred_by = Column(String(100))
    referral_code = Column(String(50), unique=True)
    preferences = Column(JSON, default={})
    
    # Relationships
    bot = relationship("BotInstance", back_populates="users")
    images = relationship("GeneratedImage", back_populates="user")
    transactions = relationship("Transaction", back_populates="user")

class GeneratedImage(Base):
    """Generated image model"""
    __tablename__ = 'generated_images'
    
    id = Column(Integer, primary_key=True)
    image_id = Column(String(100), unique=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(Integer, ForeignKey('users.id'))
    prompt = Column(Text)
    negative_prompt = Column(Text)
    style = Column(String(100))
    resolution = Column(String(50))
    aspect_ratio = Column(String(20))
    generation_date = Column(DateTime, default=datetime.utcnow)
    cost = Column(Integer, default=10)
    image_url = Column(String(500))
    thumbnail_url = Column(String(500))
    status = Column(String(50), default='completed')
    metadata = Column(JSON, default={})
    
    # Relationships
    user = relationship("User", back_populates="images")

class Transaction(Base):
    """Transaction model"""
    __tablename__ = 'transactions'
    
    id = Column(Integer, primary_key=True)
    transaction_id = Column(String(100), unique=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    amount = Column(Float)
    credits = Column(Integer)
    payment_method = Column(String(50))
    status = Column(String(50), default='pending')
    razorpay_payment_id = Column(String(100))
    razorpay_order_id = Column(String(100))
    date = Column(DateTime, default=datetime.utcnow)
    metadata = Column(JSON, default={})
    
    # Relationships
    user = relationship("User", back_populates="transactions")

class Admin(Base):
    """Admin model"""
    __tablename__ = 'admins'
    
    id = Column(Integer, primary_key=True)
    username = Column(String(100), unique=True)
    password_hash = Column(String(255))
    email = Column(String(255))
    role = Column(String(50), default='admin')
    bot_instance_id = Column(Integer, ForeignKey('bot_instances.id'))
    permissions = Column(JSON, default={})
    two_factor_secret = Column(String(255))
    last_login = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
    created_by = Column(Integer)
    status = Column(String(50), default='active')
    
    # Relationships
    bot = relationship("BotInstance", back_populates="admins")

class Owner(Base):
    """Owner/Super Admin model"""
    __tablename__ = 'owners'
    
    id = Column(Integer, primary_key=True)
    username = Column(String(100), unique=True)
    password_hash = Column(String(255))
    email = Column(String(255))
    master_key = Column(String(255))
    created_at = Column(DateTime, default=datetime.utcnow)
    last_login = Column(DateTime)
    settings = Column(JSON, default={})
    
    # Relationships
    bot_instances = relationship("BotInstance", backref="owner")

class GenerationQueue(Base):
    """Generation queue model"""
    __tablename__ = 'generation_queue'
    
    id = Column(Integer, primary_key=True)
    queue_id = Column(String(100), unique=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    prompt = Column(Text)
    parameters = Column(JSON)
    status = Column(String(50), default='queued')
    created_at = Column(DateTime, default=datetime.utcnow)
    started_at = Column(DateTime)
    completed_at = Column(DateTime)
    result_url = Column(String(500))
    error = Column(Text)