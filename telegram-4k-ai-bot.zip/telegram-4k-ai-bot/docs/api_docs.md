# API Documentation - Ultra 4K AI Image Generator Bot

## Overview

This document describes the internal APIs used by the bot and the web admin panel. These APIs are used for communication between components and can be used for integration with external systems.

## Base URL
