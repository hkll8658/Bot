# User Guide - Ultra 4K AI Image Generator Bot

## Getting Started

### What is this bot?
This bot allows you to generate stunning 4K images using artificial intelligence. Simply describe what you want, and the bot will create it for you!

### How to Start
1. Open Telegram and search for `@your_bot_username`
2. Click "Start" or send `/start` command
3. You'll receive 5 free credits to begin!

## Commands

### Basic Commands

| Command | Description |
|---------|-------------|
| `/start` | Register and get welcome message |
| `/generate [prompt]` | Generate an image (add prompt directly) |
| `/balance` | Check your credit balance |
| `/recharge` | Buy more credits |
| `/history` | View your generated images |
| `/referral` | Get your referral link |
| `/help` | Show help message |
| `/settings` | Configure preferences |

### Generating Images

**Method 1: Direct command**


❤️‍🔥❤️‍🔥❤️‍🔥❤️‍🔥❤️‍🔥❤️‍🔥❤️‍🔥


**Method 2: Interactive mode**
1. Send `/generate`
2. Type your prompt when asked
3. Choose a style
4. Select aspect ratio
5. Wait 20-30 seconds for generation

### Available Styles

| Style | Description |
|-------|-------------|
| 🎨 Realistic | Photorealistic images |
| 🌸 Anime | Japanese anime style |
| 🎬 Cinematic | Movie-like dramatic scenes |
| 🖼️ Oil Painting | Classical oil painting |
| ✏️ Sketch | Pencil sketch style |
| 🌌 Fantasy | Magical and mythical scenes |
| 📸 Photorealistic | Ultra-realistic photos |
| 🎭 3D Render | 3D computer graphics |

### Aspect Ratios

| Ratio | Use Case |
|-------|----------|
| 16:9 | Landscape, widescreen |
| 9:16 | Portrait, mobile wallpaper |
| 1:1 | Square, social media |
| 21:9 | Cinematic, ultrawide |
| 4:3 | Classic photo |
| 3:2 | Standard photo |

## Credit System

### Pricing

| Credits | Price | Cost per Image |
|---------|-------|----------------|
| 100 | ₹50 | ₹5 |
| 500 | ₹200 | ₹4 |
| 1000 | ₹400 | ₹4 |

- Each image generation costs **10 credits**
- Images are generated in **Ultra 4K (3840x2160)** resolution

### Earning Free Credits

**Welcome Bonus**: 5 free credits when you start

**Referral Program**:
- Share your referral link: `/referral`
- When someone joins using your link, you get **10 credits**
- Your friend gets **5 bonus credits**

## Tips for Better Results

### Writing Good Prompts

✅ **Good prompts:**
- "a majestic lion sitting on a rock at sunset, photorealistic, 4k"
- "cyberpunk city street with neon lights, rain, futuristic, cinematic"
- "beautiful landscape of mountains and lake, morning mist, oil painting"

❌ **Bad prompts:**
- "cat" (too simple)
- "something nice" (too vague)
- "make me a picture" (not descriptive)

### Include Details
- Subject (what's in the image)
- Setting (where/background)
- Style (realistic, anime, etc.)
- Mood (happy, dark, mysterious)
- Colors (vibrant, pastel, monochrome)

### Negative Prompts
You can specify what you DON'T want in your image:
- "no people"
- "without text"
- "not blurry"
- "no watermarks"

## FAQ

**Q: How long does generation take?**
A: Usually 20-30 seconds, depending on queue load.

**Q: Can I download the images?**
A: Yes! All images are sent directly in chat. You can download them from Telegram.

**Q: What happens if generation fails?**
A: Your credits will be automatically refunded.

**Q: Can I generate multiple images at once?**
A: Currently one image per request to ensure quality.

**Q: Is NSFW content allowed?**
A: No, the bot filters inappropriate content automatically.

**Q: How do I contact support?**
A: Send a message to @admin or use /help for contact options.

## Troubleshooting

### Common Issues

**"Insufficient credits"**
- Check your balance with `/balance`
- Buy more credits with `/recharge`

**"Generation failed"**
- Try again later
- Your credits will be refunded automatically

**Bot not responding**
- Check if bot is online
- Try restarting Telegram
- Contact support if persistent

## Privacy & Security

- Your prompts are stored to improve service quality
- Generated images are stored for 30 days
- Payment information is processed securely through Razorpay
- Never share your account credentials

## Contact

- **Support**: @support_bot
- **Updates**: @bot_channel
- **Email**: support@example.com

---

*Thank you for using Ultra 4K AI Image Generator!*