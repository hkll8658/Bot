"""
Utility function tests (continued)
"""

import pytest
from datetime import datetime, timedelta
from bot.utils.helpers import (
    generate_referral_code, format_credit_balance, hash_password,
    verify_password, validate_email, sanitize_input, time_ago,
    validate_prompt, RateLimiter, CacheManager, StatsCollector
)
from bot.utils.validators import (
    validate_telegram_id, validate_username, validate_amount,
    validate_credits, validate_prompt_content, validate_style,
    validate_aspect_ratio, validate_resolution, validate_email_format,
    validate_phone, validate_password_strength, validate_date_range,
    sanitize_filename, validate_file_size, validate_file_type
)

def test_generate_referral_code():
    """Test referral code generation"""
    code = generate_referral_code()
    assert len(code) == 8
    assert code.isalnum()
    
    # Test uniqueness
    codes = [generate_referral_code() for _ in range(10)]
    assert len(set(codes)) == 10

def test_format_credit_balance():
    """Test credit balance formatting"""
    assert format_credit_balance(500) == "500"
    assert format_credit_balance(1500) == "1.5K"
    assert format_credit_balance(1500000) == "1.5M"
    assert format_credit_balance(100) == "100"

def test_password_hashing():
    """Test password hashing and verification"""
    password = "test_password123"
    hashed = hash_password(password)
    
    assert hashed != password
    assert len(hashed) == 64  # SHA-256 hash length
    
    assert verify_password(password, hashed) is True
    assert verify_password("wrong_password", hashed) is False

def test_email_validation():
    """Test email validation"""
    assert validate_email("test@example.com") is True
    assert validate_email("user.name+tag@domain.co.uk") is True
    assert validate_email("invalid.email") is False
    assert validate_email("@domain.com") is False
    assert validate_email("") is False

def test_sanitize_input():
    """Test input sanitization"""
    dangerous = "<script>alert('xss')</script>"
    sanitized = sanitize_input(dangerous)
    assert "<" not in sanitized
    assert ">" not in sanitized
    
    long_text = "a" * 2000
    sanitized = sanitize_input(long_text)
    assert len(sanitized) <= 1000

def test_time_ago():
    """Test time ago formatting"""
    now = datetime.utcnow()
    
    assert time_ago(now - timedelta(seconds=30)) == "just now"
    assert time_ago(now - timedelta(minutes=5)) == "5 minutes ago"
    assert time_ago(now - timedelta(hours=2)) == "2 hours ago"
    assert time_ago(now - timedelta(days=3)) == "3 days ago"
    assert time_ago(now - timedelta(days=40)) == "1 month ago"
    assert time_ago(now - timedelta(days=400)) == "1 year ago"
    
    # Test None input
    assert time_ago(None) == "never"

def test_prompt_validation():
    """Test prompt validation"""
    assert validate_prompt("beautiful sunset") is True
    assert validate_prompt("a" * 50) is True
    
    assert validate_prompt("") is False
    assert validate_prompt("ab") is False  # Too short
    assert validate_prompt("a" * 2000) is False  # Too long
    assert validate_prompt("test <script>") is False  # Invalid chars

def test_rate_limiter():
    """Test rate limiting"""
    limiter = RateLimiter(max_requests=3, time_window=10)
    user_id = "test_user"
    
    # First 3 requests should be allowed
    assert limiter.is_allowed(user_id) is True
    assert limiter.is_allowed(user_id) is True
    assert limiter.is_allowed(user_id) is True
    
    # 4th request should be denied
    assert limiter.is_allowed(user_id) is False
    
    # Check remaining
    assert limiter.get_remaining(user_id) == 0
    
    # Test reset
    limiter.reset(user_id)
    assert limiter.is_allowed(user_id) is True

def test_cache_manager():
    """Test cache manager"""
    cache = CacheManager()
    
    # Test set and get
    cache.set("key1", "value1", ttl=1)
    assert cache.get("key1") == "value1"
    
    # Test expiration
    import time
    time.sleep(1.1)
    assert cache.get("key1") is None
    
    # Test delete
    cache.set("key2", "value2")
    cache.delete("key2")
    assert cache.get("key2") is None
    
    # Test clear
    cache.set("key3", "value3")
    cache.set("key4", "value4")
    cache.clear()
    assert cache.get("key3") is None
    assert cache.get("key4") is None

def test_stats_collector():
    """Test statistics collector"""
    stats = StatsCollector()
    
    # Test increment
    stats.increment("commands", "generate")
    stats.increment("commands", "generate")
    stats.increment("commands", "start")
    
    assert stats.stats["commands"]["generate"] == 2
    assert stats.stats["commands"]["start"] == 1
    
    # Test record value
    stats.record_value("response_time", "generate", 0.5)
    stats.record_value("response_time", "generate", 0.7)
    
    assert len(stats.stats["response_time"]["generate"]) == 2
    assert stats.stats["response_time"]["generate"][0] == 0.5
    
    # Test get summary
    summary = stats.get_summary()
    assert "uptime" in summary
    assert "commands" in summary
    assert summary["total_commands"] == 3

def test_validate_telegram_id():
    """Test Telegram ID validation"""
    assert validate_telegram_id("12345") is True
    assert validate_telegram_id("0") is False
    assert validate_telegram_id("-123") is False
    assert validate_telegram_id("abc") is False
    assert validate_telegram_id("") is False

def test_validate_username():
    """Test username validation"""
    assert validate_username("john_doe") is True
    assert validate_username("john123") is True
    assert validate_username("jo") is False  # Too short
    assert validate_username("john@doe") is False  # Invalid char
    assert validate_username("") is False

def test_validate_amount():
    """Test amount validation"""
    valid, amount = validate_amount("100")
    assert valid is True
    assert amount == 100.0
    
    valid, amount = validate_amount("100.50")
    assert valid is True
    assert amount == 100.50
    
    valid, _ = validate_amount("-100")
    assert valid is False
    
    valid, _ = validate_amount("abc")
    assert valid is False
    
    valid, _ = validate_amount("1000000")  # Too high
    assert valid is False

def test_validate_credits():
    """Test credits validation"""
    valid, credits = validate_credits("100")
    assert valid is True
    assert credits == 100
    
    valid, _ = validate_credits("-50")
    assert valid is False
    
    valid, _ = validate_credits("1000001")  # Too high
    assert valid is False
    
    valid, _ = validate_credits("abc")
    assert valid is False

def test_validate_prompt_content():
    """Test prompt content validation"""
    valid, msg = validate_prompt_content("beautiful landscape")
    assert valid is True
    assert msg is None
    
    valid, msg = validate_prompt_content("")
    assert valid is False
    assert msg is not None
    
    valid, msg = validate_prompt_content("a")
    assert valid is False
    assert "too short" in msg.lower()
    
    valid, msg = validate_prompt_content("test <script>")
    assert valid is False
    assert "invalid character" in msg.lower()

def test_validate_style():
    """Test style validation"""
    assert validate_style("realistic") is True
    assert validate_style("anime") is True
    assert validate_style("cinematic") is True
    assert validate_style("invalid_style") is False
    assert validate_style("") is False

def test_validate_aspect_ratio():
    """Test aspect ratio validation"""
    assert validate_aspect_ratio("16:9") is True
    assert validate_aspect_ratio("9:16") is True
    assert validate_aspect_ratio("1:1") is True
    assert validate_aspect_ratio("21:9") is True
    assert validate_aspect_ratio("4:3") is True
    assert validate_aspect_ratio("3:2") is True
    assert validate_aspect_ratio("5:4") is False
    assert validate_aspect_ratio("") is False

def test_validate_resolution():
    """Test resolution validation"""
    assert validate_resolution("3840x2160") is True
    assert validate_resolution("1920x1080") is True
    assert validate_resolution("1024x1024") is True
    assert validate_resolution("800x600") is False
    assert validate_resolution("") is False

def test_validate_email_format():
    """Test email format validation"""
    valid, msg = validate_email_format("test@example.com")
    assert valid is True
    assert msg is None
    
    valid, msg = validate_email_format("")
    assert valid is False
    assert "empty" in msg.lower()
    
    valid, msg = validate_email_format("invalid")
    assert valid is False
    assert "invalid format" in msg.lower()

def test_validate_phone():
    """Test phone number validation"""
    valid, msg = validate_phone("9876543210")
    assert valid is True
    assert msg is None
    
    valid, msg = validate_phone("")
    assert valid is False
    assert "empty" in msg.lower()
    
    valid, msg = validate_phone("12345")
    assert valid is False
    assert "invalid" in msg.lower()
    
    valid, msg = validate_phone("987654321")  # 9 digits
    assert valid is False
    assert "invalid" in msg.lower()

def test_validate_password_strength():
    """Test password strength validation"""
    valid, msg = validate_password_strength("Test12345")
    assert valid is True
    assert msg is None
    
    valid, msg = validate_password_strength("")
    assert valid is False
    assert "empty" in msg.lower()
    
    valid, msg = validate_password_strength("short")
    assert valid is False
    assert "at least 8" in msg.lower()
    
    valid, msg = validate_password_strength("alllowercase")
    assert valid is False
    assert "uppercase" in msg.lower()
    
    valid, msg = validate_password_strength("NOLOWERCASE123")
    assert valid is False
    assert "lowercase" in msg.lower()
    
    valid, msg = validate_password_strength("NoNumbers")
    assert valid is False
    assert "digit" in msg.lower()

def test_validate_date_range():
    """Test date range validation"""
    from datetime import datetime, timedelta
    
    today = datetime.now().strftime('%Y-%m-%d')
    yesterday = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
    next_week = (datetime.now() + timedelta(days=7)).strftime('%Y-%m-%d')
    
    valid, msg = validate_date_range(yesterday, today)
    assert valid is True
    assert msg is None
    
    valid, msg = validate_date_range(today, yesterday)
    assert valid is False
    assert "after end date" in msg.lower()
    
    valid, msg = validate_date_range(yesterday, next_week)
    assert valid is False
    assert "exceed 365 days" in msg.lower()
    
    valid, msg = validate_date_range("invalid", today)
    assert valid is False
    assert "invalid date format" in msg.lower()

def test_sanitize_filename():
    """Test filename sanitization"""
    assert sanitize_filename("test.jpg") == "test.jpg"
    assert sanitize_filename("../test.jpg") == ".._test.jpg"
    assert sanitize_filename("test/../file.jpg") == "test_.._file.jpg"
    assert sanitize_filename("a" * 300 + ".jpg") == ("a" * 250 + ".jpg")  # Truncated

def test_validate_file_size():
    """Test file size validation"""
    valid, msg = validate_file_size(1024 * 1024)  # 1MB
    assert valid is True
    assert msg is None
    
    valid, msg = validate_file_size(15 * 1024 * 1024, max_mb=10)  # 15MB > 10MB
    assert valid is False
    assert "too large" in msg.lower()
    
    valid, msg = validate_file_size(-100)
    assert valid is False
    assert "invalid" in msg.lower()

def test_validate_file_type():
    """Test file type validation"""
    allowed = ['jpg', 'png', 'gif']
    
    valid, msg = validate_file_type("test.jpg", allowed)
    assert valid is True
    assert msg is None
    
    valid, msg = validate_file_type("test.png", allowed)
    assert valid is True
    
    valid, msg = validate_file_type("test.txt", allowed)
    assert valid is False
    assert "not allowed" in msg.lower()
    
    valid, msg = validate_file_type("test", allowed)
    assert valid is False
    assert "not allowed" in msg.lower()