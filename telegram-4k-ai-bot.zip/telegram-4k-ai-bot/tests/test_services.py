"""
Service tests
"""

import pytest
from unittest.mock import Mock, AsyncMock, patch
import asyncio
from datetime import datetime

from bot.services.image_generation import ImageGenerationService
from bot.services.payment import PaymentService, WebhookHandler
from bot.services.queue_manager import QueueManager

@pytest.fixture
def image_service():
    """Create image generation service"""
    return ImageGenerationService(
        api_endpoint="https://test.api.com",
        api_key="test_key",
        config={'timeout': 30}
    )

@pytest.fixture
def payment_service():
    """Create payment service"""
    return PaymentService(
        key_id="test_key_id",
        key_secret="test_key_secret"
    )

@pytest.fixture
def queue_manager():
    """Create queue manager"""
    return QueueManager(max_concurrent=2)

@pytest.mark.asyncio
async def test_image_generation_success(image_service):
    """Test successful image generation"""
    mock_response = AsyncMock()
    mock_response.status = 200
    mock_response.json.return_value = {
        'artifacts': [{
            'finishReason': 'SUCCESS',
            'base64': 'dGVzdA=='  # base64 for "test"
        }]
    }
    
    mock_session = AsyncMock()
    mock_session.post.return_value.__aenter__.return_value = mock_response
    
    with patch('aiohttp.ClientSession', return_value=mock_session):
        image_service.session = mock_session
        
        result = await image_service.generate_image(
            prompt="test prompt",
            style="realistic",
            aspect_ratio="16:9"
        )
        
        assert result['success'] is True
        assert 'images' in result

@pytest.mark.asyncio
async def test_image_generation_failure(image_service):
    """Test failed image generation"""
    mock_response = AsyncMock()
    mock_response.status = 400
    mock_response.text.return_value = "Bad Request"
    
    mock_session = AsyncMock()
    mock_session.post.return_value.__aenter__.return_value = mock_response
    
    with patch('aiohttp.ClientSession', return_value=mock_session):
        image_service.session = mock_session
        
        result = await image_service.generate_image(
            prompt="test prompt",
            style="realistic"
        )
        
        assert result['success'] is False
        assert 'error' in result

@pytest.mark.asyncio
async def test_queue_manager_add_job(queue_manager):
    """Test adding job to queue"""
    with patch('bot.services.queue_manager.get_db_session') as mock_session:
        mock_db = Mock()
        mock_session.return_value = mock_db
        
        job_id = await queue_manager.add_to_queue(
            user_id=1,
            prompt="test prompt",
            parameters={'style': 'realistic'}
        )
        
        assert job_id is not None
        assert queue_manager.queue.qsize() == 1

@pytest.mark.asyncio
async def test_queue_manager_get_status(queue_manager):
    """Test getting queue status"""
    with patch('bot.services.queue_manager.get_db_session') as mock_session:
        mock_db = Mock()
        mock_session.return_value = mock_db
        
        mock_entry = Mock()
        mock_entry.queue_id = "test_id"
        mock_entry.status = "queued"
        mock_entry.created_at = datetime.now()
        
        mock_db.query.return_value.filter_by.return_value.first.return_value = mock_entry
        
        status = await queue_manager.get_queue_status("test_id")
        
        assert status is not None
        assert status['id'] == "test_id"
        assert status['status'] == "queued"

@pytest.mark.asyncio
async def test_payment_service_create_order(payment_service):
    """Test creating payment order"""
    with patch.object(payment_service.client.order, 'create') as mock_create:
        mock_create.return_value = {
            'id': 'order_test123',
            'amount': 5000,
            'currency': 'INR',
            'receipt': 'receipt_123',
            'status': 'created'
        }
        
        order = await payment_service.create_order(
            amount=50,
            currency="INR",
            receipt="receipt_123"
        )
        
        assert order is not None
        assert order['id'] == 'order_test123'
        assert order['amount'] == 50

@pytest.mark.asyncio
async def test_payment_service_verify_payment(payment_service):
    """Test payment verification"""
    signature = payment_service.key_secret  # For testing
    
    result = await payment_service.verify_payment(
        order_id="order_test123",
        payment_id="pay_test123",
        signature="test_signature"
    )
    
    # Should fail with wrong signature
    assert result is False

@pytest.mark.asyncio
async def test_webhook_handler(payment_service):
    """Test webhook handling"""
    webhook = WebhookHandler(key_secret="test_secret")
    
    payload = {
        'payload': {
            'payment': {
                'entity': {
                    'id': 'pay_test123',
                    'order_id': 'order_test123',
                    'status': 'captured'
                }
            }
        }
    }
    
    # Test signature verification
    with patch('hmac.compare_digest', return_value=True):
        result = await webhook.verify_webhook_signature(
            payload=b'{}',
            signature="test_sig",
            webhook_secret="test_secret"
        )
        
        assert result is True