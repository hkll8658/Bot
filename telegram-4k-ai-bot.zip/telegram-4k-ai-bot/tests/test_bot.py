"""
Bot core tests
"""

import pytest
import asyncio
from unittest.mock import Mock, patch, AsyncMock
from datetime import datetime

from bot.main import AIImageBot, BotManager
from models import BotInstance, User, Owner
from config.settings import TestingConfig

@pytest.fixture
def bot_instance():
    """Create test bot instance"""
    return BotInstance(
        id=1,
        bot_token="test:token",
        bot_username="test_bot",
        owner_id=1,
        status="active",
        config={
            'price_plans': {100: 50, 500: 200, 1000: 400},
            'generation_cost': 10,
            'welcome_bonus': 5,
            'referral_bonus': 10
        }
    )

@pytest.fixture
def owner():
    """Create test owner"""
    return Owner(
        id=1,
        username="test_owner",
        password_hash="hash",
        email="owner@test.com"
    )

@pytest.mark.asyncio
async def test_bot_initialization(bot_instance):
    """Test bot instance initialization"""
    with patch('telegram.ext.Application.builder') as mock_builder:
        mock_app = AsyncMock()
        mock_builder.return_value.token.return_value.build.return_value = mock_app
        
        bot = AIImageBot(bot_instance)
        
        assert bot.bot_id == 1
        assert bot.bot_token == "test:token"
        assert bot.bot_username == "test_bot"
        assert bot.image_service is not None
        assert bot.payment_service is not None
        assert bot.queue_manager is not None

@pytest.mark.asyncio
async def test_bot_manager():
    """Test bot manager"""
    manager = BotManager()
    
    assert manager.bots == {}
    assert not manager.running

@pytest.mark.asyncio
async def test_start_services(bot_instance):
    """Test starting bot services"""
    with patch('telegram.ext.Application.builder') as mock_builder:
        mock_app = AsyncMock()
        mock_builder.return_value.token.return_value.build.return_value = mock_app
        
        bot = AIImageBot(bot_instance)
        
        # Mock queue manager
        bot.queue_manager.start_workers = AsyncMock()
        
        await bot.start_services()
        
        bot.queue_manager.start_workers.assert_called_once()

@pytest.mark.asyncio
async def test_stop_services(bot_instance):
    """Test stopping bot services"""
    with patch('telegram.ext.Application.builder') as mock_builder:
        mock_app = AsyncMock()
        mock_builder.return_value.token.return_value.build.return_value = mock_app
        
        bot = AIImageBot(bot_instance)
        
        # Mock services
        bot.queue_manager.stop_workers = AsyncMock()
        bot.image_service.close = AsyncMock()
        
        await bot.stop_services()
        
        bot.queue_manager.stop_workers.assert_called_once()
        bot.image_service.close.assert_called_once()

@pytest.mark.asyncio
async def test_error_handler(bot_instance):
    """Test error handling"""
    with patch('telegram.ext.Application.builder') as mock_builder:
        mock_app = AsyncMock()
        mock_builder.return_value.token.return_value.build.return_value = mock_app
        
        bot = AIImageBot(bot_instance)
        
        # Create mock update
        mock_update = Mock()
        mock_update.effective_chat.id = 12345
        
        mock_context = Mock()
        mock_context.error = Exception("Test error")
        mock_context.bot.send_message = AsyncMock()
        
        await bot.error_handler(mock_update, mock_context)
        
        mock_context.bot.send_message.assert_called_once()