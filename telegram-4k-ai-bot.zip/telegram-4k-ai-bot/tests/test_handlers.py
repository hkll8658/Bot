"""
Handler tests
"""

import pytest
from unittest.mock import Mock, AsyncMock, patch
from telegram import Update, User as TelegramUser, Message, Chat
from telegram.ext import ContextTypes
from datetime import datetime

from bot.handlers.user import start, generate, balance, referral
from bot.handlers.admin import admin_panel, admin_dashboard
from bot.handlers.owner import owner_panel, owner_bots
from models import User, Admin, Owner

@pytest.fixture
def telegram_user():
    """Create mock Telegram user"""
    user = Mock(spec=TelegramUser)
    user.id = 12345
    user.username = "testuser"
    user.first_name = "Test"
    user.last_name = "User"
    return user

@pytest.fixture
def update(telegram_user):
    """Create mock update"""
    update = Mock(spec=Update)
    update.effective_user = telegram_user
    update.effective_chat = Mock(spec=Chat)
    update.effective_chat.id = 12345
    update.message = Mock(spec=Message)
    update.message.reply_text = AsyncMock()
    update.message.reply_photo = AsyncMock()
    update.callback_query = Mock()
    update.callback_query.answer = AsyncMock()
    update.callback_query.edit_message_text = AsyncMock()
    return update

@pytest.fixture
def context():
    """Create mock context"""
    context = Mock(spec=ContextTypes.DEFAULT_TYPE)
    context.bot = AsyncMock()
    context.bot.send_message = AsyncMock()
    context.bot.send_photo = AsyncMock()
    context.bot_data = {
        'bot_instance_id': 1,
        'welcome_bonus': 5,
        'referral_bonus': 10
    }
    context.user_data = {}
    return context

@pytest.mark.asyncio
async def test_start_handler_new_user(update, context):
    """Test /start command for new user"""
    with patch('bot.handlers.user.get_db_session') as mock_session:
        # Mock database
        mock_db = Mock()
        mock_session.return_value = mock_db
        mock_db.query.return_value.filter_by.return_value.first.return_value = None
        
        await start(update, context)
        
        # Verify response
        update.message.reply_text.assert_called_once()
        args = update.message.reply_text.call_args[0]
        assert "Welcome" in args[0]

@pytest.mark.asyncio
async def test_start_handler_existing_user(update, context):
    """Test /start command for existing user"""
    with patch('bot.handlers.user.get_db_session') as mock_session:
        # Mock database
        mock_db = Mock()
        mock_session.return_value = mock_db
        
        mock_user = Mock(spec=User)
        mock_user.credits_balance = 100
        mock_user.total_generated = 50
        mock_user.joined_date = datetime.now()
        
        mock_db.query.return_value.filter_by.return_value.first.return_value = mock_user
        
        await start(update, context)
        
        # Verify response
        update.message.reply_text.assert_called_once()
        args = update.message.reply_text.call_args[0]
        assert "Welcome back" in args[0]

@pytest.mark.asyncio
async def test_generate_handler_insufficient_credits(update, context):
    """Test generate with insufficient credits"""
    with patch('bot.handlers.user.get_db_session') as mock_session:
        mock_db = Mock()
        mock_session.return_value = mock_db
        
        mock_user = Mock(spec=User)
        mock_user.credits_balance = 5  # Less than 10 required
        
        mock_db.query.return_value.filter_by.return_value.first.return_value = mock_user
        
        await generate(update, context)
        
        update.message.reply_text.assert_called_once()
        assert "Insufficient credits" in update.message.reply_text.call_args[0][0]

@pytest.mark.asyncio
async def test_balance_handler(update, context):
    """Test balance command"""
    with patch('bot.handlers.user.get_db_session') as mock_session:
        mock_db = Mock()
        mock_session.return_value = mock_db
        
        mock_user = Mock(spec=User)
        mock_user.credits_balance = 100
        mock_user.total_generated = 50
        mock_user.joined_date = datetime.now()
        
        mock_db.query.return_value.filter_by.return_value.first.return_value = mock_user
        
        await balance(update, context)
        
        update.message.reply_text.assert_called_once()
        assert "Your Account Balance" in update.message.reply_text.call_args[0][0]

@pytest.mark.asyncio
async def test_referral_handler(update, context):
    """Test referral command"""
    with patch('bot.handlers.user.get_db_session') as mock_session:
        mock_db = Mock()
        mock_session.return_value = mock_db
        
        mock_user = Mock(spec=User)
        mock_user.telegram_id = "12345"
        mock_user.referral_code = "ABC123"
        
        mock_db.query.return_value.filter_by.return_value.first.return_value = mock_user
        
        await referral(update, context)
        
        update.message.reply_text.assert_called_once()
        assert "Referral Link" in update.message.reply_text.call_args[0][0]

@pytest.mark.asyncio
async def test_admin_panel_admin_access(update, context):
    """Test admin panel with admin access"""
    with patch('bot.handlers.admin.get_db_session') as mock_session:
        mock_db = Mock()
        mock_session.return_value = mock_db
        
        mock_admin = Mock(spec=Admin)
        mock_admin.username = "testuser"
        mock_admin.status = "active"
        
        mock_db.query.return_value.filter_by.return_value.first.return_value = mock_admin
        
        await admin_panel(update, context)
        
        update.message.reply_text.assert_called_once()
        assert "Admin Control Panel" in update.message.reply_text.call_args[0][0]

@pytest.mark.asyncio
async def test_owner_panel_owner_access(update, context):
    """Test owner panel with owner access"""
    with patch('bot.handlers.owner.get_db_session') as mock_session:
        mock_db = Mock()
        mock_session.return_value = mock_db
        
        mock_owner = Mock(spec=Owner)
        mock_owner.username = "testuser"
        
        mock_db.query.return_value.filter_by.return_value.first.return_value = mock_owner
        
        await owner_panel(update, context)
        
        update.message.reply_text.assert_called_once()
        assert "Owner Control Panel" in update.message.reply_text.call_args[0][0]