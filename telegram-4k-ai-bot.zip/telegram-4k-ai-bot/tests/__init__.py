"""
Test package initialization
"""

import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

# Test configuration
TEST_DATABASE_URL = 'sqlite:///:memory:'
TEST_REDIS_URL = 'redis://localhost:6379/1'