#!/bin/bash
# docker-entrypoint.sh

set -e

echo "🚀 Starting AI Image Bot..."

# Function to wait for database
wait_for_db() {
    echo "Waiting for database..."
    retries=30
    while ! nc -z postgres 5432 && [ $retries -gt 0 ]; do
        sleep 2
        retries=$((retries-1))
        echo "Waiting for database... $retries attempts left"
    done
    
    if [ $retries -eq 0 ]; then
        echo "❌ Database connection timeout"
        exit 1
    fi
    echo "✅ Database is ready!"
}

# Function to wait for redis
wait_for_redis() {
    echo "Waiting for redis..."
    retries=30
    while ! nc -z redis 6379 && [ $retries -gt 0 ]; do
        sleep 2
        retries=$((retries-1))
        echo "Waiting for redis... $retries attempts left"
    done
    
    if [ $retries -eq 0 ]; then
        echo "❌ Redis connection timeout"
        exit 1
    fi
    echo "✅ Redis is ready!"
}

# Initialize database
init_db() {
    echo "Initializing database..."
    python scripts/setup_db.py
    if [ $? -eq 0 ]; then
        echo "✅ Database initialized successfully"
    else
        echo "❌ Database initialization failed"
        exit 1
    fi
}

# Run migrations
run_migrations() {
    echo "Running database migrations..."
    python scripts/migrate.py migrate
    if [ $? -eq 0 ]; then
        echo "✅ Migrations completed successfully"
    else
        echo "❌ Migrations failed"
        exit 1
    fi
}

# Create default admin
create_admin() {
    echo "Creating default admin..."
    python -c "
import os
from web.models import db, Admin
from werkzeug.security import generate_password_hash

admin = Admin.query.filter_by(username=os.getenv('ADMIN_USERNAME', 'admin')).first()
if not admin:
    admin = Admin(
        username=os.getenv('ADMIN_USERNAME', 'admin'),
        password_hash=generate_password_hash(os.getenv('ADMIN_PASSWORD', 'admin123')),
        email=os.getenv('ADMIN_EMAIL', 'admin@example.com'),
        role='admin',
        status='active'
    )
    db.session.add(admin)
    db.session.commit()
    print('✅ Default admin created')
else:
    print('✅ Admin already exists')
"
}

# Create default owner
create_owner() {
    echo "Creating default owner..."
    python -c "
import os
from web.models import db, Owner
from werkzeug.security import generate_password_hash

owner = Owner.query.filter_by(username=os.getenv('OWNER_USERNAME', 'owner')).first()
if not owner:
    owner = Owner(
        username=os.getenv('OWNER_USERNAME', 'owner'),
        password_hash=generate_password_hash(os.getenv('OWNER_PASSWORD', 'owner123')),
        email=os.getenv('OWNER_EMAIL', 'owner@example.com'),
        master_key=os.getenv('OWNER_MASTER_KEY', 'master-key-123')
    )
    db.session.add(owner)
    db.session.commit()
    print('✅ Default owner created')
else:
    print('✅ Owner already exists')
"
}

# Main execution
main() {
    echo "======================================"
    echo "AI Image Bot - Docker Entrypoint"
    echo "======================================"
    
    # Wait for dependencies
    if [ "$SKIP_WAIT" != "true" ]; then
        wait_for_db
        wait_for_redis
    fi
    
    # Initialize if needed
    if [ "$SKIP_INIT" != "true" ]; then
        init_db
        run_migrations
        create_admin
        create_owner
    fi
    
    echo "✅ Setup complete!"
    echo "======================================"
    
    # Execute command
    exec "$@"
}

# Run main function
main "$@"