"""
Configuration settings for the bot
"""

import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class Config:
    """Base configuration"""
    
    # Bot settings
    BOT_TOKEN = os.getenv('BOT_TOKEN', '')
    BOT_USERNAME = os.getenv('BOT_USERNAME', '')
    
    # Database
    DATABASE_URL = os.getenv('DATABASE_URL', 'sqlite:///bot.db')
    
    # Redis
    REDIS_URL = os.getenv('REDIS_URL', 'redis://localhost:6379')
    
    # Payment
    RAZORPAY_KEY_ID = os.getenv('RAZORPAY_KEY_ID', '')
    RAZORPAY_KEY_SECRET = os.getenv('RAZORPAY_KEY_SECRET', '')
    
    # AI API
    AI_API_ENDPOINT = os.getenv('AI_API_ENDPOINT', '')
    AI_API_KEY = os.getenv('AI_API_KEY', '')
    
    # Storage
    STORAGE_PROVIDER = os.getenv('STORAGE_PROVIDER', 'local')
    AWS_ACCESS_KEY = os.getenv('AWS_ACCESS_KEY', '')
    AWS_SECRET_KEY = os.getenv('AWS_SECRET_KEY', '')
    AWS_BUCKET_NAME = os.getenv('AWS_BUCKET_NAME', '')
    CLOUDINARY_CLOUD_NAME = os.getenv('CLOUDINARY_CLOUD_NAME', '')
    CLOUDINARY_API_KEY = os.getenv('CLOUDINARY_API_KEY', '')
    CLOUDINARY_API_SECRET = os.getenv('CLOUDINARY_API_SECRET', '')
    
    # Admin
    ADMIN_USERNAME = os.getenv('ADMIN_USERNAME', 'admin')
    ADMIN_PASSWORD = os.getenv('ADMIN_PASSWORD', 'admin123')
    ADMIN_EMAIL = os.getenv('ADMIN_EMAIL', 'admin@example.com')
    
    # Owner
    OWNER_USERNAME = os.getenv('OWNER_USERNAME', 'owner')
    OWNER_PASSWORD = os.getenv('OWNER_PASSWORD', 'owner123')
    OWNER_EMAIL = os.getenv('OWNER_EMAIL', 'owner@example.com')
    OWNER_MASTER_KEY = os.getenv('OWNER_MASTER_KEY', 'master-key-123')
    
    # Settings
    MAINTENANCE_MODE = os.getenv('MAINTENANCE_MODE', 'False').lower() == 'true'
    RATE_LIMIT = int(os.getenv('RATE_LIMIT', 10))
    CONCURRENT_GENERATIONS = int(os.getenv('CONCURRENT_GENERATIONS', 5))
    
    # Pricing
    PRICE_PLANS = {
        100: 50,
        500: 200,
        1000: 400
    }
    GENERATION_COST = 10
    WELCOME_BONUS = 5
    REFERRAL_BONUS = 10
    
    # Security
    SECRET_KEY = os.getenv('SECRET_KEY', 'your-secret-key-here')
    JWT_SECRET_KEY = os.getenv('JWT_SECRET_KEY', 'jwt-secret-key')
    SESSION_TIMEOUT = int(os.getenv('SESSION_TIMEOUT', 3600))
    
    # Webhook
    WEBHOOK_URL = os.getenv('WEBHOOK_URL', '')
    WEBHOOK_PORT = int(os.getenv('WEBHOOK_PORT', 8443))
    
    # Logging
    LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
    LOG_FILE = os.getenv('LOG_FILE', 'logs/bot.log')
    
    # Features
    ENABLE_REFERRAL = os.getenv('ENABLE_REFERRAL', 'True').lower() == 'true'
    ENABLE_DAILY_BONUS = os.getenv('ENABLE_DAILY_BONUS', 'False').lower() == 'true'
    ENABLE_NSFW_FILTER = os.getenv('ENABLE_NSFW_FILTER', 'True').lower() == 'true'
    
    # Queue
    QUEUE_MAX_SIZE = int(os.getenv('QUEUE_MAX_SIZE', 100))
    QUEUE_TIMEOUT = int(os.getenv('QUEUE_TIMEOUT', 300))

class DevelopmentConfig(Config):
    """Development configuration"""
    DEBUG = True
    TESTING = False
    
    # Use SQLite for development
    DATABASE_URL = os.getenv('DEV_DATABASE_URL', 'sqlite:///dev_bot.db')
    
    # More verbose logging
    LOG_LEVEL = 'DEBUG'

class ProductionConfig(Config):
    """Production configuration"""
    DEBUG = False
    TESTING = False
    
    # Production database
    DATABASE_URL = os.getenv('DATABASE_URL')
    
    # Production settings
    MAINTENANCE_MODE = False
    
    # Stricter rate limits
    RATE_LIMIT = int(os.getenv('PROD_RATE_LIMIT', 5))
    
    # Error reporting
    SENTRY_DSN = os.getenv('SENTRY_DSN', '')

class TestingConfig(Config):
    """Testing configuration"""
    DEBUG = True
    TESTING = True
    
    # Use in-memory database for tests
    DATABASE_URL = 'sqlite:///:memory:'
    
    # Disable rate limiting for tests
    RATE_LIMIT = 1000
    
    # Mock services
    TEST_MODE = True

# Select configuration based on environment
env = os.getenv('FLASK_ENV', 'development')

if env == 'production':
    config = ProductionConfig
elif env == 'testing':
    config = TestingConfig
else:
    config = DevelopmentConfig

# Export config
__all__ = ['config']