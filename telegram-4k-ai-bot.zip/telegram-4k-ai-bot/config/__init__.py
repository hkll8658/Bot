"""
Configuration package
"""

from config.settings import config, DevelopmentConfig, ProductionConfig, TestingConfig

__all__ = ['config', 'DevelopmentConfig', 'ProductionConfig', 'TestingConfig']